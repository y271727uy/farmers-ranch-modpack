 /*
EntityEvents.spawned(event => {
    const entity = event.entity;
    if (!entity.item) return; 
    if (entity.item.id === Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_orange",inactive:"forestry:fruit_orange"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:0.5f",inactive:"forestry:0.5f"},"forestry:maturation":{active:"forestry:4i",inactive:"forestry:4i"},"forestry:saplings":{active:"forestry:0.025fd",inactive:"forestry:0.025fd"},"forestry:sappiness":{active:"forestry:0.3fd",inactive:"forestry:0.3fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_orange",inactive:"forestry:tree_orange"},"forestry:yield":{active:"forestry:0.3f",inactive:"forestry:0.3f"}}}}}')) {
      entity.item = Item.of('fruitfulfun:orange_sapling', entity.item.count);
    }
  });

EntityEvents.spawned(event => {
    const entity = event.entity;
    if (!entity.item) return; 
    if (entity.item.id === Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_dates",inactive:"forestry:fruit_dates"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:1.0f",inactive:"forestry:1.0f"},"forestry:maturation":{active:"forestry:4i",inactive:"forestry:4i"},"forestry:saplings":{active:"forestry:0.035fd",inactive:"forestry:0.035fd"},"forestry:sappiness":{active:"forestry:0.3fd",inactive:"forestry:0.3fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_date",inactive:"forestry:tree_date"},"forestry:yield":{active:"forestry:0.1fd",inactive:"forestry:0.1fd"}}}}}')) {
      entity.item = Item.of('ramadandelight:palm_sapling', entity.item.count);
    }
  });

EntityEvents.spawned(event => {
    const entity = event.entity;
    if (!entity.item) return; 
    if (entity.item.id === Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_coconut",inactive:"forestry:fruit_coconut"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:1.25f",inactive:"forestry:1.25f"},"forestry:maturation":{active:"forestry:3i",inactive:"forestry:3i"},"forestry:saplings":{active:"forestry:0.025fd",inactive:"forestry:0.025fd"},"forestry:sappiness":{active:"forestry:0.4fd",inactive:"forestry:0.4fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_coconut",inactive:"forestry:tree_coconut"},"forestry:yield":{active:"forestry:0.3f",inactive:"forestry:0.3f"}}}}}')) {
      entity.item = Item.of('braziliandelight:coconut_palm_sapling', entity.item.count);
    }
  });

EntityEvents.spawned(event => {
    const entity = event.entity;
    if (!entity.item) return; 
    if (entity.item.id === Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_lemon",inactive:"forestry:fruit_lemon"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:0.25f",inactive:"forestry:0.25f"},"forestry:maturation":{active:"forestry:4i",inactive:"forestry:4i"},"forestry:saplings":{active:"forestry:0.025fd",inactive:"forestry:0.025fd"},"forestry:sappiness":{active:"forestry:0.3fd",inactive:"forestry:0.3fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_lemon",inactive:"forestry:tree_lemon"},"forestry:yield":{active:"forestry:0.3f",inactive:"forestry:0.3f"}}}}}')) {
      entity.item = Item.of('braziliandelight:lemon_sapling', entity.item.count);
    }
  });
 
EntityEvents.spawned(event => {
    const entity = event.entity;
    if (!entity.item) return; 
    if (entity.item.id === 'manors_bounty:strawberry') {
      entity.item = Item.of('neapolitan:strawberries', entity.item.count);
    }
  });
  */