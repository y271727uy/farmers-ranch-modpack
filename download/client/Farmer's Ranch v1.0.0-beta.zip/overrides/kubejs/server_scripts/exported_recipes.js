ServerEvents.recipes(event => {

    event.shaped(
        Item.of('list:pure_pumpkin_feed', 2),
        [
            ' AA',
            ' AA',
            'B  '
        ],
        {
            A: 'minecraft:pumpkin',
            B: 'farmersdelight:canvas'
        }
    )
    event.shapeless(
        Item.of('list:pure_pumpkin_feed', 2),
        [
            'minecraft:pumpkin',
            'minecraft:pumpkin',
            'minecraft:pumpkin',
            'minecraft:pumpkin',
            'farmersdelight:canvas'
        ]
    )
});
