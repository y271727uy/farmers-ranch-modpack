/*
let $ServerLevel =
    Java.loadClass("net.minecraft.server.level.ServerLevel")
let $StructurePlaceSettings =
    Java.loadClass("net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings")
let $Rotation =
    Java.loadClass("net.minecraft.world.level.block.Rotation")
let $Mirror =
    Java.loadClass("net.minecraft.world.level.block.Mirror")
 
ServerEvents.loaded((event) => {
    function getStructureName(path) {
        return ResourceLocation.fromNamespaceAndPath("cmi", path)
    }
 
    
    // 在指定维度的特定坐标生成结构
    // @param {String} dimId - 维度 ID (例如 "minecraft:the_nether")
    // @param {String} structurePath - 结构路径和文件名 
    // (展开后为 "cmi:structures/radar/radar.nbt" 实际编写时不需要写文件后缀)
    // @param {[number, number, number]} pos - 坐标 [x, y, z]
    
    function placeStructure(dimId, structurePath, pos) {
        let level = event.server.getLevel(dimId)
        let structureNamespace = kubejs
 
        if (!(level instanceof $ServerLevel)) {
            console.warn(`Failed to find dimension: ${structureNamespace}:${dimId}`)
            return false
        }
 
        let manager = level.getServer().getStructureManager()
        let template = manager.get(getStructureName(structurePath))
 
        if (!template.isPresent()) {
            console.warn(`Structure not found: ${structureNamespace}:${structurePath}`)
            return false
        }
 
        let [x, y, z] = pos
        template.ifPresent((temp) => {
            temp.placeInWorld(
                level,
                new BlockPos(x, y, z),
                new BlockPos(x, y, z),
                new $StructurePlaceSettings()
                    .setRotation($Rotation.NONE)
                    .setMirror($Mirror.NONE),
                level.getRandom(),
                2
            )
        })
 
        console.info(`Placed structure ${structureNamespace}:${structurePath} at (${x}, ${y}, ${z})`)
        return true
    }
 
    function placeAllStructures(structures) {
        let data = event.server.persistentData
 
        structures.forEach((structure) => {
            let { id, dimId, path, pos } = structure
            let key = `structure_${id}_placed`
 
            if (data.getBoolean(key)) {
                console.info(`Structure "${id}" already placed, skipping.`)
                return
            }
 
            let level = event.server.getLevel(dimId)
            if (!(level instanceof $ServerLevel)) {
                console.warn(`Failed to find dimension: ${dimId}`)
                return
            }
 
            let success = placeStructure(dimId, path, pos)
            if (success) {
                data.putBoolean(key, true)
                console.info(`Marked structure "${id}" as placed.`)
            }
        })
    }
 
    let structuresToPlace = [
        {
            id: "radar_moon",
            dimId: "ad_astra:moon",
            path: "radar/radar",
            pos: [0, 80, 0]
        },
         
    ]
 
    placeAllStructures(structuresToPlace)
})

*/

/*
此维度非彼维度
真的不是下面的

1. 向量空间 (Vector Space)
   - 定义: V 是一个集合，配合加法和数乘运算
   - 域 (Field) F: 向量空间中的标量来源
       例: F = R, C, F_p

2. 维度 (Dimension)
   - 定义: 向量空间的基向量个数
       dim_F(V) = 基的向量个数
   - 示例:
       V = R^2, F = R  => dim_R(R^2) = 2
       V = C,   F = C  => dim_C(C)   = 1
       V = C,   F = R  => dim_R(C)   = 2

3. 扩域 / 换域公式
   - 条件: K ⊆ F, V 是 F-向量空间
   - 公式:
       dim_K(V) = dim_K(F) * dim_F(V)
   - 示例:
       V = C (作为 C-空间)
           dim_C(C) = 1
       F = C, K = R
           dim_R(C) = dim_R(C) * dim_C(C) = 2 * 1 = 2

4. 总结
   - 向量空间的维度依赖于它所定义的域
   - 换域时可用乘法公式计算新维度


*/