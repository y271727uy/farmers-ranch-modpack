// 用一个对象记录每个玩家的购买次数
let buyCounts = {};

SDMShopEvents.buyEntry(event => {
    let player = event.player.getUUID(); // 唯一标识玩家
    if (!buyCounts[player]) buyCounts[player] = 0;

    buyCounts[player]++; // 累计购买次数
    let count = buyCounts[player];

    // 每买满10次，价格才涨1
    let increment = Math.floor(count / 10); // 向下取整
    event.setPrice(event.getPrice() + increment);

    event.player.sendSystemMessage("你已购买 " + count + " 次，本次价格增加 " + increment);
})