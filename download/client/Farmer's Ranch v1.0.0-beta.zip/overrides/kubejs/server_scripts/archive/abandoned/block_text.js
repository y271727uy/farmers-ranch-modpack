/*
PlayerEvents.rightClickItem(event => {
    // 判断手上是否是指定物品 a
    if (event.item.id == 'brewincompatdelight:juniper_berries') {
        // 获取目标方块位置（右键面前一格）
        let pos = event.block.offset(event.face)

        // 获取下方方块 ID
        let blockBelow = event.world.getBlock(pos.down()).id

        // 允许放置的方块列表
        let validSoil = [
            'minecraft:dirt',
            'minecraft:grass_block',
            'minecraft:coarse_dirt',
            'minecraft:podzol',
            'minecraft:mycelium'
        ]

        if (validSoil.includes(blockBelow)) {
            // 放置方块 b
            event.server.setBlock(pos, 'minecraft:coarse_dirt')

            // 播放树苗放置音效
            event.server.playSound(pos, 'item.crop.plant', 1.0, 1.0)

            // 消耗物品（非创造模式）
            if (!event.player.isCreative()) {
                event.item.count -= 1
            }

            // 阻止原本右键行为
            event.cancel()
        } else {
            // 可选：提示玩家不能放置
            event.player.tell('§c只能放在泥土类方块上！')
            event.cancel()
        }
    }
})
*/



//测试失败，脚本无效
/*
const itemsToPlace = [
    'brewincompatdelight:juniper_berries'
]

const validSoil = [
    "minecraft:dirt",
    "minecraft:grass_block",
    "minecraft:coarse_dirt",
    "minecraft:podzol",
    "minecraft:mycelium"
]

BlockEvents.rightClicked(event => {
    // 玩家手上物品
    let stack = event.player.getHeldItem(event.hand)
    if (!stack) return
    if (!itemsToPlace.includes(stack.id)) return

    let pos = event.block.offset(event.face)
    let blockBelow = event.level.getBlock(pos.down()).id

    if (!validSoil.includes(blockBelow)) {
        event.player.tell("§c只能放在泥土类方块上！")
        return
    }

    // 放置方块
    event.level.getBlock(pos).set('minecraft:coarse_dirt')

    // 播放音效
    event.player.runCommandSilent(`playsound minecraft:item.crop.plant block @s ${pos.x} ${pos.y} ${pos.z} 1 1`)

    // 消耗物品
    if (!event.player.isCreative()) {
        stack.count -= 1
    }

    // 阻止原本右键方块的行为
    event.cancel()
})
*/