/*
//鱼卵
    public static final ItemEntry<EggItem>  = REGISTRATE
            .item("_egg", p -> new EggItem(p, ))
            .properties(p -> p.food(new FoodProperties.Builder()
                    .nutrition(1)
                    .saturationMod(0.3f)
                    .build()))
            .model(ItemModelUtil::eggItemModel)
            .register();
*/