/*
ServerEvents.recipes(event => {
    event.remove({id: 'growable_ores:vanilla/leather_cane'})
    event.remove({id: 'growable_ores:vanilla/gunpowder_cane'})
    event.remove({id: 'growable_ores:vanilla/wool_cane'})
    event.remove({id: 'growable_ores:vanilla/feather_cane'})
    event.remove({id: 'growable_ores:vanilla/egg_cane'})
    event.remove({id: 'growable_ores:vanilla/result/netherite_ingot_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/egg_cane_result'})

    event.remove({id: 'growable_ores:vanilla/result/coal_cane_result'})
    event.remove({id: 'orecrop:coal_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/diamond_cane_result'})
    event.remove({id: 'orecrop:diamond_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/emerald_cane_result'})
    event.remove({id: 'orecrop:emerald_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/gold_cane_result'})
    event.remove({id: 'orecrop:gold_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/iron_cane_result'})
    event.remove({id: 'orecrop:iron_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/lapis_cane_result'})
    event.remove({id: 'orecrop:lapis_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/nether_quartz_cane_result'})
    event.remove({id: 'orecrop:quartz_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/redstone_cane_result'})
    event.remove({id: 'orecrop:redstone_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/netherite_scrap_cane_result'})
    event.remove({id: 'orecrop:netherite_fruit'})
    event.remove({id: 'growable_ores:vanilla/result/copper_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/leather_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/feather_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/wool_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/gunpowder_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/blaze_rod_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/slime_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/bone_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/ender_pearl_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/prismarine_shard_cane'})
    event.remove({id: 'growable_ores:vanilla/result/prismarine_crystals_cane'})
    event.remove({id: 'growable_ores:vanilla/result/oak_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/spruce_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/warped_stem_cane'})
    event.remove({id: 'growable_ores:vanilla/result/crimson_stem_cane'})
    event.remove({id: 'growable_ores:vanilla/result/cherry_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/bamboo_block_cane'})
    event.remove({id: 'growable_ores:vanilla/result/mangrove_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/dark_oak_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/acacia_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/birch_log_cane'})
    event.remove({id: 'growable_ores:vanilla/result/jungle_log_cane'})
    event.remove({id: 'growable_ores:create/result/c_andesite_alloy_cane'})
    event.remove({id: 'growable_ores:create/result/c_brass_ingot_cane'})
    event.remove({id: 'growable_ores:create/result/c_polished_rose_quartz_cane'})
    event.remove({id: 'growable_ores:vanilla/result/nether_star_cane_result'})
    event.remove({id: 'growable_ores:vanilla/result/glowstone_cane_result'})
    event.remove({id: 'growable_ores:ae/result/fluix_crystal_cane_result'})

    event.remove({id: 'growable_ores:vanilla/slime_cane'})
    event.remove({id: 'growable_ores:vanilla/prismarine_shard_cane'})
    event.remove({id: 'growable_ores:vanilla/jungle_log_cane'})
    event.remove({id: 'growable_ores:vanilla/crimson_stem_cane'})
    event.remove({id: 'growable_ores:vanilla/bamboo_block_cane'})
    event.remove({id: 'growable_ores:vanilla/acacia_log_cane'})
    event.remove({id: 'growable_ores:vanilla/clay_cane'})
    event.remove({id: 'growable_ores:vanilla/prismarine_crystals_cane'})
    event.remove({id: 'growable_ores:vanilla/netherite_ingot_cane'})
    event.remove({id: 'growable_ores:vanilla/warped_stem_cane'})
    event.remove({id: 'growable_ores:vanilla/spruce_log_cane'})
    event.remove({id: 'growable_ores:vanilla/mangrove_log_cane'})
    event.remove({id: 'growable_ores:vanilla/blaze_rod_cane'})
    event.remove({id: 'growable_ores:vanilla/birch_log_cane'})
    event.remove({id: 'growable_ores:vanilla/dark_oak_log_cane'})
    event.remove({id: 'growable_ores:vanilla/oak_log_cane'})
    event.remove({id: 'growable_ores:vanilla/cherry_log_cane'})
    event.remove({id: 'growable_ores:vanilla/bone_cane'})
    event.remove({id: 'growable_ores:vanilla/ender_pearl_cane'})
    event.remove({id: 'growable_ores:create/c_andesite_alloy_cane'})
    event.remove({id: 'growable_ores:create/c_brass_ingot_cane'})
    event.remove({id: 'growable_ores:create/c_polished_rose_quartz_cane'})
    event.remove({id: 'growable_ores:vanilla/nether_star_cane'})
    event.remove({id: 'growable_ores:ae/fluix_crystal_cane'})
    event.remove({id: 'growable_ores:vanilla/glowstone_cane'})
})
    //1终点
    */

/*

event.remove({id: ''})

ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "minecraft:candle", // 种子物品
        ["oak_leaves"], // 作物可以种植的土壤类别
        { block: "minecraft:candle" }, // 显示方块
        [
            Item.of ("minecraft:candle") // 物品
                .withChance(100) // 相对于其他掉落物的权重
                .withRolls(1, 2) // 掉落次数（最小值，最大值）
            // 例如，选中时将给予1到2根蜡烛
        ],
        10, // 生长刻数
        1, // 可选，生长修饰符 - 大多数情况下可设为1
    )

    event.recipes.botanypots.soil(
        "minecraft:oak_leaves", // 该土壤关联的物品
        { block: "minecraft:oak_leaves" }, // 显示方块
        ["oak_leaves"], // 该土壤提供的类别
        100, // 该土壤将提供的生长刻数，设为-1表示无修饰符
        0.5 // 可选，生长修饰符，例如：0.5表示所有作物的生长时间减半
    )

    event.recipes.botanypots.fertilizer(
        "minecraft:iron_ingot", // 肥料物品
        10, // 应用的最小生长刻数
        20 // 应用的最大生长刻数
        // 例如：10到20个刻数将随机给予作物
    )
})

// 每次作物生长时触发
BotanyPotsEvents.onCropGrow(event => {
    // event.random : 与事件关联的随机对象
    // event.crop : 描述生长作物的作物对象
    // event.originalDrops : 该作物掉落的物品数组
    // event.drops : 可修改的数组，用于更改作物的掉落物
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})


ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:coal_sapling", 
        ["dirt"], 
        { block: "minecraft:candle" }, 
        [
            Item.of ("minecraft:candle") 
                .withChance(2) 
                .withRolls(1, 1), 

            Item.of ("minecraft:candle") 
                .withChance(2) 
                .withRolls(1, 1) 
        ],
        80000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )

    event.recipes.botanypots.fertilizer(
        "minecraft:air", 
        10, 
        20 
       
    )
})

// 每次作物生长时触发
BotanyPotsEvents.onCropGrow(event => {
    // event.random : 与事件关联的随机对象
    // event.crop : 描述生长作物的作物对象
    // event.originalDrops : 该作物掉落的物品数组
    // event.drops : 可修改的数组，用于更改作物的掉落物
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})

ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "", 
        ["dirt"], 
        { block: "" }, 
        [
            Item.of ("") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})

*/

// 优化：使用数据驱动方式注册作物配方，减少重复代码
/*
const cropsData = [
    {
        sapling: "orecrop:coal_sapling",
        nugget: "orecrop:coal_nugget",
        leaf: "orecrop:coal_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:copper_sapling",
        nugget: "create:copper_nugget",
        leaf: "orecrop:copper_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:iron_sapling",
        nugget: "minecraft:iron_nugget",
        leaf: "orecrop:iron_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:gold_sapling",
        nugget: "minecraft:gold_nugget",
        leaf: "orecrop:gold_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:emerald_sapling",
        nugget: "orecrop:emerald_nugget",
        leaf: "orecrop:emerald_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:redstone_sapling",
        nugget: "orecrop:redstone_nugget",
        leaf: "orecrop:redstone_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:lapis_sapling",
        nugget: "orecrop:lapis_nugget",
        leaf: "orecrop:lapis_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:diamond_sapling",
        nugget: "orecrop:diamond_nugget",
        leaf: "orecrop:diamond_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:quartz_sapling",
        nugget: "orecrop:quartz_nugget",
        leaf: "orecrop:quartz_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    },
    {
        sapling: "orecrop:netherite_sapling",
        nugget: "orecrop:netherite_nugget",
        leaf: "orecrop:netherite_leaf",
        nuggetChance: 10,
        nuggetRolls: [1, 9],
        leafChance: 1,
        leafRolls: [1, 1]
    }
];

// 注册所有作物配方
cropsData.forEach(crop => {
    ServerEvents.recipes(event => {
        event.recipes.botanypots.crop(
            crop.sapling,
            ["dirt"],
            { block: crop.sapling },
            [
                Item.of(crop.leaf)
                    .withChance(crop.leafChance)
                    .withRolls(...crop.leafRolls),

                Item.of("orecrop:ore_log")
                    .withChance(25)
                    .withRolls(1, 1),

                Item.of(crop.nugget)
                    .withChance(crop.nuggetChance)
                    .withRolls(...crop.nuggetRolls)
            ],
            18000,
            1,
        )

        event.recipes.botanypots.soil(
            "minecraft:dirt",
            { block: "minecraft:dirt" },
            ["dirt"],
            100,
            0.5
        )
    })
});

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})
*/
// 保留原始代码但注释掉，以供参考

/*
ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:coal_sapling", 
        ["dirt"], 
        { block: "orecrop:coal_sapling" }, 
        [
            Item.of ("orecrop:coal_leaf") 
                .withChance(10) 
                .withRolls(1, 1), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:coal_nugget") 
                .withChance(1) 
                .withRolls(1, 9) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:copper_sapling", 
        ["dirt"], 
        { block: "orecrop:copper_sapling" }, 
        [
            Item.of ("create:copper_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:copper_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:iron_sapling", 
        ["dirt"], 
        { block: "orecrop:iron_sapling" }, 
        [
            Item.of ("minecraft:iron_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:iron_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:gold_sapling", 
        ["dirt"], 
        { block: "orecrop:gold_sapling" }, 
        [
            Item.of ("minecraft:gold_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:gold_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})


ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:emerald_sapling", 
        ["dirt"], 
        { block: "orecrop:emerald_sapling" }, 
        [
            Item.of ("orecrop:emerald_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:emerald_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:redstone_sapling", 
        ["dirt"], 
        { block: "orecrop:redstone_sapling" }, 
        [
            Item.of ("orecrop:redstone_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:redstone_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:lapis_sapling", 
        ["dirt"], 
        { block: "orecrop:lapis_sapling" }, 
        [
            Item.of ("orecrop:lapis_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:lapis_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:diamond_sapling", 
        ["dirt"], 
        { block: "orecrop:diamond_sapling" }, 
        [
            Item.of ("orecrop:diamond_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:diamond_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {

    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:quartz_sapling", 
        ["dirt"], 
        { block: "orecrop:quartz_sapling" }, 
        [
            Item.of ("orecrop:quartz_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:quartz_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})

BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})



ServerEvents.recipes(event => {
    event.recipes.botanypots.crop(
        "orecrop:netherite_sapling", 
        ["dirt"], 
        { block: "orecrop:netherite_sapling" }, 
        [
            Item.of ("orecrop:netherite_nugget") 
                .withChance(10) 
                .withRolls(1, 9), 

            Item.of ("orecrop:ore_log") 
                .withChance(25) 
                .withRolls(1, 1), 

            Item.of ("orecrop:netherite_leaf") 
                .withChance(1) 
                .withRolls(1, 1) 
        ],
        18000, 
        1, 
    )

    event.recipes.botanypots.soil(
        "minecraft:dirt", 
        { block: "minecraft:dirt" }, 
        ["dirt"], 
        100, 
        0.5
    )
})


BotanyPotsEvents.onCropGrow(event => {
    console.log([event.random, event.crop, event.originalDrops, event.drops].join(","))
})


// 右键点击事件 - 禁止与作物交互
BlockEvents.rightClicked('orecrop:coal_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:diamond_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:emerald_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:gold_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:iron_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:lapis_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:quartz_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:redstone_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:netherite_sapling', event => event.cancel())
BlockEvents.rightClicked('orecrop:copper_sapling', event => event.cancel())

*/
//2重点

/*
替换示例
BlockEvents.placed('', event => {
  event.block.set('minecraft:air')
  event.player.setStatusMessage(Text.translate("因致命bug所以禁止放置"))
  event.player.give('')
})

BlockEvents.placed("", event => {
    let pos = event.block.pos
    let level = event.level

    // 定义检测范围
    for (let i = -4; i <= 4; i++) {     
    for (let j = -4; j <= 4; j++) { 
        for (let k = -4; k <= 4; k++) { 
            if (i == 0 && j == 0 && k == 0) continue

                let checkPos = pos.offset(i, j, k)
                let block = level.getBlock(checkPos)

                // 如果发现 torcherino
                if (block.id == "torcherino:torcherino") {
                    // 播放音效提醒
                    event.server.runCommandSilent(`playsound minecraft:block.anvil.land block @a ${checkPos.x} ${checkPos.y} ${checkPos.z}`)

                    // 返还 torcherino 物品
                    let item = Item.of("torcherino:torcherino")
                    event.player.give(item)

                    // 删除 torcherino
                    block.set("minecraft:air")
                }
            }
        }
    }
})



BlockEvents.placed('orecrop:coal_sapling', event => {
  event.block.set('minecraft:air')
  event.player.setStatusMessage(Text.translate("因致命bug所以禁止放置"))
  event.player.give('orecrop:coal_sapling')
})

BlockEvents.placed("orecrop:coal_sapling", event => {
    let pos = event.block.pos
    let level = event.level

    // 定义检测范围
    for (let i = -4; i <= 4; i++) {     // X方向 -4 ~ +4  → 共9格
    for (let j = -4; j <= 4; j++) { // Y方向 -4 ~ +4  → 共9格
        for (let k = -4; k <= 4; k++) { // Z方向 -4 ~ +4  → 共9格
            if (i == 0 && j == 0 && k == 0) continue

                let checkPos = pos.offset(i, j, k)
                let block = level.getBlock(checkPos)

                // 如果发现 torcherino
                if (block.id == "torcherino:torcherino") {
                    // 播放音效提醒
                    event.server.runCommandSilent(`playsound minecraft:block.anvil.land block @a ${checkPos.x} ${checkPos.y} ${checkPos.z}`)

                    // 返还 torcherino 物品
                    let item = Item.of("torcherino:torcherino")
                    event.player.give(item)

                    // 删除 torcherino
                    block.set("minecraft:air")
                }
            }
        }
    }
})

BlockEvents.placed('orecrop:diamond_sapling', event => {
  event.block.set('minecraft:air')
  event.player.setStatusMessage(Text.translate("因致命bug所以禁止放置"))
  event.player.give('orecrop:diamond_sapling')
})

BlockEvents.placed("orecrop:diamond_sapling", event => {
    let pos = event.block.pos
    let level = event.level

    // 定义检测范围
    for (let i = -4; i <= 4; i++) {   
    for (let j = -4; j <= 4; j++) { 
        for (let k = -4; k <= 4; k++) { 
            if (i == 0 && j == 0 && k == 0) continue

                let checkPos = pos.offset(i, j, k)
                let block = level.getBlock(checkPos)

                // 如果发现 torcherino
                if (block.id == "torcherino:torcherino") {
                    // 播放音效提醒
                    event.server.runCommandSilent(`playsound minecraft:block.anvil.land block @a ${checkPos.x} ${checkPos.y} ${checkPos.z}`)

                    // 返还 torcherino 物品
                    let item = Item.of("torcherino:torcherino")
                    event.player.give(item)

                    // 删除 torcherino
                    block.set("minecraft:air")
                }
            }
        }
    }
})
*/
/*
//3开始

// 需要禁止放置的树苗
const saplings = [
  "orecrop:coal_sapling",
  "orecrop:diamond_sapling",
  "orecrop:emerald_sapling",
  "orecrop:gold_sapling",
  "orecrop:iron_sapling",
  "orecrop:lapis_sapling",
  "orecrop:quartz_sapling",
  "orecrop:redstone_sapling",
  "orecrop:netherite_sapling",
  "orecrop:copper_sapling"
]

// 不允许出现在附近的方块
const forbiddenBlocks = [
  "torcherino:torcherino",
  "torcherino:compressed_torcherino",
  "torcherino:double_compressed_torcherino",
  "torcherino:lanterino",
  "torcherino:compressed_lanterino",
  "torcherino:double_compressed_lanterino",
  "torcherino:lantern",
  "torcherino:compressed_lantern",
  "torcherino:double_compressed_lantern"
  // , "anothermod:xxx" 以后想加就放这里
]

// 通用处理函数
function handleSapling(event) {
  // 禁止放置
  event.block.set("minecraft:air")
  event.player.setStatusMessage(Text.translate("因致命bug所以禁止放置"))
  event.player.give(event.item) // 返还原物品

  // 检测范围 9x9x9
  let pos = event.block.pos
  let level = event.level

   for (let i = -9; i <= 9; i++) {
    for (let j = -9; j <= 9; j++) {
      for (let k = -9; k <= 9; k++) {
        if (i == 0 && j == 0 && k == 0) continue

        let checkPos = pos.offset(i, j, k)
        let block = level.getBlock(checkPos)

        // 如果发现表里定义的禁用方块
        if (forbiddenBlocks.includes(block.id)) {
          // 提示 + 播放音效
          event.server.runCommandSilent(`playsound minecraft:block.anvil.land block @a ${checkPos.x} ${checkPos.y} ${checkPos.z}`)

          // 返还对应物品
          event.player.give(block.id)

          // 删除该方块
          block.set("minecraft:air")
        }
      }
    }
  }
}

// 注册所有树苗监听器
saplings.forEach(id => {
  BlockEvents.placed(id, event => handleSapling(event))
})
*/


/*
 ServerEvents.recipes(event => {
 event.recipes.create.milling(
          [
            Item.of('minecraft:netherite_ingot').withChance(0.01), 
            Item.of('orecrop:netherite_nugget').withChance(0.10), 
            Item.of('minecraft:sugar_cane').withChance(0.60), 
          ],
          [
          Item.of('growable_ores:netherite_ingot_cane')
          ]
 ).processingTime(400);

 event.recipes.create.milling(
          [
            Item.of('minecraft:netherite_scrap').withChance(0.10), 
            Item.of('minecraft:sugar_cane').withChance(0.60), 
          ],
          [
          Item.of('growable_ores:netherite_scrap_cane')
          ]
 ).processingTime(400);

 event.recipes.create.milling(
          [
            Item.of('minecraft:glowstone_dust').withChance(0.50), 
            Item.of('minecraft:sugar_cane').withChance(0.60), 
          ],
          [
          Item.of('growable_ores:glowstone_cane')
          ]
 ).processingTime(400);
})
*/