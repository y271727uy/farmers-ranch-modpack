LootJS.modifiers((event) => {
    event
        .addEntityLootModifier("minecraft:vindicator") 
        .replaceLoot("minecraft:emerald", "mystias_izakaya:en_1");
    event
        .addEntityLootModifier("minecraft:pillager") 
        .replaceLoot("minecraft:emerald", "mystias_izakaya:en_1");
    
    event
        .addEntityLootModifier("minecraft:evoker") 
        .replaceLoot("minecraft:emerald", "mystias_izakaya:en_1");

    event
        .addBlockLootModifier('minecraft:grass')
        .removeLoot('createcafe:coffee_beans')
        .removeLoot('farmersdelight:tomato')
        .removeLoot('pizzacraft:pineapple_seeds')
        //.removeLoot()
        //.removeLoot()
        //.removeLoot()

});


LootJS.modifiers(event => {

    event.addLootTableModifier(/^(minecraft|lootr):chests\/.*/)
        .replaceLoot('muffins_thaidelight:lime_sapling', 'minecraft:air', false)
        //.replaceLoot('minecraft:potato', 'minecraft:diamond', true)  //测试用
        .replaceLoot('veggiesdelight:bellpepper_seeds', 'minecraft:air', false)
        .replaceLoot('ubesdelight:ginger', 'minecraft:air', false)
        .replaceLoot('veggiesdelight:garlic', 'minecraft:air', false)
        .replaceLoot('ubesdelight:garlic', 'minecraft:air', false)
        .replaceLoot('dumplings_delight:garlic', 'minecraft:air', false)
        .replaceLoot('muffins_thaidelight:lime_sapling', 'minecraft:air', false)
        .replaceLoot('veggiesdelight:bellpepper', 'minecraft:air', false)
        .replaceLoot('vintagedelight:cucumber_seeds', 'minecraft:air', false)
        //.replaceLoot(, 'minecraft:air', false)
        //.replaceLoot(, 'minecraft:air', false)


    
        
});//true保留原物品数量