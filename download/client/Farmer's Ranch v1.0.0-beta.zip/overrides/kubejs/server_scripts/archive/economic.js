// priority: 0
// Visit the wiki for more info - https://kubejs.com/

const $SDMShopR = Java.loadClass('net.sixik.sdmshoprework.SDMShopR')

ItemEvents.rightClicked('kubejs:mini_banker', event => {
    let player = event.player;
    let item = event.item;
    if (event.getHand() == "off_hand") {
        if (player.isShiftKeyDown()) {
            let inv = player.inventory.items
            let count = 0
            for (let i = 0; i < inv.length; i++) {
                let coincount = inv[i].getCount()
                switch (inv[i].getItem().toString()) {
                    case 'copper_gt_credit': //铜
                        count += coincount
                        inv[i].shrink(coincount);
                        break;
                    case 'cupronickel_gt_credit': //白铜
                        count += coincount * 2
                        inv[i].shrink(coincount);
                        break;
                    case 'silver_gt_credit': //银
                        count += coincount * 4
                        inv[i].shrink(coincount);
                        break;
                    case 'gold_gt_credit':  //金
                        count += coincount * 8
                        inv[i].shrink(coincount);
                        break;
                    case 'platinum_gt_credit': // 铂币
                        count += coincount * 16
                        inv[i].shrink(coincount);
                        break;
                    case 'osmium_gt_credit': // 锇币
                        count += coincount * 128
                        inv[i].shrink(coincount);
                        break;
                    case 'naquadah_gt_credit': // 硅岩币
                        count += coincount * 1024
                        inv[i].shrink(coincount);
                        break;
                    case 'neutronium_gt_credit': // 中子素币
                        count += coincount * 8192
                        inv[i].shrink(coincount);
                        break;
                    case 'doge_coin': // Dog币
                        count += coincount * 131072
                        inv[i].shrink(coincount);
                        break;
                }
            }

            // 将这些逻辑移到if语句内部，解决作用域问题
            if (count >= 131072) { // Dog币
                player.give(Item.of('list:doge_coin').withCount(parseInt(count / 131072)))
                count = count % 131072
            }
            if (count >= 8192) { // 中子素币
                player.give(Item.of('list:neutronium_gt_credit').withCount(parseInt(count / 8192)))
                count = count % 8192
            }
            if (count >= 1024) { // 硅岩币
                player.give(Item.of('list:naquadah_gt_credit').withCount(parseInt(count / 1024)))
                count = count % 1024
            }
            if (count >= 128) { // 锇币
                player.give(Item.of('list:osmium_gt_credit').withCount(parseInt(count / 128)))
                count = count % 128
            }
            if (count >= 16) { // 铂币
                player.give(Item.of('list:platinum_gt_credit').withCount(parseInt(count / 16)))
                count = count % 16
            }
            if (count >= 8) { // 金币
                player.give(Item.of('list:gold_gt_credit').withCount(parseInt(count / 8)))
                count = count % 8
            }
            if (count >= 4) { // 银币
                player.give(Item.of('list:silver_gt_credit').withCount(parseInt(count / 4)))
                count = count % 4
            }
            if (count >= 2) { // 白铜币
                player.give(Item.of('list:cupronickel_gt_credit').withCount(parseInt(count / 2)))
                count = count % 2
            }
            if (count >= 1) { // 铜币
                player.give(Item.of('list:copper_gt_credit').withCount(count))
            }
        }
    }
});

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    event.register(Commands.literal('bank-save')
        .executes(c => save(c.source.player))
    );

    let save = (player) => {
        if (player == null) return
        let inv = player.inventory.items
        let count = $SDMShopR.getMoney(player)
        for (let i = 0; i < inv.length; i++) {
            let coincount = inv[i].getCount()
            switch (inv[i].getItem().toString()) {
                case 'copper_gt_credit':
                    count += coincount
                    inv[i].shrink(coincount);
                    break;
                case 'cupronickel_gt_credit':
                    count += coincount * 2
                    inv[i].shrink(coincount);
                    break;
                case 'silver_gt_credit':
                    count += coincount * 4
                    inv[i].shrink(coincount);
                    break;
                case 'gold_gt_credit':
                    count += coincount * 8
                    inv[i].shrink(coincount);
                    break;
                case 'platinum_gt_credit':
                    count += coincount * 16
                    inv[i].shrink(coincount);
                    break;
                case 'osmium_gt_credit': // 锇币
                    count += coincount * 128
                    inv[i].shrink(coincount);
                    break;
                case 'naquadah_gt_credit': // 硅岩币
                    count += coincount * 1024
                    inv[i].shrink(coincount);
                    break;
                case 'neutronium_gt_credit': // 中子素币
                    count += coincount * 8192
                    inv[i].shrink(coincount);
                    break;
                case 'doge_coin': // Dog币
                    count += coincount * 131072
                    inv[i].shrink(coincount);
                    break;
            }
        }
        $SDMShopR.setMoney(player, count)
        player.setStatusMessage("当前余额：§6" + count)
        return 1;
    };

    event.register(Commands.literal('bank-extract')
        .executes(c => extract(c.source.player, -1))
        .then(Commands.argument("value", Arguments.INTEGER.create(event))
            .executes(c => extract(c.source.player, Arguments.INTEGER.getResult(c, "value")))
        )
    );

    let extract = (player, amount) => {
        let count = $SDMShopR.getMoney(player);
        if (amount < 0 || amount > count) {
            amount = count;
        }
        let originalAmount = amount;
        count -= amount;

        // 按照货币价值从高到低进行提取
        let dogeCoins = Math.floor(amount / 131072);
        if (dogeCoins > 0) {
            player.give(Item.of('list:doge_coin').withCount(dogeCoins));
            amount = amount % 131072;
        }

        let neutroniumCoins = Math.floor(amount / 8192);
        if (neutroniumCoins > 0) {
            player.give(Item.of('list:neutronium_gt_credit').withCount(neutroniumCoins));
            amount = amount % 8192;
        }

        let naquadahCoins = Math.floor(amount / 1024);
        if (naquadahCoins > 0) {
            player.give(Item.of('list:naquadah_gt_credit').withCount(naquadahCoins));
            amount = amount % 1024;
        }

        let osmiumCoins = Math.floor(amount / 128);
        if (osmiumCoins > 0) {
            player.give(Item.of('list:osmium_gt_credit').withCount(osmiumCoins));
            amount = amount % 128;
        }

        let platinumCoins = Math.floor(amount / 16);
        if (platinumCoins > 0) {
            player.give(Item.of('list:platinum_gt_credit').withCount(platinumCoins));
            amount = amount % 16;
        }

        let goldCoins = Math.floor(amount / 8);
        if (goldCoins > 0) {
            player.give(Item.of('list:gold_gt_credit').withCount(goldCoins));
            amount = amount % 8;
        }

        let silverCoins = Math.floor(amount / 4);
        if (silverCoins > 0) {
            player.give(Item.of('list:silver_gt_credit').withCount(silverCoins));
            amount = amount % 4;
        }

        let cupronickelCoins = Math.floor(amount / 2);
        if (cupronickelCoins > 0) {
            player.give(Item.of('list:cupronickel_gt_credit').withCount(cupronickelCoins));
            amount = amount % 2;
        }

        let copperCoins = amount; // 剩余的就是铜币
        if (copperCoins > 0) {
            player.give(Item.of('list:copper_gt_credit').withCount(copperCoins));
        }

        $SDMShopR.setMoney(player, count)
        player.setStatusMessage([Text.translate("message.kubejs.balance"), Text.of(count).gold()]);
        return 1;
    };
});

/*
GT币兑换比例：
铜币:白铜币 2:1
白铜币:银币 2:1
银币:金币 2:1
金币:铂币 2:1
铂币:锇币 8:1
锇币:硅岩币 8:1
硅岩币:中子素币 8:1
中子素币:dog币 16:1  
*/