ServerEvents.recipes(event => {
//event.remove({id: ''})
event.remove({id: 'braziliandelight:coffee_seeds'})
event.remove({id: 'youkaishomecoming:green_coffee_bean'})
event.remove({id: 'youkaishomecoming:coffee_berries_cutting'})
event.remove({id: 'manors_bounty:coffee_beans_recipe_2'})
event.remove({id: 'manors_bounty:coffee_beans_recipe'})
event.remove({id: 'manors_bounty:coffee_beans_recipe_3'})
event.remove({id: 'coffee_delight:cutting/coffee_beans'})
event.remove({id: 'coffee_delight:coffee_beans'})
event.remove({id: 'braziliandelight:coffee_beans_bag_to_materials'})
event.remove({id: 'braziliandelight:coffee_beans_smoking'})
event.remove({id: 'braziliandelight:coffee_beans_smelting'})
event.remove({id: 'braziliandelight:coffee_beans_campfire'})
event.remove({id: 'youkaishomecoming:coffee_beans_from_coffee_bean_bag'})
event.remove({id: 'youkaishomecoming:coffee_beans_from_green_coffee_bean_smoking'})
event.remove({id: 'youkaishomecoming:coffee_beans_from_green_coffee_bean_smelting'})
event.remove({id: 'farmersrespite:cutting/coffee_berries'})
event.remove({id: 'farmersrespite:coffee_beans'})
event.remove({id: 'rusticdelight:coffee_beans_from_coffee_beans_bag'})
event.remove({id: 'rusticdelight:wild_coffee'})
event.remove({id: 'createcafe:crushing/coffee_crushing'})
event.remove({id: 'createcafe:milling/coffee_milling'})
//event.remove({id: ''})
//event.remove({id: ''})
//event.remove({id: ''})
//event.remove({id: ''})
//event.remove({id: ''})
//event.remove({id: ''})

event.shaped(
      Item.of('braziliandelight:coffee_seeds', 2),  
      [
        'A  ',
        '   ',
        '   '
      ],
      {
        A: Ingredient.of('#fabric:neo_coffe_berrise_tag', 1)
      }
    )

event.shaped(
      Item.of('braziliandelight:coffee_seeds', 2),  
      [
        'A  ',
        '   ',
        '   '
      ],
      {
        A: 'manors_bounty:coffee_berry'
      }
    )

event.smelting('braziliandelight:coffee_beans', 'braziliandelight:coffee_seeds')
event.smoking('braziliandelight:coffee_beans', 'braziliandelight:coffee_seeds').xp(0.35)

});

ServerEvents.tags('item', event => {
    event.add('fabric:neo_coffe_berrise_tag', 'youkaishomecoming:coffee_berries'); 
    event.add('fabric:neo_coffe_berrise_tag', 'farmersrespite:coffee_berries');
    event.add('fabric:neo_coffe_berrise_tag', 'createcafe:coffee_fruit');
    event.add('fabric:neo_coffe_berrise_tag', 'coffee_delight:coffee_berries');
    event.add('fabric:neo_coffe_berrise_tag', 'braziliandelight:coffee_berries');
    event.add('fabric:neo_coffe_berrise_tag', 'manors_bounty:coffee_berry');
});