ServerEvents.recipes(event => {
//配方坟场
//event.remove({id: ''})
    event.remove({type: 'manors_bounty_machine:cutting_board'})
    event.remove({type: 'manors_bounty_machine:stock_pot'})
    event.remove({type: 'manors_bounty_machine:fryer'})
    event.remove({type: 'manors_bounty:cutting_board'})
    event.remove({id: 'gourmet:butter'})
    event.remove({id: 'youkaishomecoming:butter'})
    event.remove({id: 'braziliandelight:crafting_shapeless/butter'})
    event.remove({id: 'alcocraftplus:spruce_mug'})
    event.remove({id: 'yeastnfeast:tankard'})
    event.remove({id: 'brewinandchewin:cooking/apple_jelly'})
    event.remove({id: 'farmersdelight:cooking/apple_jelly'})
    event.remove({id: 'vintagedelight:cooking/apple_sauce_jar'})
    event.remove({id: 'farmersdelight:cooking/apple_jam'})

    event.remove({id: 'yeastnfeast:thornberry_mead_from_keg'})
    event.remove({id: 'yeastnfeast:blossom_mead_from_keg'})
    event.remove({id: 'yeastnfeast:amber_mead_from_keg'})
    event.remove({id: 'yeastnfeast:honey_mead_from_keg'})
    event.remove({id: 'yeastnfeast:sour_mead_from_keg'})
    event.remove({id: 'yeastnfeast:molasses_mead_from_keg'})

    event.remove({id: 'yeastnfeast:golden_apple_jam_from_keg'})
    event.remove({id: 'yeastnfeast:elderberries_jam_from_keg'})
    event.remove({id: 'farmersdelight:cooking/chorus_jelly'})
    event.remove({id: 'farmersdelight:cooking/sweet_berry_jam'})
    event.remove({id: 'farmersdelight:cooking/sweetberry_jelly'})
    event.remove({id: 'farmersdelight:cooking/glow_berry_jam'})
    event.remove({id: 'farmersdelight:cooking/glowberry_jelly'})
    event.remove({id: 'farmersdelight:cooking/lemon_jelly'})
    event.remove({id: 'farmersdelight:cooking/melon_jelly'})
    event.remove({id: 'farmersdelight:cooking/melon_jam'})
    event.remove({id: 'farmersdelight:cooking/hawberry_jelly'})
    event.remove({id: 'yeastnfeast:hawthorn_berries_jam_from_keg'})
    event.remove({id: 'farmersdelight:cooking/blueberry_jam'})
    event.remove({id: 'farmersdelight:cooking/blueberry_jelly'})
    event.remove({id: 'yeastnfeast:rose_hips_jam_from_keg'})
    event.remove({id: 'seeddelight:cooking/rosehip_jam_jar'})
    event.remove({id: 'yeastnfeast:apple_jam_from_keg'})
    event.remove({id: 'yeastnfeast:melon_jam_from_keg'})
    event.remove({id: 'yeastnfeast:lemon_jam_from_keg'})
    event.remove({id: 'yeastnfeast:chorus_fruit_jam_from_keg'})
    event.remove({id: 'yeastnfeast:sweet_berries_jam_from_keg'})
    event.remove({id: 'yeastnfeast:glow_berries_jam_from_keg'})
    event.remove({id: 'farmersdelight:cooking/hamimelon_jelly'})
    event.remove({id: 'farmersdelight:cooking/lychee_jelly'})
    event.remove({id: 'farmersdelight:cooking/mango_jelly'})
    event.remove({id: 'farmersdelight:cooking/orange_jelly'})
    event.remove({id: 'farmersdelight:cooking/peach_jelly'})
    event.remove({id: 'farmersdelight:cooking/pear_jelly'})
    event.remove({id: 'farmersdelight:cooking/persimmon_jelly'})
    event.remove({id: 'farmersdelight:cooking/pineapple_jelly'})
    event.remove({id: 'farmersdelight:cooking/cranberry_jelly'})
    event.remove({id: 'farmersdelight:cooking/mangosteen_jelly'})
    event.remove({id: 'farmersdelight:cooking/bayberry_jelly'})
    event.remove({id: 'farmersdelight:cooking/kiwi_jelly'})
    event.remove({id: 'farmersdelight:cooking/fig_jelly'})
    event.remove({id: 'farmersdelight:cooking/durian_jelly'})
    event.remove({id: 'farmersdelight:cooking/raspberry_jam'})
    event.remove({id: 'farmersdelight:cooking/grape_jam'})
    event.remove({id: 'vintagedelight:cooking/gearo_berry_jam_jar'})
    event.remove({id: 'immortalers_delight:cooking/himekaido_jelly'})
    event.remove({id: 'seeddelight:cooking/cherry_jam_jar'})
    event.remove({id: 'brewinandchewin:fermenting/beer_from_water'})

    // 移除 hearthandharvest 物品的配方
    event.remove({id: 'hearthandharvest:aging/red_grape_wine'})
    event.remove({id: 'hearthandharvest:aging/mead'})
    event.remove({id: 'hearthandharvest:aging/green_grape_wine'})
    event.remove({id: 'hearthandharvest:aging/raspberry_wine'})
    event.remove({id: 'hearthandharvest:aging/blueberry_wine'})
    event.remove({id: 'hearthandharvest:aging/cherry_wine'})
    event.remove({id: 'hearthandharvest:aging/cheddar_cheese_wheel'})
    event.remove({id: 'hearthandharvest:aging/goat_cheese_wheel'})
    event.remove({id: 'hearthandharvest:drying/jerky'})
    event.remove({id: 'hearthandharvest:pickling/pickled_carrots'})
    event.remove({id: 'hearthandharvest:pickling/pickled_potatoes'})
    event.remove({id: 'hearthandharvest:pickling/pickled_cabbage'})

    event.remove({id: 'alcocraftplus:wither_stout'})
    event.remove({id: 'alcocraftplus:night_rauch'})
    event.remove({id: 'alcocraftplus:digger_bitter'})
    event.remove({id: 'alcocraftplus:nether_star_lager'})
    event.remove({id: 'alcocraftplus:nether_porter'})
    event.remove({id: 'alcocraftplus:magnet_pilsner'})
    event.remove({id: 'alcocraftplus:leprechaun_cider'})
    event.remove({id: 'alcocraftplus:ice_beer'})
    event.remove({id: 'alcocraftplus:drowned_ale'})
    event.remove({id: 'cocraftplus:sun_pale_ale'})
	  event.remove({id: 'alcocraftplus:kvass'})
	  event.remove({id: 'alcocraftplus:chorus_ale'})
	  event.remove({id: 'alcocraftplus:wither_stout'})
	  event.remove({id: 'alcocraftplus:night_rauch'})
	  event.remove({id: 'alcocraftplus:digger_bitter'})
	  event.remove({id: 'alcocraftplus:nether_star_lager'})
	  event.remove({id: 'alcocraftplus:nether_porter'})
	  event.remove({id: 'alcocraftplus:magnet_pilsner'})
	  event.remove({id: 'alcocraftplus:leprechaun_cider'})
	  event.remove({id: 'alcocraftplus:ice_beer'})
	  event.remove({id: 'alcocraftplus:drowned_ale'})
	  event.remove({id: 'alcocraftplus:sun_pale_ale'})
	  event.remove({id: 'alcocraftplus:kvass'})
	  event.remove({id: 'alcocraftplus:chorus_ale'})

    event.remove({id: 'some_assembly_required:cutting/farmersdelight/tomato_slices'})
    event.remove({id: 'some_assembly_required:cutting/create/tomato_slices'})
    event.remove({id: 'pizzacraft:farmersdelight/tomato'})

    //event.remove({id: ''})
    event.remove({id: 'hearthandharvest:aging/pickled_carrots'})
    event.remove({id: 'hearthandharvest:aging/jerky'})
    event.remove({id: 'hearthandharvest:aging/pickled_potatoes'})
    event.remove({id: 'hearthandharvest:aging/pickled_onions'})
    event.remove({id: 'hearthandharvest:aging/pickled_cabbage'})
    event.remove({id: 'hearthandharvest:aging/pickled_beetroots'})
    event.remove({id: 'hearthandharvest:aging/sweet_berry_wine'})

    //event.remove({id: _fermenter_recipe'})
    event.remove({id: 'manors_bounty:caviar_fermenter_recipe'})
    event.remove({id: 'manors_bounty:yogurt_fermenter_recipe'})
    event.remove({id: 'manors_bounty:white_wine_fermenter_recipe'})
    event.remove({id: 'manors_bounty:red_wine_fermenter_recipe'})
    event.remove({id: 'manors_bounty:gin_fermenter_recipe'})
    event.remove({id: 'manors_bounty:rum_fermenter_recipe'})
    event.remove({id: 'manors_bounty:sake_fermenter_recipe'})
    event.remove({id: 'manors_bounty:beer_fermenter_recipe'})
    event.remove({id: 'manors_bounty:whiskey_fermenter_recipe'})
    event.remove({id: 'manors_bounty:absinthe_fermenter_recipe'})
    event.remove({id: 'manors_bounty:rice_vinegar_fermenter_recipe'})
    event.remove({id: 'manors_bounty:vodka_fermenter_recipe'})
    event.remove({id: 'manors_bounty:champagne_fermenter_recipe'})
    event.remove({id: 'manors_bounty:chamoy_fermenter_recipe'})
    event.remove({id: 'manors_bounty:brandy_fermenter_recipe'})
    event.remove({id: 'manors_bounty:umeshu_fermenter_recipe'})
    event.remove({id: 'manors_bounty:starfruit_wine_fermenter_recipe'})
    event.remove({id: 'manors_bounty:kvass_fermenter_recipe'})
    event.remove({id: 'manors_bounty:creme_de_cassis_fermenter_recipe'})
    event.remove({id: 'manors_bounty:dried_apricot_fermenter_recipe'})
    event.remove({id: 'manors_bounty:suspicious_mold_fermenter_recipe'})
    event.remove({id: 'manors_bounty:nata_de_coco_fermenter_recipe'})
    event.remove({id: 'manors_bounty:stuffed_olive_fermenter_recipe'})
    event.remove({id: 'manors_bounty:umeboshi_fermenter_recipe'})
    event.remove({id: 'manors_bounty:pickle_fermenter_recipe'})
    event.remove({id: 'manors_bounty:black_tea_leaves_fermenter_recipe'})
    event.remove({id: 'manors_bounty:prune_fermenter_recipe'})
    event.remove({id: 'manors_bounty:floral_kombucha_fermenter_recipe'})
    event.remove({id: 'manors_bounty:kombucha_fermenter_recipe'})
    event.remove({id: 'manors_bounty:cheddar_cheese_wheel_fermenter_recipe'})
    event.remove({id: 'manors_bounty:emmental_cheese_wheel_fermenter_recipe'})
    event.remove({id: 'manors_bounty:mozzarella_cheese_wheel_fermenter_recipe'})
    event.remove({id: 'manors_bounty:cream_cheese_fermenter_recipe'})
    event.remove({id: 'manors_bounty:mentaiko_fermenter_recipe'})
    event.remove({id: 'manors_bounty:fruit_flavored_kombucha_fermenter_recipe'})
    event.remove({id: 'manors_bounty:canton_bloom_soup_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:cream_with_mushroom_soup_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:borscht_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:prawn_and_corn_soup_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:suanmeitang_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:olive_oil_bucket_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:salt_shaker_stock_pot_recipe'})
    event.remove({id: 'manors_bounty:raw_mallard_duck_cutting_recipe'})
    event.remove({id: 'manors_bounty:raw_bresse_chicken_cutting_recipe'})
    //event.remove({id: ''})
    event.remove({id: 'manors_bounty:mango_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:avocado_half_cutting_recipe'})
    event.remove({id: 'manors_bounty:pear_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:apple_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:banana_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pineapple_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:starfruit_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:plum_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:peach_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pomegranate_wedge_cutting_recipe'})
    event.remove({id: 'manors_bounty:hawthorn_flakes_recipe'})
    event.remove({id: 'manors_bounty:durian_half_cutting_recipe'})
    event.remove({id: 'manors_bounty:durian_flesh_cutting_recipe'})
    event.remove({id: 'manors_bounty:yuzumelo_wedge_cutting_recipe'})
    event.remove({id: 'manors_bounty:banana_cutting_recipe'})
    event.remove({id: 'manors_bounty:banana_frond_sapling_cutting_recipe'})
    event.remove({id: 'manors_bounty:hamimelon_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:green_apple_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:golden_apple_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:enchanted_golden_apple_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:orange_segment_cutting_recipe'})
    event.remove({id: 'manors_bounty:grapefruit_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:lemon_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:lime_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:melon_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:kiwifruit_half_cutting_recipe'})
    event.remove({id: 'manors_bounty:kiwifruit_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:gold_kiwifruit_half_cutting_recipe'})
    event.remove({id: 'manors_bounty:gold_kiwifruit_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:avocado_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:fig_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:coconut_cutting_recipe'})
    event.remove({id: 'manors_bounty:coconut_half_cutting_recipe'})
    event.remove({id: 'manors_bounty:coconut_meat_cutting_recipe'})
    event.remove({id: 'manors_bounty:cucumber_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pumpkin_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:raw_rice_cutting_recipe'})
    event.remove({id: 'manors_bounty:tomato_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:raw_beef_cubes_cutting_recipe'})
    event.remove({id: 'manors_bounty:cooked_beef_cubes_cutting_recipe'})
    event.remove({id: 'manors_bounty:raw_mutton_ribs_cutting_recipe'})
    event.remove({id: 'manors_bounty:cooked_mutton_ribs_cutting_recipe'})
    event.remove({id: 'manors_bounty:carrot_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:end_pepper_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pimento_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:green_bell_pepper_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:wild_jalapeno_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:jalapeno_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:passion_fruit_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pomegranate_seed_cutting_recipe'})
    event.remove({id: 'manors_bounty:dragon_fruit_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:grated_coconut_cutting_recipe'})
    event.remove({id: 'manors_bounty:spam_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:cheddar_cheese_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:cheddar_cheese_wedge_cutting_recipe'})
    event.remove({id: 'manors_bounty:emmental_cheese_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:emmental_cheese_wedge_cutting_recipe'})
    event.remove({id: 'manors_bounty:pickle_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:cheesy_mushroom_bacon_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:hawaiian_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:durian_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:seafood_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:supreme_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pepperoni_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:vanilla_pizza_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:sandwich_bread_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:swiss_roll_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:durian_mile_crepe_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:truffle_pie_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:cherries_pie_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:mozzarella_cheese_wedge_cutting_recipe'})
    event.remove({id: 'manors_bounty:mozzarella_cheese_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:strawberry_shortcake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:pavlova_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:chorus_flower_jelly_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:nether_wart_soul_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:sweet_berry_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:caramel_chocolate_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:vanilla_cake_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:corn_chips_cutting_recipe'})
    event.remove({id: 'manors_bounty:dark_chocolate_chips_cutting_recipe'})
    event.remove({id: 'manors_bounty:chocolate_chips_cutting_recipe'})
    event.remove({id: 'manors_bounty:white_chocolate_chips_cutting_recipe'})
    event.remove({id: 'manors_bounty:ice_cube_cutting_recipe'})
    event.remove({id: 'manors_bounty:rose_cutting_recipe'})
    event.remove({id: 'manors_bounty:sakura_cutting_recipe'})
    event.remove({id: 'manors_bounty:beetroot_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:potato_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:raw_pork_belly_cutting_recipe'})
    event.remove({id: 'manors_bounty:bacon_cutting_recipe'})
    event.remove({id: 'manors_bounty:fugu_slice_cutting_recipe'})
    //event.remove({id: ''})
    event.remove({id: 'manors_bounty:tropical_fish_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:raw_cod_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:salmon_slice_cutting_recipe'})
    event.remove({id: 'manors_bounty:chicken_cutting_recipe'})
    event.remove({id: 'manors_bounty:cooked_chicken_cutting_recipe'})
    event.remove({id: 'manors_bounty:fried_chicken_cutting_recipe'})
    event.remove({id: 'manors_bounty:mochi_cutting_recipe'})
    event.remove({id: 'manors_bounty:dough_cutting_recipe'})
    event.remove({id: 'manors_bounty:corn_dough_cutting_recipe'})
    event.remove({id: 'manors_bounty:cooked_peanut_recipe'})
    event.remove({id: 'manors_bounty:cooked_peanut_recipe_2'})
    event.remove({id: 'manors_bounty:cooked_peanut_recipe_3'})
    event.remove({id: 'manors_bounty:surimi_crab_stick_cutting_recipe'})
    
    event.remove({id: 'farmersdelight:cutting/pufferfish'})
    event.remove({id: 'oceansdelight:cutting/pufferfish'})
    event.remove({id: 'farmersdelight:cutting/cod'})
    event.remove({id: 'farmersdelight:cutting/tropical_fish'})
    event.remove({id: 'pizzacraft:wing'})
    event.remove({id: 'pizzacraft:farmersdelight/chicken'})
    event.remove({id: 'farmersdelight:cutting/chicken'})
    event.remove({id: 'seeddelight:cutting/rosehip'})
    event.remove({id: 'farmersrespite:cutting/rose_bush'})
    event.remove({id: 'trailandtales_delight:cutting/cherry_petal_from_cherry_leaves'})
    event.remove({id: 'nethers_exoticism:cut_pitaya_recipe'})
    event.remove({id: 'collectorsreap:cutting/pink_dragon_fruit'})
    event.remove({id: 'culturaldelights:palta_cortada1'})
    event.remove({id: 'culturaldelights:palta_cortada2'})
    event.remove({id: 'peruviansdelight:cortar/palta_cortada'})
    event.remove({id: 'peruviansdelight:cortar/gajo_limon'})
    event.remove({id: 'immortalers_delight:cutting/mashed_potatoes'})

    event.remove({id: 'farmersdelight:cooking/mango_jam'})
    event.remove({id: 'farmersdelight:cutting/starfruit'})
    event.remove({id: 'farmersdelight:cutting/grapefruit'})
    event.remove({id: 'pizzacraft:cooked_wing_chopping'})

    //event.remove({id: ''})
    event.remove({id: 'extravagantdelight:crafting/mango_cake'})
    event.remove({id: 'extravagantdelight:crafting/mango_popsicle_neapolitan'})
    event.remove({id: 'extravagantdelight:crafting/mango_popsicle_double'})
    event.remove({id: 'hearthandharvest:aging/pickled_mangoes'})
    event.remove({id: 'extravagantdelight:crafting/mango_salad'})
    event.remove({id: 'extravagantdelight:crafting/tropical_pizza'})

    event.remove({id: 'alexsmobsdelight:cutting/banana_slice'})
    event.remove({id: 'hearthandharvest:aging/grapefruit_wine'})
    event.remove({id: 'hearthandharvest:aging/mango_wine'})
    event.remove({id: 'hearthandharvest:aging/quince_wine'})
    event.remove({id: 'hearthandharvest:aging/starfruit_wine'})
    event.remove({id: 'hearthandharvest:aging/muscadine_wine'})
    event.remove({id: 'hearthandharvest:aging/sloe_berry_wine'})
    event.remove({id: 'hearthandharvest:aging/rhubarb_wine'})
    event.remove({id: 'hearthandharvest:aging/pickled_muscadine_grapes'})
    event.remove({id: 'hearthandharvest:aging/pickled_rhubarb'})
    event.remove({id: 'hearthandharvest:aging/pickled_hops'})
    event.remove({id: 'botanypots:botanypots/crafting/terracotta_hopper_botany_pot'})
    event.remove({id: 'botanypots:botanypots/crafting/terracotta_compact_hopper_botany_pot'})

    event.remove({id: 'casualness_delight:cutting/diced_potatoes'})
    event.remove({id: 'moredelight:papetas1'})
    event.remove({id: 'moredelight:cutting/diced_potatoes'})
    event.remove({id: 'create:diced_potatoes'})
    event.remove({id: 'moredelight:papetas2'})
    event.remove({id: 'casualnessdelight:papas_cortadas2'})
    event.remove({id: 'peruviansdelight:cortar/papas_cortadas'})
    event.remove({id: 'youkaishomecoming:cucumber_cutting'})
    event.remove({id: 'vintagedelight:cutting/cucumber_cutting'})
    event.remove({id: 'delightful:cutting/raw_venison'})
    event.remove({id: 'manors_bounty:tea_leaves_from_camelia_recipe'})
    event.remove({id: 'youkaishomecoming:tea_leaves_from_tea_leaf_bag'})
    event.remove({id: 'manors_bounty:green_tea_leaves_recipe_2'})
    event.remove({id: 'manors_bounty:green_tea_leaves_recipe_3'})
    event.remove({id: 'manors_bounty:green_tea_leaves_recipe'})
    event.remove({id: 'manors_bounty:fries_fryer_slow_recipe'})
    event.remove({id: 'manors_bounty:fries_fryer_fast_recipe'})

    event.remove({id: 'oddsnends:peeled_mandrake'})
    event.remove({id: 'oddsnends:peeled_mandrake_from_crate'})
    event.remove({id: 'dungeonsdelight:soft_serve_sniffer_egg_from_smoking'})
    event.remove({id: 'create:empty_meadow_wooden_grain_milk_bucket_of_minecraft_milk'})

    event.remove({id: 'manors_bounty:pineapple_pies_fryer_fast_recipe'})
    event.remove({id: 'manors_bounty:pineapple_pies_fryer_slow_recipe'})

    //event.remove({id: ''})
    event.remove({id: 'meadow:cooking_pot/roasted_ham'})
    event.remove({id: 'meadow:cooking_pot/rennet'})
    event.remove({id: 'meadow:cooking_pot/ham_cheese'})
    event.remove({id: 'meadow:cooking_pot/rabbit_stew_from_cheese'})
    event.remove({id: 'meadow:cooking_pot/beetroot_soup'})
    event.remove({id: 'meadow:cooking_pot/leather'})
    event.remove({id: 'meadow:cooking_pot/grain_milk'})
    event.remove({id: 'meadow:cooking_pot/amethyst_milk'})
    event.remove({id: 'meadow:cooking_pot/alpine_salt_from_calcite'})
    event.remove({id: 'meadow:cooking_pot/alpine_salt_from_limestone'})
    event.remove({id: 'meadow:cooking_pot/cooked_cod'})
    event.remove({id: 'meadow:cooking_pot/cooked_buffalo_meat'})
    event.remove({id: 'meadow:cooking_pot/cooked_salmon'})
    event.remove({id: 'meadow:cooking_pot/cooked_porkchop'})
    event.remove({id: 'meadow:cooking_pot/cooked_beef'})
    event.remove({id: 'meadow:cooking_pot/cooked_chicken'})
    event.remove({id: 'meadow:cooking_pot/cooked_rabbit'})
    event.remove({id: 'meadow:cooking_pot/cooked_mutton'})
    event.remove({id: 'meadow:cooking_pot/baked_potato'})

    event.remove({id: 'ltc2:ae_compat/refined_salt'})
    event.remove({id: 'ltc2:milling/refined_salt'})
    event.remove({id: 'ltc2:create/milling/refined_salt'})
    event.remove({id: 'ltc2:crafting/shapeless/refined_salt'})
    event.remove({id: 'ltc2:crafting/shaped/refined_salt_from_block'})

    //event.remove({id: ''})
    event.remove({id: 'farm_and_charm:oat_seeds'})
    
    event.remove({id: 'farm_and_charm:pot_cooking/potato_soup'})
    event.remove({id: 'farm_and_charm:pot_cooking/corn_grits'})
    event.remove({id: 'farm_and_charm:pot_cooking/barley_soup'})
    event.remove({id: 'farm_and_charm:pot_cooking/nettle_tea'})
    event.remove({id: 'farm_and_charm:pot_cooking/ribwort_tea'})
    event.remove({id: 'farm_and_charm:pot_cooking/onion_soup'})
    event.remove({id: 'farm_and_charm:pot_cooking/simple_tomato_soup'})
    event.remove({id: 'farm_and_charm:pot_cooking/goulash'})
    event.remove({id: 'farm_and_charm:pot_cooking/strawberry_tea'})
    //event.remove({id: ''})
    event.remove({id: 'farm_and_charm:roaster/beef_patty_with_vegetables'})
    event.remove({id: 'farm_and_charm:roaster/lamb_with_corn'})
    event.remove({id: 'farm_and_charm:roaster/oat_pancake'})
    event.remove({id: 'farm_and_charm:roaster/barley_patties_with_potatoes'})
    event.remove({id: 'farm_and_charm:roaster/cooked_salmon'})
    event.remove({id: 'farm_and_charm:roaster/cooked_cod'})
    event.remove({id: 'farm_and_charm:roaster/chicken_wrapped_in_bacon'})
    event.remove({id: 'farm_and_charm:roaster/bacon_with_eggs'})
    event.remove({id: 'farm_and_charm:roaster/sausage_with_oat_patty'})
    
    event.remove({id: 'argentinas_delight:batatacampfire'})

    event.remove({id: 'culturaldelights:corn_dough'})
    event.remove({id: 'alexsmobsdelight:campfire_cooking/cooked_bear_meat_slice'})
    event.remove({id: 'alexsmobsdelight:cutting/cooked_bear_meat_slice'})
    event.remove({id: 'alexsmobsdelight:cutting/raw_bear_meat_slice'})
    event.remove({id: 'peruviansdelight:coocked/camote_cocido'})
    event.remove({id: 'peruviansdelight:coocked/camote_cocido_hoguera'})
    event.remove({id: 'peruviansdelight:coocked/camote_cocido_ahumador'})
    //event.remove({id: ''})
    //event.remove({id: ''})
    //event.remove({id: ''})
    //event.remove({id: ''})


    event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'cosmopolitan:fiddlehead' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'kubejs:fiddlefern',  //输出
          count: 1,
          chance: 1.0
        }
      ]
    });
    
    
    event.shaped(
      Item.of('some_assembly_required:burger_bun', 10),  
      [
        'AAB',
        'CDE',
        '   '
      ],
      {
        A: 'create:wheat_flour',
        B: 'braziliandelight:butter',
        C:  Ingredient.of('#forge:milk', 1), 
        D: 'minecraft:sugar' ,
        E: Ingredient.of('#forge:eggs', 1)  
      }
    )
  //俺寻思这没错啊
event.shapeless(
  Item.of('manors_bounty:banana_frond', 1),
  [
    'neapolitan:banana_frond',
  ]
)

event.shapeless(
  Item.of('neapolitan:banana_frond', 1),
  [
    'manors_bounty:banana_frond',
  ]
)

event.remove({ output: 'some_assembly_required:burger_bun' })

event.shaped(
      Item.of('vintagedelight:salt_dust', 2),  
      [
        '  A',
        ' B ',
        '   '
      ],
      {
        A: 'meadow:alpine_salt',
        B: Item.of('ltc2:mortar', '{Damage:0}') 
      }
    )

event.shaped(
      Item.of('meadow:fondue', 1),  
      [
        ' A ',
        'BBB',
        'B B'
      ],
      {
        A: 'farmersdelight:cooking_pot',
        B: 'minecraft:iron_ingot'
      }
    )

event.shaped(
      Item.of('argentinas_delight:postre_vigilantebatata', 1),  
      [
        ' A ',
        ' B ',
        '   '
      ],
      {
        A: Ingredient.of('#forge:cheese', 1),
        B: 'argentinas_delight:dulcebatatabloque'
      }
    )

event.shaped(
      Item.of('argentinas_delight:postrevigilantemembrillo', 1),  
      [
        ' A ',
        ' B ',
        '   '
      ],
      {
        A: Ingredient.of('#forge:cheese', 1),
        B: 'argentinas_delight:membrillobloque'
      }
    )
  /*
    event.custom({
        type: 'farmersdelight:cutting',
        ingredients: [
          { item: 'wildernature:venison' }   //输入
        ],
        tool: {
          tag: 'forge:tools/knives'   //工具
        },
        result: [
          {
            item: 'delightful:venison_chops',  //输出
            count: 2,
            chance: 1.0
          }
        ]
      });
    */

    event.recipes.farmersdelight.cooking(
    ['braziliandelight:heavy_cream_bucket', '#forge:salt'],
    Item.of('braziliandelight:butter', 4),  // 修正：使用Item.of()方法指定数量
    50, // 经验
    10  // 烹饪时间（tick）
    // 如果需要容器，可以在这里添加
);

event.remove({id: 'pizzacraft:farmersdelight/onion'})
event.remove({id: 'spanishdelight:cutting/onion'})

event.recipes.farmersdelight.cooking(
    ['kubejs:human_bones', '#forge:crops/mushroom'],
    Item.of('kubejs:suspicious_bone_broth', 1),  // 修正：使用Item.of()方法指定数量
    50, // 经验
    300,  // 烹饪时间（tick）
    'minecraft:bowl' // 如果需要容器，可以在这里添加
);

event.shaped(
      Item.of('kubejs:suspicious_roasted_mutton_chops', 1),  
      [
        'AFB',
        'CDE',
        '   '
      ],
      {
        A: 'farmersdelight:cooked_mutton_chops',
        B: 'minecraft:beetroot',
        C: 'minecraft:bowl', 
        D: 'farmersdelight:cooked_rice',
        E:  Ingredient.of('#forge:crops/tomato', 1),
        F: 'kubejs:raw_human_organ_meat'
      }
    )

event.shaped(
      Item.of('extravagantdelight:mango_salad', 1),  
      [
        'AAB',
        'CDD',
        'E  '
      ],
      {
        A: Ingredient.of('#modpack:mango_slice', 1),
        B: 'extravagantdelight:pickled_mangoes',
        C: Ingredient.of('#modpack:cheese', 1),
        D: Ingredient.of('#forge:crops/cabbage', 1),
        E: 'minecraft:bowl'
      }
    )

event.shaped(
      Item.of('hearthandharvest:peanut_butter_pie', 1),  
      [
        'AAA',
        'BBB',
        'CDC'
      ],
      {
        A: 'minecraft:wheat',
        B: 'manors_bounty:cooked_peanut',
        C: 'minecraft:sugar', 
        D: 'farmersdelight:pie_crust'
      }
    )

event.shaped(
      Item.of('extravagantdelight:mango_cake', 1),  
      [
        'ABA',
        'CDC',
        'EEE'
      ],
      {
        A: 'fruitsdelight:mango_jelly',
        B: Ingredient.of('#modpack:mango',1),
        C: Ingredient.of('#forge:milk/milk',1),
        D: 'minecraft:egg',
        E: 'minecraft:wheat'
      }
    )


event.shaped(
      Item.of('kubejs:suspicious_steak_and_potatoes', 1),  
      [
        'AFB',
        'CDE',
        '   '
      ],
      {
        A: 'minecraft:cooked_beef',
        B: 'minecraft:bowl', 
        C:  Ingredient.of('#forge:crops/onion', 1), 
        D: 'farmersdelight:cooked_rice',
        E: 'kubejs:raw_human_organ_meat',
        F: 'minecraft:baked_potato'
      }
    )

event.recipes.farmersdelight.cooking(
    ['kubejs:raw_human_organ_meat', '#forge:pasta','farmersdelight:tomato_sauce'],
    Item.of('kubejs:suspicious_pasta_with_meatballs', 1),  // 修正：使用Item.of()方法指定数量
    50, // 经验
    300,  // 烹饪时间（tick）
    'minecraft:bowl' // 如果需要容器，可以在这里添加

)

event.shaped(
      Item.of('extravagantdelight:mango_popsicle_double', 1),  
      [
        ' AA',
        'BAA',
        'CB '
      ],
      {
        A: Ingredient.of('#modpack:mango', 1),
        B: 'neapolitan:ice_cubes', 
        C: 'minecraft:stick' 
      }
    )

event.shaped(
      Item.of('extravagantdelight:mango_popsicle', 1),  
      [
        ' AA',
        'BAA',
        'CB '
      ],
      {
        A: Ingredient.of('#modpack:mango_slice', 1),
        B: 'neapolitan:ice_cubes', 
        C: 'minecraft:stick' 
      }
    )

event.shaped(
      Item.of('kubejs:suspicious_barbecue_stick', 1),  
      [
        'AB ',
        'CD ',
        '   '
      ],
      {
        A: 'kubejs:raw_man_meat',
        B: 'minecraft:stick', 
        C:  Ingredient.of('#forge:crops/onion', 1), 
        D:  Ingredient.of('#dumplings_delight:tomato', 1)
  
      }
    )

    event.shaped(
      Item.of('createcafe:mana_berries', 1),  
      [
        ' A ',
        ' B ',
        '   '
      ],
      {
        A: 'unusual_delight:magic_butter',
        B: Ingredient.of('#modpack:berry',1)
      }
    )

    event.shaped(
      Item.of('createcafe:blood_orange', 1),  
      [
        ' A ',
        ' B ',
        '   '
      ],
      {
        A: 'youkaishomecoming:blood_bottle',
        B: Ingredient.of('#modpack:orange',1)
      }
    )

    event.shaped(
      Item.of(Item.of('barbequesdelight:chili_powder', '{Damage:0}'), 1),  
      [
        ' A ',
        ' B ',
        '   '
      ],
      {
        A: 'spanishdelight:paprika',
        B: 'minecraft:bowl'
      }
    )

     event.shaped(
      Item.of('argentinas_delight:tuco', 1),  
      [
        ' A ',
        ' B ',
        '   '
      ],
      {
        A: 'farmersdelight:minced_beef',
        B: 'farmersdelight:tomato_sauce'
      }
    )

event.recipes.farmersdelight.cooking(
    ['kubejs:raw_human_organ_meat', '#forge:pasta','farmersdelight:tomato_sauce','farmersdelight:mutton_chops'],
    Item.of('kubejs:suspicious_pasta_with_mutton_chop', 1),  // 修正：使用Item.of()方法指定数量
    50, // 经验
    300,  // 烹饪时间（tick）
    'minecraft:bowl' // 如果需要容器，可以在这里添加

)

event.shaped(
      Item.of('kubejs:human_meat_burger', 1),  
      [
        'ABE',
        'CDF',
        '   '
      ],
      {
        A: 'kubejs:cooked_man_meat',
        B: 'farmersdelight:beef_patty', 
        C:  Ingredient.of('#forge:crops/onion', 1), 
        D: Ingredient.of('#dumplings_delight:tomato', 1),
        E: Ingredient.of('#forge:salad_ingredients'),
        F: Ingredient.of('#forge:bread')
  
      }
    )

event.shaped(
      Item.of('create:tree_fertilizer', 4),  
      [
        'BA ',
        '   ',
        '   '
      ],
      {
        A:'minecraft:bone_meal' ,
        B:'createaddition:biomass' 
      }
    )

event.shaped(
      Item.of('farmingforblockheads:green_fertilizer', 16),  
      [
        'AAA',
        'BCB',
        'DDD'
      ],
      {
        A:'minecraft:green_dye',
        B:'minecraft:gold_nugget', 
        C:'minecraft:wheat_seeds', 
        D:'createaddition:biomass'
      }
    )

event.shaped(
      Item.of('farmingforblockheads:red_fertilizer', 16),  
      [
        'AAA',
        'BCB',
        'DDD'
      ],
      {
        A:'minecraft:red_dye',
        B:'minecraft:gold_nugget', 
        C:'minecraft:wheat_seeds', 
        D:'createaddition:biomass'
      }
    )

event.shaped(
      Item.of('farmingforblockheads:yellow_fertilizer', 16),  
      [
        'AAA',
        'BCB',
        'DDD'
      ],
      {
        A:'minecraft:yellow_dye',
        B:'minecraft:gold_nugget', 
        C:'minecraft:wheat_seeds', 
        D:'createaddition:biomass'
      }
    )

/*
    event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'biologica:raw_elk' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'delightful:venison_chops',  //输出
          count: 2,
          chance: 1.0
        }
      ]
    });
*/

event.shaped(
      Item.of('extravagantdelight:tropical_pizza', 1),  
      [
        ' A ',
        'BCB',
        'DDD'
      ],
      {
        A: 'extravagantdelight:pickled_mangoes',
        B: Ingredient.of('#modpack:mango_slice', 1),
        C: Ingredient.of('#modpack:cheese', 1), 
        D: 'yeastnfeast:barley'
      }
    )

event.shaped(
      Item.of('kubejs:human_meat_sandwich', 1),  
      [
        'ABE',
        'F  ',
        '   '
      ],
      {
        A: 'kubejs:cooked_man_meat',
        B: 'minecraft:carrot', 
        E: Ingredient.of('#forge:salad_ingredients'),
        F: Ingredient.of('#forge:bread')
  
      }
    )

event.shaped(
      Item.of('kubejs:human_meat_saladr', 1),  
      [
        'ABE',
        'CD ',
        '   '
      ],
      {
        A: 'kubejs:cooked_man_meat',
        B: 'minecraft:bowl',
        C:  Ingredient.of('#forge:crops/onion', 1), 
        D: Ingredient.of('#dumplings_delight:tomato', 1),
        E: Ingredient.of('#forge:salad_ingredients'),
  
      }
    )

event.shaped(
      Item.of('kubejs:human_sausage', 3),  
      [
        'ABE',
        'CD ',
        '   '
      ],
      {
        A: 'kubejs:raw_human_organ_meat',
        B: Item.of('barbequesdelight:pepper_powder', '{Damage:0}'),
        C: 'spanishdelight:paprika', 
        D: 'minecraft:sugar',
        E: 'braziliandelight:salt',
  
      }
    )

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'vintagedelight:roasted_peanut' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'manors_bounty:cooked_peanut',  //输出
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:cooked_peanut',  
          count: 1,
          chance: 0.5
        }
      ]
    });


  event.smelting('kubejs:cooked_man_meat', 'kubejs:raw_man_meat')
    //前输出  后输入
  event.smelting('kubejs:cooked_human_sausage','kubejs:human_sausage')
/*blasting*/

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'kubejs:raw_man_meat' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'kubejs:raw_human_organ_meat',  //输出
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'kubejs:human_stomach' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'kubejs:raw_human_organ_meat',  //输出
          count: 1,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'kubejs:human_lungs' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'kubejs:raw_human_organ_meat',  //输出
          count: 1,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'kubejs:human_heart' }   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'   //工具
      },
      result: [
        {
          item: 'kubejs:raw_human_organ_meat',  //输出
          count: 1,
          chance: 1.0
        }
      ]
    });
/*
event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:milk"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": ""
    },
    {
      "item": ""
    },
    {
      "item": ""
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1000,
    "item": ""
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": ""
    },
    {
      "item": ""
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": ""
  },
  "temperature": 5
});
*/

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "alcocraftplus:hop"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item": "minecraft:wheat"
    },
    {
      "item": "yeastnfeast:yeast"
    }
  ],
  "recipe_book_tab": "fluid",
  "result": {
    "count": 4000,
    "fluid": "brewinandchewin:beer"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "tag": "neoforge:hawberry"
    },
    {
      "tag": "forge:elderberries"
    },
    {
      "item": "minecraft:sweet_berries"
    },
    {
      "item":"kubejs:yeast_tankard"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "yeastnfeast:thornberry_mead"
  },
  "temperature": 4
});

event.shaped(
      Item.of('kubejs:yeast_tankard', 1),  
      [
        'A  ',
        'B  ',
        '   '
      ],
      {
        A: 'yeastnfeast:yeast',
        B: 'brewinandchewin:tankard'
      }
    )

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "seeddelight:rosehip"
    },
    {
      "item": "yeastnfeast:maple_syrup"
    },
    {
      "item": "neapolitan:mint_leaves"
    },
    {
      "item":"kubejs:yeast_tankard"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "yeastnfeast:blossom_mead"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "yeastnfeast:rye"
    },
    {
      "item": "yeastnfeast:maple_syrup"
    },
    {
      "item": "neapolitan:mint_leaves"
    },
    {
      "item":"kubejs:yeast_tankard"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "yeastnfeast:amber_mead"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "minecraft:apple"
    },
    {
      "item": "minecraft:honey_bottle"
    },
    {
      "item": "minecraft:wheat"
    },
    {
      "item":"kubejs:yeast_tankard"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "yeastnfeast:honey_mead"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "bountifulfares:elderberries"
    },
    {
      "item": "fruitsdelight:lemon"
    },
    {
      "item": "yeastnfeast:ginger"
    },
    {
      "item":"kubejs:yeast_tankard"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "yeastnfeast:sour_mead"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "yeastnfeast:barley"
    },
    {
      "item": "yeastnfeast:molasses"
    },
    {
      "item": "minecraft:sugar_cane"
    },
    {
      "item":"kubejs:yeast_tankard"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "yeastnfeast:molasses_mead"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "minecraft:rotten_flesh"
    },
    {
      "item": "minecraft:rotten_flesh"
    },
    {
      "item": "minecraft:rotten_flesh"
    },
    {
      "tag":"forge:salt2"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 3,
    "item": "hearthandharvest:jerky"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "hearthandharvest:unripe_goat_cheese_wheel"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:goat_cheese_wheel"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "experience": 1.0,
  "fermentingtime": 9600,
  "ingredients": [
    {
      "item": "hearthandharvest:unripe_cheddar_cheese_wheel"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:cheddar_cheese_wheel"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 3200,
  "ingredients": [
    {
      "item": "hearthandharvest:raspberry_juice"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:raspberry_wine"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 3200,
  "ingredients": [
    {
      "item": "hearthandharvest:cherry_juice"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:cherry_wine"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 3200,
  "ingredients": [
    {
      "item": "hearthandharvest:red_grape_juice"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:red_grape_wine"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 3200,
  "ingredients": [
    {
      "item": "hearthandharvest:blueberry_juice"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:blueberry_wine"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 3200,
  "ingredients": [
    {
      "item": "hearthandharvest:green_grape_juice"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:green_grape_wine"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 500,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 3200,
  "ingredients": [
    {
      "item": "minecraft:honey_bottle"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "hearthandharvest:mead"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:apple"
    },
    {
      "item": "minecraft:honeycomb"
    },
    {
      "item": "minecraft:bread"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:kvass"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:diamond"
    },
    {
      "item": "minecraft:glow_lichen"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:digger_bitter"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:phantom_membrane"
    },
    {
      "item": "minecraft:chorus_fruit"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:chorus_ale"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:prismarine_shard"
    },
    {
      "item": "minecraft:prismarine_crystals"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:drowned_ale"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:nether_wart"
    },
    {
      "item": "minecraft:wither_skeleton_skull"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:wither_stout"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:glistering_melon_slice"
    },
    {
      "item": "minecraft:sunflower"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:sun_pale_ale"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:gold_nugget"
    },
    {
      "item": "minecraft:blaze_powder"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:nether_porter"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:phantom_membrane"
    },
    {
      "item": "minecraft:charcoal"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:night_rauch"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:nether_star"
    },
    {
      "item": "minecraft:diamond"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:nether_star_lager"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:iron_nugget"
    },
    {
      "item": "minecraft:redstone"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:magnet_pilsner"
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:emerald"
    },
    {
      "item": "minecraft:rabbit_foot"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:leprechaun_cider"
  },
  "temperature": 5
});
/*
event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": 'forestry:fertilizer_compound'
    },
    {
      "item": 'vintagedelight:organic_mash'
    },
    {
      "item": 'vintagedelight:organic_mash'
    },
    {
      "item":'vintagedelight:organic_mash'
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 6,
    "item": 'createaddition:biomass'
  },
  "temperature": 5
});
*/
event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": 'forestry:fertilizer_compound'
    },
    {
      "item": 'kubejs:plant_residue'
    },
    {
      "item": 'kubejs:plant_residue'
    },
    {
      "item":'kubejs:plant_residue'
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 2,
    "item": 'createaddition:biomass'
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 64000,
  "ingredients": [
    {
      "item": 'kubejs:plant_residue'
    },
    {
      "item": 'kubejs:plant_residue'
    },
    {
      "item": 'kubejs:plant_residue'
    },
    {
      "item":'kubejs:plant_residue'
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 50,
    "item": 'vintagedelight:organic_mash'
  },
  "temperature": 5
});

event.custom({
  "type": "brewinandchewin:fermenting",
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 18000,
  "ingredients": [
    {
      "item": "minecraft:snowball"
    },
    {
      "item": "minecraft:packed_ice"
    },
    {
      "item": "alcocraftplus:dry_seeds"
    },
    {
      "item":"brewinandchewin:beer"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "alcocraftplus:ice_beer"
  },
  "temperature": 1
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
  "count": 250,
    "fluid": "minecraft:water",
  }, 
  "experience": 1.0,
  "fermentingtime": 6000,
  "ingredients": [
    {
      "item": "yeastnfeast:yeast"
    },
    {
      "item": "minecraft:sugar"
    },
    {
      "item":"neapolitan:ice_cubes"
    }
  ],
  "recipe_book_tab": "fluid",
  "result": {
    "count": 1,
    "item": "kubejs:dryice"
  },
  "temperature": 2
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 250,
    "fluid": "minecraft:water"
  }, 
  "experience": 1.0,
  "fermentingtime": 6000,
  "ingredients": [
    {
      "item": "kubejs:soda_can"
    },
    {
      "item":"kubejs:dryice"
    }
  ],
  "recipe_book_tab": "fluid",
  "result": {
    "count": 1,
    "item": "kubejs:soda_water"
  },
  "temperature": 2
});

event.recipes.farmersdelight.cooking(
    ['bountifulfares:elderberries','bountifulfares:elderberries','bountifulfares:elderberries','bountifulfares:elderberries','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('yeastnfeast:elderberries_jam',1),  // 修正：使用Item.of()方法指定数量
    50, // 经验
    300,  // 烹饪时间（tick）
    'vintagedelight:mason_jar'// 如果需要容器，可以在这里添加
);

event.recipes.farmersdelight.cooking(
    ['minecraft:golden_apple','minecraft:golden_apple','minecraft:golden_apple','minecraft:golden_apple','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('yeastnfeast:golden_apple_jam', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['minecraft:apple','minecraft:apple','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:apple_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['minecraft:chorus_fruit','minecraft:chorus_fruit','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:chorus_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['minecraft:sweet_berries','minecraft:sweet_berries','minecraft:sweet_berries','minecraft:sweet_berries','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:sweetberry_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['minecraft:glow_berries','minecraft:glow_berries','minecraft:glow_berries','minecraft:glow_berries','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:glowberry_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['minecraft:melon_slice','minecraft:melon_slice','minecraft:melon_slice','minecraft:melon_slice','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:melon_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:lemon','fruitsdelight:lemon','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:lemon_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:hawberry','fruitsdelight:hawberry','fruitsdelight:hawberry','fruitsdelight:hawberry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:hawberry_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['seeddelight:rosehip','seeddelight:rosehip','seeddelight:rosehip','seeddelight:rosehip','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('seeddelight:rosehip_jam_jar', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:blueberry','fruitsdelight:blueberry','fruitsdelight:blueberry','fruitsdelight:blueberry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:blueberry_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

/*
event.recipes.farmersdelight.cooking(
    [,'minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of(, 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);
*/

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:hamimelon_slice','fruitsdelight:hamimelon_slice','fruitsdelight:hamimelon_slice','fruitsdelight:hamimelon_slice','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:hamimelon_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:lychee','fruitsdelight:lychee','fruitsdelight:lychee','fruitsdelight:lychee','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:lychee_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:mango','fruitsdelight:mango','fruitsdelight:mango','fruitsdelight:mango','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:mango_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['#neoforge:orange2','#neoforge:orange2','#neoforge:orange2','#neoforge:orange2','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:orange_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:peach','fruitsdelight:peach','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:peach_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:pear','fruitsdelight:pear','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:pear_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:persimmon','fruitsdelight:persimmon','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:persimmon_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:pineapple_slice','fruitsdelight:pineapple_slice','fruitsdelight:pineapple_slice','fruitsdelight:pineapple_slice','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:pineapple_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:cranberry','fruitsdelight:cranberry','fruitsdelight:cranberry','fruitsdelight:cranberry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:cranberry_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:mangosteen','fruitsdelight:mangosteen','fruitsdelight:mangosteen','fruitsdelight:mangosteen','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:mangosteen_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:bayberry','fruitsdelight:bayberry','fruitsdelight:bayberry','fruitsdelight:bayberry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:bayberry_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:kiwi','fruitsdelight:kiwi','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:kiwi_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:fig','fruitsdelight:fig','fruitsdelight:fig','fruitsdelight:fig','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:fig_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['fruitsdelight:durian_flesh','fruitsdelight:durian_flesh','fruitsdelight:durian_flesh','fruitsdelight:durian_flesh','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('fruitsdelight:durian_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['hearthandharvest:raspberry','hearthandharvest:raspberry','hearthandharvest:raspberry','hearthandharvest:raspberry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('hearthandharvest:raspberry_jam', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['vintagedelight:gearo_berry','vintagedelight:gearo_berry','vintagedelight:gearo_berry','vintagedelight:gearo_berry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('vintagedelight:gearo_berry_mason_jar', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['#c:grapes','#c:grapes','#c:grapes','#c:grapes','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('hearthandharvest:grape_jam', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['immortalers_delight:himekaido','immortalers_delight:himekaido','immortalers_delight:himekaido','immortalers_delight:himekaido','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('immortalers_delight:himekaido_jelly', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
);

event.recipes.farmersdelight.cooking(
    ['vinery:cherry','vinery:cherry','vinery:cherry','vinery:cherry','minecraft:sugar','fruitsdelight:lemon_slice'],
    Item.of('seeddelight:cherry_jam_jar', 1), 
    50, 
    300, 
    'vintagedelight:mason_jar'
)

event.recipes.farmersdelight.cooking(
    [
    '#c:water_bottles',
    'neapolitan:strawberries',
    'neapolitan:strawberries'
    
    ],
    Item.of('farm_and_charm:strawberry_tea', 1), 
    50, 
    300, 
  'minecraft:glass_bottle'
  );

  event.recipes.farmersdelight.cooking(
    [
    '#forge:crops/onion',
    '#farm_and_charm:cooked_beef',
    'farm_and_charm:simple_tomato_soup',
    'minecraft:potato',
    'minecraft:carrot'
    
    ],
    Item.of('farm_and_charm:goulash', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
    '#forge:vegetables/tomato',
    '#forge:vegetables/tomato',
    'minecraft:sugar'
    
    ],
    Item.of('farm_and_charm:simple_tomato_soup', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
    '#forge:crops/onion',
    '#forge:crops/onion',
    '#c:bread'
    
    ],
    Item.of('farm_and_charm:onion_soup', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
    '#c:water_bottles',
    'farm_and_charm:wild_nettle',
    'farm_and_charm:wild_nettle'
    
    ],
    Item.of('farm_and_charm:nettle_tea', 1), 
    50, 
    300, 
  'minecraft:glass_bottle'
  );

event.recipes.farmersdelight.cooking(
    [
    '#c:water_bottles',
    'farm_and_charm:wild_ribwort',
    'farm_and_charm:wild_ribwort'
    
    ],
    Item.of('farm_and_charm:ribwort_tea', 1), 
    50, 
    300, 
  'minecraft:glass_bottle'
  );

event.recipes.farmersdelight.cooking(
    [
    '#c:water_bottles',
    'yeastnfeast:barley',
    'yeastnfeast:barley',
    '#forge:eggs'
    
    ],
    Item.of('farm_and_charm:barley_soup', 1), 
    50, 
    300, 
  'minecraft:bowl'
  );

event.recipes.farmersdelight.cooking(
    [
    'braziliandelight:corn',
    'braziliandelight:corn',
    'create:wheat_flour'
    
    ],
    Item.of('farm_and_charm:corn_grits', 1), 
    50, 
    300, 
  'minecraft:bowl'
  );

event.recipes.farmersdelight.cooking(
    [
    '#forge:crops/onion',
    'minecraft:potato',
    
    ],
    Item.of('farm_and_charm:potato_soup', 1), 
    50, 
    300, 
    'minecraft:bowl'
);
/*
event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": "" },
    { "item": "" },
    { "item": "" },
    { "item": "" },
    { "item": "" },
    { "item": "braziliandelight:salt" }
  ],
  "container": { "item": "vintagedelight:mason_jar" },
  "output": {
    "item": "",
    "count": 1,
  },
  "processingTime": 400
});

event.recipes.farmersdelight.cooking(
    [
    ,
    ,
    ,
    ,
    ,
    
    ],
    Item.of(, 1), 
    50, 
    300, 
    
);


*/
event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": "farmersdelight:cabbage" },
    { "item": "farmersdelight:cabbage" },
    { "item": "farmersdelight:cabbage" },
    { "item": "farmersdelight:cabbage" },
    { "item": "farmersdelight:cabbage" },
    { "item": "braziliandelight:salt" }
  ],
  "container": { "item": "vintagedelight:mason_jar" },
  "output": {
    "item": "hearthandharvest:pickled_cabbage",
    "count": 1,
  },
  "processingTime": 400
});

event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": "minecraft:potato" },
    { "item": "minecraft:potato" },
    { "item": "minecraft:potato" },
    { "item": "minecraft:potato" },
    { "item": "minecraft:potato" },
    { "item": "braziliandelight:salt" }
  ],
  "container": { "item": "vintagedelight:mason_jar" },
  "output": {
    "item": "hearthandharvest:pickled_potatoes",
    "count": 1,
  },
  "processingTime": 400
});

event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": "minecraft:carrot" },
    { "item": "minecraft:carrot" },
    { "item": "minecraft:carrot" },
    { "item": "minecraft:carrot" },
    { "item": "minecraft:carrot" },
    { "item": "braziliandelight:salt" }
  ],
  "container": { "item": "vintagedelight:mason_jar" },
  "output": {
    "item": "hearthandharvest:pickled_carrots",
    "count": 1,
  },
  "processingTime": 400
});
/*
event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": 'vintagedelight:organic_mash' },
    { "item": 'vintagedelight:organic_mash' },
    { "item": 'vintagedelight:organic_mash' },
    { "item": 'vintagedelight:organic_mash' },
    { "item": 'vintagedelight:organic_mash' },
    { "item": 'vintagedelight:organic_mash' }
  ],
  "output": {
    "item": 'createaddition:biomass',
    "count": 3,
  },
  "processingTime": 400
});

event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' }
  ],
  "output": {
    "item": 'createaddition:biomass',
    "count": 1,
  },
  "processingTime": 400
});
*/
event.custom({
  "type": "vintagedelight:fermenting",
  "ingredients": [
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' },
    { "item": 'kubejs:plant_residue' }
  ],
  "output": {
    "item": 'vintagedelight:organic_mash',
    "count": 30,
  },
  "processingTime": 40000
});

//切
event.custom({
        type: 'farmersdelight:cutting',
        ingredients: [
          { item: 'neapolitan:banana_stalk' }   //输入
        ],
        tool: {
          tag: 'forge:tools/axes'   //工具
        },
        result: [
          {
            item: 'manors_bounty:banana_frond_sapling',  //输出
            count: 2,
            chance: 1.0
          }
        ]
      });

/*
庄园馀话

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 250,
    "fluid": "minecraft:water"
  }, 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":""
    },
    {
      "item":""
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": ""
  },
  "temperature": 2
});
*/
event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item": "manors_bounty:tropical_fish_roe"
    },
    {
      "item": "manors_bounty:tropical_fish_roe"
    },
    {
      "item": "minecraft:gold_ingot"
    },
    {
      "item":"manors_bounty:salt_shaker"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:caviar"
  },
  "temperature": 1
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item": "manors_bounty:tropical_fish_roe"
    },
    {
      "item": "manors_bounty:tropical_fish_roe"
    },
    {
      "item": "minecraft:gold_ingot"
    },
    {
      "item":"vintagedelight:salt_dust"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:caviar"
  },
  "temperature": 1
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 250,
    "fluid": "minecraft:water"
  }, 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item": "manors_bounty:boxed_milk"
    },
    {
      "item": "minecraft:honey_bottle"
    },
    {
      "item": "manors_bounty:deformed_glass_bottle"
    },
    {
      "item":"fruitsdelight:lemon_slice"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:yogurt"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "tag":"forge:muscat_grape"
    },
    {
      "tag":"forge:muscat_grape"
    },
    {
      "item":"manors_bounty:bottled_water"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:white_wine"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "tag":"forge:red_grape_two"
    },
    {
      "tag":"forge:red_grape_two"
    },
    {
      "item":"manors_bounty:bottled_water"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:red_wine"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:lavender"
    },
    {
      "tag":"c:corn"
    },
    {
      "item":"brewincompatdelight:juniper_berries"
    },
    {
      "item":"manors_bounty:bottled_water"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:gin"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"manors_bounty:purple_sugar_cane"
    },
    {
      "item":"minecraft:honey_bottle"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:rum"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "tag":"forge:grain/rice"
    },
    {
      "tag":"forge:grain/rice"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:sake"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"minecraft:wheat"
    },
    {
      "item":"minecraft:wheat"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:beer"
  },
  "temperature": 4
  
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"yeastnfeast:barley"
    },
    {
      "item":"yeastnfeast:barley"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:whiskey"
  },
  "temperature": 4
  
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:frigid_grass"
    },
    {
      "item":"minecraft:wheat"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:absinthe"
  },
  "temperature": 1
  
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 250,
    "fluid": "minecraft:water"
  },  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:sake"
    },
    {
      "item":"fruitsdelight:lemon_slice"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:rice_vinegar"
  },
  "temperature": 2
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"minecraft:potato"
    },
    {
      "item":"minecraft:potato"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:vodka"
  },
  "temperature": 2
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:cherries"
    },
    {
      "item":"manors_bounty:white_wine"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:brandy"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:sake"
    },
    {
      "item":"manors_bounty:ume"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:umeshu"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"minecraft:dragon_breath"
    },
    {
      "item":"manors_bounty:white_wine"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:champagne"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:champagne"
    },
    {
      "item":"some_assembly_required:enchanted_golden_apple_slices"
    },
    {
      "item":"manors_bounty:starfruit_slice"
    },
    {
      "item":"minecraft:pitcher_pod"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:starfruit_wine"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"minecraft:bread"
    },
    {
      "item":"manors_bounty:yogurt"
    },
    {
      "item":"manors_bounty:bottled_water"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:kvass"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:blackcurrant"
    },
    {
      "item":"manors_bounty:blackcurrant"
    },
    {
      "item":"manors_bounty:vodka"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:creme_de_cassis"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:prune"
    },
    {
      "item":"manors_bounty:jalapeno"
    },
    {
      "item":"collectorsreap:lime_slice"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:chamoy"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:ume"
    },
    {
      "tag":"forge:salt_two"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:umeboshi"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:water"
  },
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt_two"
    },
    {
      "item":"manors_bounty:pimento_slice"
    },
    {
      "item":"manors_bounty:olive_fruit"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:stuffed_olive"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"braziliandelight:coconut_slice"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 2,
    "item": "manors_bounty:nata_de_coco"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:mushrooms"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 2,
    "item": "manors_bounty:suspicious_mold"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":"manors_bounty:apricot"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:dried_apricot"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "tag":"forge:plum"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:prune"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:milk"
  }, 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:boxed_whipping_cream"
    },
    {
      "item":"manors_bounty:boxed_whipping_cream"
    },
    {
      "item":"manors_bounty:yogurt"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 2,
    "item": "manors_bounty:cream_cheese"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:milk"
  }, 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:fig_slice"
    },
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":"manors_bounty:yogurt"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:mozzarella_cheese_wheel"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:milk"
  }, 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt_two"
    },
    {
      "item":"minecraft:dragon_breath"
    },
    {
      "item":"manors_bounty:yogurt"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:emmental_cheese_wheel"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "basefluid": {
    "count": 1000,
    "fluid": "minecraft:milk"
  }, 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt_two"
    },
    {
      "item":"minecraft:red_dye"
    },
    {
      "item":"manors_bounty:yogurt"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:cheddar_cheese_wheel"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt"
    },
    {
      "tag":"modpack:mango_slice"
    },
    {
      "tag":"modpack:mango_slice"
    },
    {
      "item":"vintagedelight:mason_jar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "extravagantdelight:pickled_mangoes"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt"
    },
    {
      "item":"extravagantdelight:muscadine_grapes"
    },
    {
      "item":"extravagantdelight:muscadine_grapes"
    },
    {
      "item":"vintagedelight:mason_jar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "extravagantdelight:pickled_muscadine_grapes"
  },
  "temperature": 4
});
event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt"
    },
    {
      "item":"extravagantdelight:roasted_rhubarb"
    },
    {
      "item":"extravagantdelight:roasted_rhubarb"
    },
    {
      "item":"vintagedelight:mason_jar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "extravagantdelight:pickled_rhubarb"
  },
  "temperature": 4
});
event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"forge:salt"
    },
    {
      "item":"alcocraftplus:hop"
    },
    {
      "item":"alcocraftplus:hop"
    },
    {
      "item":"vintagedelight:mason_jar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "extravagantdelight:pickled_hops"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"manors_bounty:tea_base"
    },
    {
      "item":"manors_bounty:nata_de_coco"
    },
    {
      "item":"minecraft:sugar"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:kombucha"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting", 
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:rose"
    },
    {
      "item":"manors_bounty:lavender"
    },
    {
      "item":"minecraft:oxeye_daisy"
    },
    {
      "item":"manors_bounty:kombucha"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:floral_kombucha"
  },
  "temperature": 4
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"fruitsdelight:lemon_slice"
    },
    {
      "item":"manors_bounty:plum_slice"
    },
    {
      "item":"manors_bounty:passion_fruit_slice"
    },
    {
      "item":"manors_bounty:kombucha"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:fruit_flavored_kombucha"
  },
  "temperature": 3
});

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "tag":"neoforge:paprika"
    },
    {
      "tag":"forge:salt_two"
    },
    {
      "item":"manors_bounty:tarako"
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": "manors_bounty:mentaiko"
  },
  "temperature": 4
});

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:bottled_water',
      'manors_bounty:dragon_fruit_cactus_flower',
      'manors_bounty:pear_slice',
      'manors_bounty:fig',
      'manors_bounty:apricot_kernel',
      'minecraft:sugar'
    ],
    Item.of('manors_bounty:canton_bloom_soup', 1), 
    50, 
    300, 
    'manors_bounty:marble_bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:olive_fruit',
      'manors_bounty:olive_fruit',
      'manors_bounty:olive_fruit',
      'manors_bounty:olive_fruit',
      'manors_bounty:olive_fruit',
      'manors_bounty:olive_fruit'
    ],
    Item.of('manors_bounty:olive_oil_bucket', 1), 
    50, 
    300, 
    'minecraft:bucket'
);

event.recipes.farmersdelight.cooking(
    [
      'minecraft:water_bucket',
      'minecraft:water_bucket',
      'minecraft:water_bucket'
    ],
    Item.of('manors_bounty:salt_shaker', 1), 
    50, 
    300, 
    'manors_bounty:deformed_wine_bottle'
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:bottled_water',
      'manors_bounty:dried_hawthorn',
      'manors_bounty:dried_hawthorn',
      'manors_bounty:umeboshi',
      '#forge:sugar_cane',
      'minecraft:sugar'

    ],
    Item.of('manors_bounty:suanmeitang', 1), 
    50, 
    300, 
    'manors_bounty:fruitwood_bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:bottled_water',
      'manors_bounty:beetroot_slice',
      'manors_bounty:tomato_slice',
      'some_assembly_required:chopped_carrot',
      'rusticdelight:potato_slices',
      'manors_bounty:raw_beef_cubes'
    ],
    Item.of('manors_bounty:borscht', 1), 
    50, 
    300, 
    'manors_bounty:marble_bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:boxed_milk',
      'manors_bounty:boxed_whipping_cream',
      'braziliandelight:butter',
      'create:wheat_flour',
      '#forge:mushrooms',
      '#forge:mushrooms'
    ],
    Item.of('manors_bounty:cream_with_mushroom_soup', 1), 
    50, 
    300, 
    'manors_bounty:marble_bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:boxed_milk',
      'manors_bounty:boxed_whipping_cream',
      'braziliandelight:butter',
      'create:wheat_flour',
      'braziliandelight:cooked_shrimp',
      'braziliandelight:kernels'
    ],
    Item.of('manors_bounty:prawn_and_corn_soup', 1), 
    50, 
    300, 
    'manors_bounty:marble_bowl'
);

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item:  'argentinas_delight:tomatitos_cherry'}   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'  //工具
      },
      result: [
        {
          item: 'some_assembly_required:tomato_slices',  //输出
          count: 1,
          chance: 1.0
        },
        {
          item: 'manors_bounty:tomato_seed',  //输出
          count: 1,
          chance: 0.10
        },
        {
          item: 'farmersdelight:tomato_seeds',  //输出
          count: 1,
          chance: 0.25
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item:  'farmersdelight:tomato'}   //输入
      ],
      tool: {
        tag: 'forge:tools/knives'  //工具
      },
      result: [
        {
          item: 'some_assembly_required:tomato_slices',  //输出
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:tomato_seed',  //输出
          count: 1,
          chance: 0.10
        },
        {
          item: 'farmersdelight:tomato_seeds',  //输出
          count: 1,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:pufferfish'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'crabbersdelight:pufferfish_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'minecraft:bone_meal',  
          count: 1,
          chance: 0.8
        },
        {
          item: 'manors_bounty:shirako',  
          count: 1,
          chance: 0.1
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:tropical_fish'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'crabbersdelight:tropical_fish_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'minecraft:bone_meal',  
          count: 1,
          chance: 0.8
        },
        {
          item: 'manors_bounty:tropical_fish_roe',  
          count: 1,
          chance: 0.1
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:cod'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'farmersdelight:cod_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'minecraft:bone_meal',  
          count: 1,
          chance: 0.8
        },
        {
          item: 'manors_bounty:tarako',  
          count: 1,
          chance: 0.1
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:chicken' }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'farmersdelight:chicken_cuts',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_chicken_wing',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_chicken_breast',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_chicken_drumstick',  
          count: 2,
          chance: 1.0
        }
      ]
    });

  event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:raw_bresse_chicken' }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'farmersdelight:chicken_cuts',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_chicken_wing',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_chicken_breast',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_chicken_drumstick',  
          count: 2,
          chance: 1.0
        }
      ]
    });

 event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:raw_mallard_duck' }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:raw_duck_wing',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_duck_foot',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_duck_breast',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'manors_bounty:raw_duck_drumstick',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:cooked_chicken' }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'farmersdelight:cooked_chicken_cuts',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:cooked_chicken_wing',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:cooked_chicken_breast',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'manors_bounty:cooked_chicken_drumstick',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:fried_chicken'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:karaage',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:fried_drumstick',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'farmersdelight:cooked_rice'}   
      ],
      tool: {
        tag: 'forge:tools/rolling_pins'  
      },
      result: [
        {
          item: 'manors_bounty:mochi',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item:'manors_bounty:tostada_shell'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:corn_chips',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:spam'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:spam_slice',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:chorus_flower_jelly_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:chorus_flower_jelly_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:truffle_pie'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:truffle_pie_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:swiss_roll'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:swiss_roll_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:durian_mile_crepe_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:durian_mile_crepe_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:strawberry_shortcake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:strawberry_shortcake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:caramel_chocolate_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:caramel_chocolate_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:nether_wart_soul_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:nether_wart_soul_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:pavlova_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:pavlova_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:sweet_berry_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:sweet_berry_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'neapolitan:vanilla_cake'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:vanilla_cake_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:wild_jalapeno'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:wild_jalapeno_slice',  
          count: 3,
          chance: 1.0
        }
      ]  
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'rusticdelight:bell_pepper_green'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:green_bell_pepper_slice',  
          count: 3,
          chance: 1.0
        },
        {
          item: 'rusticdelight:bell_pepper_seeds',  
          count: 1,
          chance: 0.5
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'rusticdelight:bell_pepper_red'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:pimento_slice',  
          count: 3,
          chance: 1.0
        },
        {
          item: 'rusticdelight:bell_pepper_seeds',  
          count: 1,
          chance: 0.5
        }
      ]
    });  

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:jalapeno'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:jalapeno_slice',  
          count: 3,
          chance: 1.0
        },
        {
          item: 'manors_bounty:jalapeno_seed',  
          count: 1,
          chance: 0.5
        }
      ]
    });    

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:pepperoni_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:pepperoni_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:cheesy_mushroom_bacon_pizza'}      
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:cheesy_mushroom_bacon_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:durian_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:durian_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:hawaiian_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:hawaiian_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:seafood_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:seafood_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:supreme_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:supreme_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:vanilla_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:vanilla_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:cherries_pie'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:cherries_pie_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:dark_chocolate'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:dark_chocolate_chips',  
          count: 3,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:chocolate'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:chocolate_chips',  
          count: 3,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:white_chocolate'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:white_chocolate_chips',  
          count: 3,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:beetroot'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:beetroot_slice',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:rose_bush'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'seeddelight:rosehip',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:rose',  
          count: 2,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:cherry_leaves'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'trailandtales_delight:cherry_petal',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'manors_bounty:sakura',  
          count: 1,
          chance: 1.0
        }
      ]
    });    

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:musang_king_durian'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:half_of_musang_king_durian',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:half_of_musang_king_durian'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:musang_king_durian_flesh',  
          count: 3,
          chance: 1.0
        },
        {
          item: 'manors_bounty:musang_king_durian_flesh',  
          count: 1,
          chance: 0.5
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'neapolitan:banana_bunch'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'neapolitan:banana',  
          count: 3,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'neapolitan:banana'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:banana_slice',  
          count: 3,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:end_pepper'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:end_pepper_slice',  
          count: 3,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:yuzumelo'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:yuzumelo_wedge',  
          count: 3,
          chance: 1.0
        },
        {
          item: 'manors_bounty:yuzumelo_wedge',  
          count: 1,
          chance: 0.5
        },
        {
          item: 'manors_bounty:yuzumelo_wedge',  
          count: 1,
          chance: 0.28
        },
        {
          item: 'manors_bounty:yuzumelo_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'culturaldelights:avocado'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'culturaldelights:cut_avocado',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:avocado_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'culturaldelights:cut_avocado'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:avocado_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'culturaldelights:cut_avocado'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:avocado_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:beef'}   
      ],
      tool: {
        tag: 'hearthandharvest:cleavers'  
      },
      result: [
        {
          item: 'manors_bounty:raw_beef_cubes',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'minecraft:cooked_beef'}   
      ],
      tool: {
        tag: 'hearthandharvest:cleavers'  
      },
      result: [
        {
          item: 'manors_bounty:cooked_beef_cubes',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'collectorsreap:pomegranate_slice'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:pomegranate_seed',  
          count: 3,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'fruitsdelight:mango'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:mango_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:starfruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:starfruit_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:starfruit_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:tomato'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:tomato_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:tomato_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'bountifulfares:plum'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:plum_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'braziliandelight:coconut_slice'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:coconut_meat',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:coconut_meat'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:grated_coconut',  
          count: 3,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'fruitsdelight:kiwi'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:half_of_kiwifruit',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:kiwifruit_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:half_of_kiwifruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:kiwifruit_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:gold_kiwifruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:half_of_gold_kiwifruit',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:kiwifruit_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:half_of_gold_kiwifruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:gold_kiwifruit_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'fruitsdelight:peach'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:peach_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:peach_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'fruitsdelight:pear'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:pear_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:pear_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:grapefruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:grapefruit_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:yuzumelo_seed',  
          count: 1,
          chance: 0.5
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:green_apple'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:green_apple_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:apple_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'fruitsdelight:hawberry'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:hawthorn_flakes',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:hawthorn_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'fruitsdelight:fig'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:fig_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:fig_seed',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'bountifulfares:passion_fruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:passion_fruit_slice',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:mozzarella_cheese_wheel'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:mozzarella_cheese_wedge',  
          count: 4,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:mozzarella_cheese_wedge'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:mozzarella_cheese_slice',  
          count: 4,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:emmental_cheese_wheel'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:emmental_cheese_wedge',  
          count: 4,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:emmental_cheese_wedge'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:emmental_cheese_slice',  
          count: 4,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:cheddar_cheese_wheel'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:cheddar_cheese_wedge',  
          count: 4,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:cheddar_cheese_wedge'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:cheddar_cheese_slice',  
          count: 4,
          chance: 1.0
        }
      ]
});
/*
event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'collectorsreap:pink_dragon_fruit'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:dragon_fruit_slice',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'collectorsreap:dragon_fruit_seeds',  
          count: 1,
          chance: 1.0
        }
      ]
});
*/
event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'culturaldelights:cut_cucumber'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'vintagedelight:cucumber_noodles',  
          count: 2,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'vintagedelight:cucumber_noodles'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'youkaishomecoming:cucumber_slice',  
          count: 1,
          chance: 1.0
        }
      ]
});



event.recipes.create.cutting(
        [
            Item.of('manors_bounty:raw_duck_foot', 2),
            Item.of('manors_bounty:raw_duck_drumstick', 2),
            Item.of('manors_bounty:raw_duck_wing', 2),
            Item.of('manors_bounty:raw_duck_neck', 1), 
            Item.of('manors_bounty:raw_duck_breast', 1) 
        ],
        'manors_bounty:raw_mallard_duck'
    )

event.recipes.create.cutting(
        [
            Item.of('farmersdelight:chicken_cuts', 4),
            Item.of('manors_bounty:raw_chicken_foot', 2),
            Item.of('manors_bounty:raw_chicken_drumstick', 2),
            Item.of('manors_bounty:raw_chicken_wing', 2),
            Item.of('manors_bounty:raw_chicken_neck', 1), 
            Item.of('manors_bounty:raw_chicken_breast', 2) 
        ],
       'manors_bounty:raw_bresse_chicken'
    )

event.recipes.create.cutting(
        [
            Item.of('farmersdelight:chicken_cuts', 2),
            Item.of('manors_bounty:raw_chicken_foot', 2),
            Item.of('manors_bounty:raw_chicken_drumstick', 2),
            Item.of('manors_bounty:raw_chicken_wing', 2),
            Item.of('manors_bounty:raw_chicken_neck', 1), 
            Item.of('manors_bounty:raw_chicken_breast', 1)
        ],
       'minecraft:chicken'
    )

event.recipes.create.cutting(
        [
            Item.of('collectorsreap:pomegranate_slice', 5),
            Item.of('minecraft:gunpowder', 2)
        ],
       'collectorsreap:stygian_pomegranate'
    )

event.recipes.create.cutting(
        [
            Item.of('collectorsreap:pomegranate_slice', 4),
            Item.of('minecraft:red_dye', 2)
        ],
       'collectorsreap:pomegranate'
    )


event.recipes.farmersdelight.cooking(
    [
      'meadow:raw_buffalo_meat',
      'meadow:raw_buffalo_meat',
      'meadow:raw_buffalo_meat',
      '#forge:salt',
      'minecraft:potato',
      'minecraft:carrot'
    ],
    Item.of('meadow:roasted_ham', 2), 
    50, 
    300, 
   'minecraft:bowl'
);    

event.recipes.farmersdelight.cooking(
    [
      'meadow:raw_buffalo_meat',
      '#forge:salt',
      '#c:cheese'
    ],
    Item.of('meadow:sausage_with_cheese', 2), 
    50, 
    300, 
   'minecraft:bowl'
);    

event.recipes.farmersdelight.cooking(
    [
      '#meadow:egg',
      '#forge:salt'
    ],
    Item.of('meadow:rennet', 2), 
    50, 
    300, 
    'minecraft:glass_bottle'
);    

event.recipes.farmersdelight.cooking(
    [
     'minecraft:rotten_flesh',
     'minecraft:rotten_flesh',
     'minecraft:rotten_flesh',
     'minecraft:rotten_flesh',
     'minecraft:rotten_flesh',
     'minecraft:rotten_flesh'
    ],
    Item.of('minecraft:leather', 1), 
    50, 
    10
);    

event.recipes.farmersdelight.cooking(
    [
      'minecraft:wheat',
      'minecraft:wheat',
      'minecraft:wheat',
      'minecraft:water_bucket',
    ],
    Item.of('meadow:wooden_grain_milk_bucket', 1), 
    50, 
    300, 
    'meadow:wooden_bucket'
);    

event.recipes.farmersdelight.cooking(
    [
      'minecraft:amethyst_cluster',
      '#forge:salt',
      '#forge:milk'
    ],
    Item.of('meadow:wooden_amethyst_milk_bucket', 1), 
    50, 
    300, 
    'meadow:wooden_bucket'
);    

event.recipes.farmersdelight.cooking(
    [
      'minecraft:calcite',
      'minecraft:water_bucket'
    ],
    Item.of('meadow:alpine_salt', 2), 
    50, 
    300, 
);    

event.recipes.farmersdelight.cooking(
    [
      'meadow:limestone',
      'minecraft:water_bucket'
    ],
    Item.of('meadow:alpine_salt', 4), 
    50, 
    300, 
);   

event.recipes.farmersdelight.cooking(
    [
      'minecraft:beef',
      'minecraft:carrot',
      'braziliandelight:butter',
      'minecraft:potato',
      'minecraft:beetroot',
      '#c:crops/cabbage'
      
    ],
    Item.of('farm_and_charm:beef_patty_with_vegetables', 1), 
    50, 
    300, 
   'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'farm_and_charm:lamb_ham',
      'minecraft:carrot',
      'braziliandelight:butter',
      'braziliandelight:corn',
      
    ],
    Item.of('farm_and_charm:lamb_with_corn', 1), 
    50, 
    300, 
   'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'vintagedelight:oat',
      'vintagedelight:oat',
      'vintagedelight:oat',
      '#c:dough',
      'braziliandelight:butter',
      'neapolitan:strawberries'
    ],
    Item.of('farm_and_charm:oat_pancake', 3), 
    50, 
    300, 
   'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'yeastnfeast:barley',
      'yeastnfeast:barley',
      'braziliandelight:butter',
      'minecraft:potato',
      'minecraft:egg',
      '#c:crops/cabbage'
      
    ],
    Item.of('farm_and_charm:barley_patties_with_potatoes', 1), 
    50, 
    300, 
   'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      '#modpack:salmon',
      'braziliandelight:corn',
      'braziliandelight:butter',
      '#c:crops/cabbage'
      
    ],
    Item.of('farm_and_charm:cooked_salmon', 1), 
    50, 
    300, 
   'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      '#modpack:cod',
      'minecraft:carrot',
      'braziliandelight:butter',
      '#c:crops/cabbage'
      
    ],
    Item.of('farm_and_charm:cooked_cod', 1), 
    50, 
    300, 
   'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'farmersdelight:bacon',
      'farmersdelight:chicken_cuts',
      '#c:pasta',
      'braziliandelight:butter'
      
    ],
    Item.of('farm_and_charm:chicken_wrapped_in_bacon', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'farmersdelight:bacon',
      'farmersdelight:bacon',
      '#modpack:chicken_egg',
      '#modpack:chicken_egg',
      'braziliandelight:butter'
      
    ],
    Item.of('farm_and_charm:bacon_with_eggs', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'vintagedelight:oat',
      'minecraft:carrot',
      'braziliandelight:butter',
      'minecraft:potato',
      '#modpack:raw_beef_cubes',
      '#modpack:raw_beef_cubes'
    ],
    Item.of('farm_and_charm:sausage_with_oat_patty', 2), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'veggiesdelight:sweet_potato',
      'minecraft:water_bucket',

      
    ],
    Item.of('argentinas_delight:purebatataitem', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:purebatataitem',
      'minecraft:sugar'
      
    ],
    Item.of('argentinas_delight:dulcebatatabloque', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:membrillo',
      'minecraft:sugar'
      
    ],
    Item.of('argentinas_delight:membrillobloque', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'veggiesdelight:sweet_potato',
      'argentinas_delight:grasa'
      
    ],
    Item.of('argentinas_delight:batatafrita', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:espinacaitem',
      'argentinas_delight:grasa'
      
    ],
    Item.of('argentinas_delight:torreja', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:milanesacruda',
      'argentinas_delight:grasa'
      
    ],
    Item.of('argentinas_delight:milanesa', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:cherry_tomatoes',
      '#modpack:raw_beef_cubes',
      'minecraft:bread'
    ],
    Item.of('argentinas_delight:pancontuco', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'manors_bounty:cherry_tomatoes',
      '#modpack:raw_beef_cubes',
    ],
    Item.of('argentinas_delight:tuco', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:polentaconsalsaitem',
      'minecraft:cooked_chicken'
      
    ],
    Item.of('argentinas_delight:polentaconpajarito', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:polentaitem',
      'argentinas_delight:tuco'
      
    ],
    Item.of('argentinas_delight:polentaconsalsaitem', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'braziliandelight:corn_flour',
      'minecraft:water_bucket'
      
    ],
    Item.of('argentinas_delight:polentaitem', 1), 
    50, 
    300, 
    'minecraft:bowl'
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:grasa',
      'argentinas_delight:grasa'
      
    ],
    Item.of('argentinas_delight:chicharron', 1), 
    50, 
    300, 
    'minecraft:paper'
);

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item":'peruviansdelight:camote_cortado'
        },
        "output": { 
            "item":'argentinas_delight:batatasadaitem'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'farmersdelight:pumpkin_slice'
        },
        "output": { 
            "item": 'argentinas_delight:rodajasdecalabazasitem'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 32000, 
        "ingredient": { 
            "item": 'argentinas_delight:corderocrudo'
        },
        "output": { 
            "item": 'argentinas_delight:corderoitem',
            "count": 4
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'argentinas_delight:brochetascrudasitem'
        },
        "output": { 
            "item": 'argentinas_delight:brochetaasada'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'argentinas_delight:chorizos_crudositem'
        },
        "output": { 
            "item": 'argentinas_delight:chorizoitem'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'minecraft:cod'
        },
        "output": { 
            "item": 'argentinas_delight:tablapescado'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'argentinas_delight:achurasitem'
        },
        "output": { 
            "item": 'argentinas_delight:tablachura'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'argentinas_delight:tirasdechancho'
        },
        "output": { 
            "item": 'argentinas_delight:tabladechancho'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'argentinas_delight:tirasdeasado'
        },
        "output": { 
            "item": 'argentinas_delight:tabladeasadobloque'
        }
});

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 'argentinas_delight:polloloco'
        },
        "output": { 
            "item": 'argentinas_delight:tabladepollo'
        }
});

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:rodajasdecalabazasitem',
      'argentinas_delight:hamburguesasola'
      
    ],
    Item.of('argentinas_delight:calabazitarellena', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      'argentinas_delight:rodajasdecalabazasitem',
      '#modpack:raw_beef_cubes'
      
    ],
    Item.of('argentinas_delight:calabazitarellena', 1), 
    50, 
    300, 
);

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'argentinas_delight:vacio'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'argentinas_delight:costeletaitem',  
          count: 1,
          chance: 1.0
        }
      ]
    });

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'argentinas_delight:tabladepollo'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'argentinas_delight:patamusloitem',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'argentinas_delight:alitasdepollo',  
          count: 2,
          chance: 1.0
        },
        {
          item: 'manors_bounty:cooked_chicken_breast',  
          count: 1,
          chance: 1.0
        }
      ]
    });

    event.recipes.farmersdelight.cooking(
    [
      'braziliandelight:heavy_cream_bucket',
      '#modpack:caramel'
      
    ],
    Item.of('argentinas_delight:dulcedeleche', 1), 
    50, 
    300, 
    'minecraft:bucket'
);

event.custom({
  "type": "manors_bounty_machine:teapot",
  "container": {
    "item": 'argentinas_delight:matevacio'
  },
  "input": [
    {
      "item": 'minecraft:water_bucket'
    },
    {
      "tag": 'modpack:yerba'
    }
  ],
  "output": {
    "item": 'argentinas_delight:mateamargoitem'
  }
});

event.custom({
  "type": "manors_bounty_machine:teapot",
  "container": {
    "item": 'argentinas_delight:matevacio'
  },
  "input": [
    {
      "item": 'minecraft:water_bucket'
    },
    {
      "item": 'minecraft:sugar'
    },
    {
      "tag": 'modpack:yerba'
    }
  ],
  "output": {
    "item": 'argentinas_delight:matedulceitem'
  }
});

event.custom({
  "type": "manors_bounty_machine:teapot",
  "container": {
    "item": 'argentinas_delight:matevacio'
  },
  "input": [
    {
      "item": 'minecraft:water_bucket'
    },
    {
      "tag": 'alexscaves:ferns'
    },
    {
      "tag": 'modpack:yerba'
    }
  ],
  "output": {
    "item": 'argentinas_delight:mateconyuyos'
  }
});

event.custom({
  "type": "manors_bounty_machine:teapot",
  "container": {
    "item": 'argentinas_delight:matevacio'
  },
  "input": [
    {
      "item": 'minecraft:milk_bucket'
    },
    {
      "tag": 'modpack:yerba'
    }
  ],
  "output": {
    "item": 'argentinas_delight:matedeleche'
  }
});

event.recipes.farmersdelight.cooking(
    [
      '#forge:dough',
      'argentinas_delight:grasa'
    ],
    Item.of('argentinas_delight:bandejapancasero', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      '#forge:dough',
      'argentinas_delight:grasa',
      'argentinas_delight:chicharron'
    ],
    Item.of('argentinas_delight:bandejachicharron', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      '#forge:dough',
      'argentinas_delight:grasa',
      'argentinas_delight:grasa',
    ],
    Item.of('argentinas_delight:bolasfrailehechasbandeja', 1), 
    50, 
    300, 
);

event.recipes.farmersdelight.cooking(
    [
      '#forge:dough',
      'argentinas_delight:grasa',
      'minecraft:sugar'
    ],
    Item.of('argentinas_delight:roscashechas', 1), 
    50, 
    300, 
);


//黑麦汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:butter"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "item": "list:rye_dough"
    },
    {
      "item": "list:rye_dough"
    }
  ],
  "output": {
    "count": 3,
    "item": "list:black_burger"
  },
  "temperature": 250
});

//大麦汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:butter"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "item": "list:barley_dough"
    },
    {
      "item": "list:barley_dough"
    }
  ],
  "output": {
    "count": 3,
    "item": "list:barley_burger"
  },
  "temperature": 250
});

//木薯汉堡
event.recipes.farmersdelight.cooking(
    [
      'braziliandelight:cassava_flour',
      'braziliandelight:cassava_flour',
      'braziliandelight:butter',
      'vintagedelight:salt_dust',
      '#forge:milk',
      'minecraft:sugar'

    ],
    Item.of('list:cassava_burger', 1), 
    50, 
    300, 
   
);

//玉米汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "vintagedelight:salt_dust"
    },
    {
      "item": "minecraft:sugar"
    },
    {
      "item": "culturaldelights:corn_dough"
    },
    {
      "item": "culturaldelights:corn_dough"
    }
  ],
  "output": {
    "count": 3,
    "item": "list:corn_burger"
  },
  "temperature": 250
});

//白垩玉黍汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "item": "immortalers_delight:evolutcorn_grains"
    },
    {
      "item": "immortalers_delight:evolutcorn_paste"
    },
    {
      "item": "immortalers_delight:evolutcorn_paste"
    },
    {
      "item": "immortalers_delight:evolutcorn_paste"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:evolutcorn_burger"
  },
  "temperature": 250
});

//瓦斯麦汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "item": "immortalers_delight:kwat_wheat_dough"
    },
    {
      "item": "immortalers_delight:kwat_wheat_dough"
    },
    {
      "item": "immortalers_delight:kwat_wheat_dough"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:kwat_wheat_burger"
  },
  "temperature": 250
});

//黑橡子汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "item": "foragersinsight:acorn_dough"
    },
    {
      "item": "foragersinsight:acorn_dough"
    },
    {
      "item": "foragersinsight:acorn_dough"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:black_oak_burger"
  },
  "temperature": 250
});

//橡子汉堡
event.recipes.farmersdelight.cooking(
    [
      'delightful:roasted_acorn',
      'delightful:roasted_acorn',
      'delightful:roasted_acorn',
      'braziliandelight:butter',
      'vintagedelight:salt_dust',
      'minecraft:sugar'

    ],
    Item.of('list:oak_burger', 2), 
    50, 
    300, 
   
);
//红薯汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "veggiesdelight:sweet_potato_dough"
    },
    {
      "item": "veggiesdelight:sweet_potato_dough"
    },
    {
      "item": "veggiesdelight:sweet_potato_dough"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:sweet_potato_burger"
  },
  "temperature": 250
});

//南瓜汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "farmersdelight:pumpkin_slice"
    },
    {
      "item": "farmersdelight:pumpkin_slice"
    },
    {
      "item": "farmersdelight:pumpkin_slice"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:pumpkin_burger"
  },
  "temperature": 250
});

//坚果汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "delightful:nut_dough"
    },
    {
      "item": "delightful:nut_dough"
    },
    {
      "item": "delightful:nut_dough"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:nut_burger"
  },
  "temperature": 250
});

//恶魂汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "mynethersdelight:ghast_dough"
    },
    {
      "item": "mynethersdelight:ghast_dough"
    },
    {
      "item": "mynethersdelight:ghast_dough"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:ghast_burger"
  },
  "temperature": 250
});

//香蕉汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "manors_bounty:cooked_banana"
    },
    {
      "item": "manors_bounty:cooked_banana"
    },
    {
      "item": "manors_bounty:cooked_banana"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:banana_burger"
  },
  "temperature": 250
});

//马铃薯汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "tag": "forge:butter"
    },
    {
      "item": "minecraft:baked_potato"
    },
    {
      "item": "minecraft:baked_potato"
    },
    {
      "item": "minecraft:baked_potato"
    }
  ],
  "output": {
    "count": 2,
    "item": "list:potato_burger"
  },
  "temperature": 250
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'untameddelight:sliced_bear'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'alexsmobsdelight:raw_bear_meat_slice',  
          count: 2,
          chance: 1.0
        }
      ]
    });

/*
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:butter"
    },
    {
      "tag": "fabric:yeast"
    },
    {
      "item": ""
    },
    {
      "item": ""
    },
    {
      "item": ""
    },
    {
      "item": ""
    }
  ],
  "output": {
    "count": 3,
    "item": ""
  },
  "temperature": 250
});
*/



});

/*
event.custom({
  "type": "manors_bounty_machine:teapot",
  "container": {
    "item": 
  },
  "input": [
    {
      "item": 
    },
    {
      "item": 
    },
    {
      "item": 
    },
    {
      "item": 
    }
  ],
  "output": {
    "item": 
  }
});

event.recipes.farmersdelight.cooking(
    [
      ,
      
    ],
    Item.of(, 1), 
    50, 
    300, 
);

event.recipes.create.cutting(
        [
            Item.of(, 5),
            Item.of(, 2)
        ],
       
    )

event.custom({
        "type": "barbequesdelight:grilling",
        "barbecuingTime": 720, 
        "ingredient": { 
            "item": 
        },
        "output": { 
            "item": 
        }
});
  
event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: ,  
          count: 1,
          chance: 1.0
        },
        {
          item: ,  
          count: 1,
          chance: 1.0
        },
        {
          item: ,  
          count: 1,
          chance: 1.0
        },
        {
          item: ,  
          count: 1,
          chance: 1.0
        }
      ]
});



event.recipes.farmersdelight.cooking(
    [],
    Item.of(, 1), 
    50, 
    300, 
   
);


庄园馀话
event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"minecraft:sugar"
    },
    {
      "item":""
    },
    {
      "item":""
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": ""
  },
  "temperature": 3
});

"basefluid": {
    "count": 1000,
    "fluid": "minecraft:milk"
  },

event.custom({
  "type": "brewinandchewin:fermenting",  
  "experience": 1.0,
  "fermentingtime": 12000,
  "ingredients": [
    {
      "item":"manors_bounty:bottled_water"
    },
    {
      "item":""
    },
    {
      "item":""
    },
    {
      "item":""
    }
  ],
  "recipe_book_tab": "meals",
  "result": {
    "count": 1,
    "item": ""
  },
  "temperature": 4
});
*/
/*
妖怪们的归家料理板json解析

cuisine_fixed（固定料理）

{
  "type": "youkaishomecoming:cuisine_fixed",
  "base": "<基础料理或物品ID>",
  "result": {
    "item": "<输出物品ID>"
  }
}

cuisine_ordered（有序料理）

{
  "type": "youkaishomecoming:cuisine_ordered",
  "base": "<基础料理或物品ID>",
  "input": [
    { "item": "<第1步投入的物品ID>" },
    { "tag": "<第2步投入的标签>" }
    // ...可以继续加更多步骤
  ],
  "result": {
    "item": "<输出物品ID>"
  }
}

event.custom({
  
  "type": "youkaishomecoming:cuisine_ordered",
  "base": "manors_bounty:sumeshi",
  "input": [
    { "item": "manors_bounty:surimi_crab_stick" },
    { "item": "manors_bounty:nori" }
  ],
  "result": {
    "item": "manors_bounty:surimi_crab_stick_nigiri"
  }
});

event.recipes.farmersdelight.cooking(
    [],
    Item.of('', 1), 
    50, 
    300, 
    'manors_bounty:marble_bowl'
);

*/



/*
Manor's Bounty Mod 机器处理配方JSON格式详解
这个Mod中有多种类型的机器，每种机器都有自己特定的处理配方格式。以下是各种机器的配方结构：

1. 搅拌机（Blender）配方
json
{
  "type": "manors_bounty_machine:blender",
  "container": {
    "item": "manors_bounty:deformed_glass_bottle"
  },
  "mainInput": [
    {
      "item": "manors_bounty:apple_slice"
    }
  ],
  "secondaryInput": [
    {
      "item": "manors_bounty:apple_slice"
    }
  ],
  "output": {
    "count": 1,
    "item": "manors_bounty:apple_juice"
  }
}
使用mainInput和secondaryInput指定输入原料
通过container指定输出容器
2. 发酵器（Fermenter）配方
json
{
  "type": "manors_bounty_machine:normal_fermentation",
  "container": {
    "item": "manors_bounty:deformed_wine_bottle"
  },
  "cookingTime": 2400,
  "input": [
    {
      "item": "minecraft:wheat"
    }
  ],
  "output": {
    "count": 1,
    "item": "manors_bounty:absinthe"
  }
}
包含cookingTime参数控制处理时间
通过container指定存储容器
3. 烤箱（Oven）配方
json
{
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "tag": "forge:dough/wheat"
    }
  ],
  "output": {
    "count": 1,
    "item": "manors_bounty:baguette"
  },
  "temperature": 250
}
包含temperature参数指定温度
有cookingTime参数控制烘焙时间
4. 切菜板（Cutting Board）配方
json
{
  "type": "manors_bounty_machine:cutting_board_single",
  "input": {
    "item": "minecraft:apple"
  },
  "output": {
    "count": 3,
    "item": "manors_bounty:apple_slice"
  },
  "outgrowths": [
    {
      "chance": 1.0,
      "count": 1,
      "item": "manors_bounty:apple_seed"
    }
  ],
  "tool": {
    "tag": "forge:tools/knives"
  }
}
使用outgrowths指定副产物及其概率
通过tool指定所需的工具类型
5. 炸锅（Fryer）配方
json
{
  "type": "manors_bounty_machine:fast_fry",
  "input": {
    "tag": "forge:cooked_whole_chicken"
  },
  "output": {
    "item": "manors_bounty:fried_chicken"
  }
}
分为fast_fry和slow_fry两种类型，代表快速和慢速烹饪

茶壶（Teapot）机器处理配方
茶壶是一种特殊的机器方块，用于冲泡饮料（如咖啡、茶等）。它的配方格式有以下特点：

茶壶配方JSON结构
json
{
  "type": "manors_bounty_machine:teapot",
  "container": {
    "item": "manors_bounty:reactive_glaze_mug"
  },
  "input": [
    {
      "item": "manors_bounty:bottled_water"
    },
    {
      "item": "manors_bounty:coffee_powder"
    },
    {
      "item": "manors_bounty:boxed_milk"
    },
    {
      "item": "manors_bounty:cocoa_powder"
    }
  ],
  "output": {
    "item": "manors_bounty:cappuccino"
  }
}
  
*/