ServerEvents.tags('item', event => {
    event.add('forge:all_orange', 'bountifulfares:orange');
    event.add('forge:all_orange', 'fruitfulfun:orange');
    event.add('forge:all_orange', 'manors_bounty:orange');
    event.add('forge:all_orange', 'fruitsdelight:orange');
    event.add('forge:all_orange', 'fruitfulfun:tangerine');

    event.add('forge:papper2','minecolonies:nether_pepper')
    event.add('forge:papper2','vintagedelight:ghost_pepper')
    event.add('forge:papper2','manors_bounty:jalapeno')
    event.add('forge:papper2','muffins_thaidelight:pepper')

    event.add('neoforge:venison2', 'wildernature:venison'); 
    event.add('neoforge:venison2', 'naturalist:venison'); 
    event.add('neoforge:venison2', 'biologica:raw_elk'); 

    event.add('neoforge:orange2', 'fruitsdelight:orange'); 
    event.add('neoforge:orange2', 'fruitfulfun:orange');

    event.add('forge:salt_two', 'manors_bounty:salt_shaker'); 
    event.add('forge:salt_two', 'vintagedelight:salt_dust');

    event.add('forge:muscat_grape', 'manors_bounty:muscat_grape');
    event.add('forge:muscat_grape', 'vinery:jungle_grapes_white');
    event.add('forge:muscat_grape', 'vinery:savanna_grapes_white');
    event.add('forge:muscat_grape', 'vinery:taiga_grapes_white');
    event.add('forge:muscat_grape', 'vinery:white_grape');

    event.add('forge:red_grape_two', 'vinery:jungle_grapes_red');
    event.add('forge:red_grape_two', 'vinery:taiga_grapes_red');
    event.add('forge:red_grape_two', 'vinery:red_grape');
    event.add('forge:red_grape_two', 'vinery:savanna_grapes_red');
    event.add('forge:red_grape_two', 'youkaishomecoming:black_grape');

    event.add('forge:sugar_cane', 'manors_bounty:purple_sugar_cane');
    event.add('forge:sugar_cane', 'minecraft:sugar_cane');

    event.add('shop:meal_restaurant', 'cuisinedelight:ham_fried_rice');
    event.add('shop:meal_restaurant', 'cuisinedelight:fried_rice');
    event.add('shop:meal_restaurant', 'cuisinedelight:mixed_fried_rice');
    //event.add('shop:meal_restaurant', );

    //删除
    event.remove('forge:raw_beef','mystias_izakaya:niu_rou');
    event.remove('forge:crops/onion','mystias_izakaya:yang_cong');
    event.remove('forge:ice_cubes','mystias_izakaya:bing_kuai');
    event.remove('forge:salt','mystias_izakaya:hei_yan');
    //event.remove('','mystias_izakaya:ji_dan');
    event.removeAllTagsFrom('mystias_izakaya:ji_dan') 
    event.removeAllTagsFrom('mystias_izakaya:mo_gu') 
    event.removeAllTagsFrom('mystias_izakaya:ning_meng') 
    event.removeAllTagsFrom('mystias_izakaya:mian_fen') 
    event.removeAllTagsFrom('mystias_izakaya:zhi_shi') 
    event.remove('rusticdelight:coffee_ingredients','manors_bounty:coffee_berry');
    event.removeAllTagsFrom('manors_bounty:coffee_berry') 

    event.remove('neoforge:coconut','braziliandelight:coconut_slice');
    event.remove('sereneseasons:winter_crops','fruitfulfun:lime_sapling');
    event.remove('sereneseasons:spring_crops','fruitfulfun:lime_sapling');

    event.remove('sereneseasons:autumn_crops','fruitfulfun:grapefruit_sapling');
    event.remove('sereneseasons:spring_crops','fruitfulfun:grapefruit_sapling');
    event.remove('sereneseasons:summer_crops','fruitfulfun:grapefruit_sapling');

    event.remove('sereneseasons:spring_crops','fruitfulfun:pomelo_sapling');
    event.remove('sereneseasons:autumn_crops','fruitfulfun:pomelo_sapling');
    event.remove('sereneseasons:winter_crops','fruitfulfun:pomelo_sapling');

    event.remove('sereneseasons:spring_crops','fruitfulfun:citron_sapling');
    event.remove('sereneseasons:summer_crops','fruitfulfun:citron_sapling');
    event.remove('sereneseasons:winter_crops','fruitfulfun:citron_sapling');

    event.remove('sereneseasons:winter_crops','fruitfulfun:redlove_sapling');
    event.remove('sereneseasons:spring_crops','fruitfulfun:redlove_sapling');

    event.remove('sereneseasons:summer_crops','foragersinsight:bountiful_spruce_sapling');

    
    event.remove('sereneseasons:summer_crops','rusticdelight:coffee');
    event.remove('sereneseasons:autumn_crops','rusticdelight:coffee');


    const alexCakeBlocks = [
        'alexscaves:cake_layer',
        'alexscaves:block_of_chocolate_frosting',
        'alexscaves:block_of_vanilla_frosting',
        'alexscaves:block_of_frosting',
        'alexscaves:block_of_frosted_chocolate',
        'alexscaves:block_of_chiseled_chocolate',
        'alexscaves:block_of_polished_chocolate',
        'alexscaves:block_of_chocolate',
        'alexscaves:cookie_block',
        'alexscaves:dough_block'
    ];
    
    alexCakeBlocks.forEach(block => {
        event.add('alexcave:cake', block);
    });

    const alexCavegingerbread = [
        'alexscaves:frosted_gingerbread_door',
        'alexscaves:frosted_gingerbread_brick_slab', 
        'alexscaves:frosted_gingerbread_brick_stairs',
        'alexscaves:frosted_gingerbread_bricks', 
        'alexscaves:frosted_gingerbread_wall',
        'alexscaves:frosted_gingerbread_slab', 
        'alexscaves:frosted_gingerbread_stairs', 
        'alexscaves:gingerbarrel',
        'alexscaves:frosted_gingerbread_block',
        'alexscaves:gingerbread_slab', 
        'alexscaves:gingerbread_wall', 
        'alexscaves:gingerbread_door', 
        'alexscaves:gingerbread_bricks', 
        'alexscaves:gingerbread_brick_stairs', 
        'alexscaves:gingerbread_brick_slab', 
        'alexscaves:gingerbread_brick_wall', 
        'alexscaves:gingerbread_stairs', 
        'alexscaves:gingerbread_block', 
        'alexscaves:frosted_gingerbread_brick_wall'
    ];
    
    alexCavegingerbread.forEach(block => {
        event.add('alexcave:gingerbread', block);
    });

    // 添加糖果 cane 相关方块
    const alexCandyCaneBlocks = [
        'alexscaves:candy_cane',
        'alexscaves:candy_cane_block',
        'alexscaves:chiseled_candy_cane_block',
        'alexscaves:large_peppermint',
        'alexscaves:small_peppermint',
        'alexscaves:stripped_candy_cane_pole',
        'alexscaves:candy_cane_pole',
        'alexscaves:stripped_candy_cane_block',
        'alexscaves:sprinkles'
    ];
    
    alexCandyCaneBlocks.forEach(block => {
        event.add('alexscaves:candy', block);
    });

    event.add('alexscaves:gummy_ring', 'alexscaves:gummy_ring_pink');
    event.add('alexscaves:gummy_ring', 'alexscaves:gummy_ring_blue');
    event.add('alexscaves:gummy_ring', 'alexscaves:gummy_ring_yellow');
    event.add('alexscaves:gummy_ring', 'alexscaves:gummy_ring_green');
    event.add('alexscaves:gummy_ring', 'alexscaves:gummy_ring_red');

//这玩意不纯为了一叠醋包了一盘饺子？？
    const reberry = [
        //正宗浆果
        'bountifulfares:tea_berries',
        'vintagedelight:gearo_berry',
        'frightsdelight:wither_berry',
        'frightsdelight:soul_berry',
        'coffee_delight:coffee_berries',
        'farmersrespite:coffee_berries',
        'minecraft:sweet_berries',
        'minecraft:glow_berries',
        'braziliandelight:coffee_berries',

        //莓 因为在分类学上莓果也是浆果
        'bountifulfares:elderberries',
        'fruitsdelight:cranberry',
        'fruitsdelight:blueberry',
        'braziliandelight:acai_berries',
        'manors_bounty:blackcurrant',
        'cosmopolitan:wildberry',
        'manors_bounty:gooseberry',
        'cosmopolitan:arbutus_berries',
        'bountifulfares:lapisberries',

        //意想不到的浆果
        //瓜类
        'minecraft:melon',
        'minecraft:pumpkin',
        'delightful:cantaloupe',
        'fruitsdelight:hamimelon',
        'bountifulfares:spongekin',
        'vintagedelight:cucumber',
        'muffins_thaidelight:raw_papaya',
        'muffins_thaidelight:papaya',
        //番茄
        'argentinas_delight:tomatitos_cherry',
        'manors_bounty:tomato',
        'avaritia_delight:blaze_tomato',
        'farmersdelight:tomato',
        'manors_bounty:cherry_tomatoes',
        //柑橘
        'fruitsdelight:orange',
        'fruitfulfun:tangerine',
        'bountifulfares:orange',
        'fruitsdelight:lemon',
        'collectorsreap:lime',
        'manors_bounty:yuzumelo',
        'manors_bounty:grapefruit',
        'fruitfulfun:citron',
        'fruitfulfun:lime',
        //辣椒
        'peruviansdelight:aji_amarillo',
        'muffins_thaidelight:pepper',
        'manors_bounty:jalapeno',
        'manors_bounty:end_pepper',
        'vintagedelight:ghost_pepper',
        'rusticdelight:bell_pepper_yellow',
        'rusticdelight:bell_pepper_green',
        'rusticdelight:bell_pepper_red',
        //葡萄
        'youkaishomecoming:black_grape',
        'nethervinery:crimson_grape',
        'nethervinery:warped_grape',
        'vinery:red_grape',
        'vinery:jungle_grapes_white',
        'vinery:savanna_grapes_red',
        'vinery:savanna_grapes_white',
        'vinery:taiga_grapes_red' ,
        'vinery:taiga_grapes_white',
        'vinery:jungle_grapes_red',
        'vinery:white_grape',
        'manors_bounty:muscat_grape',
        //其他，不查文献真不知道
        'braziliandelight:guarana_fruit',
        'culturaldelights:avocado',
        'neapolitan:banana_bunch',
        'culturaldelights:eggplant',
        'culturaldelights:white_eggplant',
        'braziliandelight:coconut',
        'braziliandelight:green_coconut',
        'manors_bounty:olive_fruit',
        'manors_bounty:black_olive_fruit',
        'collectorsreap:pink_dragon_fruit',
        'fruitsdelight:fig',
        'minecraft:cocoa_beans',
        'fruitsdelight:lychee',
        'fruitsdelight:kiwi',
        'manors_bounty:gold_kiwifruit',
        'fruitsdelight:mangosteen',
        'bountifulfares:passion_fruit',
        'yungscavebiomes:prickly_peach',
        'manors_bounty:starfruit',
        'argentinas_delight:membrillo',
        'fruitsdelight:bayberry',
        'nethers_exoticism:ramboutan',
        'nethers_exoticism:jaboticaba',
        'nethers_exoticism:kiwano_peel',
        'fruitsdelight:durian',
        'manors_bounty:musang_king_durian',

        //假浆果 草莓 黑加仑等 事实上他们不是浆果
        'delighto_flight:cloud_berries',
        'delightful:salmonberries',
        'manors_bounty:blackberry',
        'neapolitan:strawberries',
        'neapolitan:white_strawberries',
        'hearthandharvest:raspberry'

        //植物家族千千万，浆果过来祸害下

    ];
    
    reberry.forEach(block => {
        event.add('modpack:berry', block);
    });

//柑橘类
    const reorange = [
        'fruitsdelight:orange',
        'fruitfulfun:tangerine',
        'bountifulfares:orange',
        'fruitsdelight:lemon',
        'collectorsreap:lime',
        'manors_bounty:yuzumelo',
        'manors_bounty:grapefruit',
        'fruitfulfun:citron',
        'fruitfulfun:lime'
    ];
    
    reorange.forEach(block => {
        event.add('modpack:orange', block);
    });

    event.add('forge:nuggets/silver', 'kubejs:tin_nugget'); 
    event.add('forge:nuggets/tin', 'kubejs:nickel_nugget'); 
    event.add('forge:nuggets/nickel', 'kubejs:silver_nugget'); 
    event.add('forge:nuggets/aluminium', 'kubejs:aluminium_nugget'); 
    event.add('forge:nuggets/aluminum', 'kubejs:aluminium_nugget');

     const reore_sugarcane = [
        'growable_ores:redstone_cane',
        'growable_ores:nether_quartz_cane',
        'growable_ores:lapis_cane',
        'growable_ores:gold_cane',
        'growable_ores:emerald_cane',
        'growable_ores:copper_cane',
        'growable_ores:diamond_cane',
        'growable_ores:iron_cane',
        'growable_ores:coal_cane',
        'growable_ores:amethyst_shard_cane',
        'growable_ores:c_zinc_ore_cane',
        'growable_ores:certus_quartz_crystal_cane',
        'growable_ores:netherite_scrap_cane'
    ];
    
    reore_sugarcane.forEach(block => {
        event.add('modpack:ore_sugarcane', block);
    });

    const cheese = [
        'extravagantdelight:white_cheese_wedge',
        'pizzacraft:cheese', 
        'create_bic_bit:young_cheese_wedge',
        'dungeonsdelight:wardenzola_crumbles',
        'create_bic_bit:unripe_cheese_wedge',
        'unusualfoodsdelight:soft_cheese_cube', 
        'brewinandchewin:scarlet_cheese_wedge',
        'meadow:piece_of_warped_cheese', 
        'meadow:piece_of_sheep_cheese',
        'casualness_delight:cheese_wheel_slice',
        'fastfooddelight:cheese', 
        'brewinandchewin:flaxen_cheese_wedge', 
        'manors_bounty:emmental_cheese_wedge', 
        'trailandtales_delight:cherry_cheese_slice', 
        'trailandtales_delight:cherry_cheese_pie_slice', 
        'vintagedelight:cheese_slice', 
        'trailandtales_delight:cheese_slice', 
        'manors_bounty:cheddar_cheese_wedge', 
        'hearthandharvest:cheddar_cheese_slice', 
        'create_bic_bit:aged_cheese_wedge', 
        'hearthandharvest:goat_cheese_slice', 
        'extravagantdelight:hereford_hop_cheese_wedge', 
        'braziliandelight:minas_cheese_slice', 
        'manors_bounty:mozzarella_cheese_wedge', 
        'meadow:piece_of_amethyst_cheese', 
        'meadow:piece_of_buffalo_cheese', 
        'meadow:piece_of_cheese',
        'meadow:piece_of_grain_cheese', 
        'meadow:piece_of_goat_cheese',
        'create_bic_bit:young_cheese_wedge',
        'list:gorgonzola_cheese_slice',
        'dungeonsdelight:wardenzola_crumbles',
        'meadow:piece_of_buffalo_cheese'
    ];
    
    cheese.forEach(block => {
        event.add('modpack:cheese', block);
    });

    event.remove('forge:vegetables','mystias_izakaya:xi_lan_hua');
    event.remove('forge:vegetables/broccoli','mystias_izakaya:xi_lan_hua');
    event.remove('foragersinsight:handbasket_allowed','mystias_izakaya:xi_lan_hua');

    //event.add('modpack:',)
    event.add('modpack:mango','fruitsdelight:mango');
    event.add('modpack:mango','extravagantdelight:green_mango');
    event.add('modpack:mango','extravagantdelight:lush_mango');

    event.add('modpack:mango_slice','manors_bounty:mango_slice')
    event.add('modpack:mango_slice','extravagantdelight:lush_mango_slice')
    event.add('modpack:mango_slice','extravagantdelight:green_mango_slice')

    event.add('forge:fruits/mango','extravagantdelight:green_mango')

    event.add('modpack:salmon','minecraft:salmon');
    event.add('modpack:salmon','list:deep_sea_salmon');

    event.add('modpack:cod','minecraft:cod')
    event.add('modpack:cod','aquaculture:atlantic_cod')
    event.add('modpack:cod','aquaculture:pollock')

    event.add('modpack:chicken_egg','manors_bounty:bresse_chicken_egg')
    event.add('modpack:chicken_egg','minecraft:egg')

    event.add('modpack:raw_beef_cubes','manors_bounty:raw_beef_cubes')
    event.add('modpack:raw_beef_cubes','farmersdelight:minced_beef')

    event.add('modpack:caramel','create_confectionery:bar_of_caramel')
    event.add('modpack:caramel','gelato_galore:caramel')
    event.add('modpack:caramel','create_confectionery:caramel_bucket')
    event.add('modpack:caramel','manors_bounty:coconut_sugar_caramel')

    event.add('modpack:yerba','braziliandelight:dried_yerba_mate')
    event.add('modpack:yerba','braziliandelight:yerba_mate_leaves')
    event.add('modpack:yerba','argentinas_delight:yerbamate')

    event.remove('forge:vegetables/corn','immortalers_delight:evolutcorn');
    event.remove('forge:vegetables/corn','immortalers_delight:evolutcorn_grains');

//沉浸农艺
    const feeding_trough_fodder = [
        'dumplings_delight:chinese_cabbage_leaf', 'avaritia_delight:crystal_cabbage_leaf', 'manors_bounty:pomegranate_seed', 'veggiesdelight:garlic_clove', 'immortalers_delight:pearlipearl', 'veggiesdelight:zucchini_slice', 'manors_bounty:yuzumelo_wedge', 'peruviansdelight:yuca_cortada', 'manors_bounty:wild_jalapeno_slice', 'culturaldelights:cut_eggplant', 'manors_bounty:dragon_fruit_slice', 'some_assembly_required:enchanted_golden_apple_slices', 'manors_bounty:hawthorn_flakes', 'manors_bounty:jalapeno_slice', 'manors_bounty:kiwifruit_slice', 'fruitsdelight:lemon_slice', 'collectorsreap:lime_slice', 'extravagantdelight:lush_mango_slice', 'manors_bounty:starfruit_slice', 'manors_bounty:tomato_slice', 'some_assembly_required:tomato_slices', 'manors_bounty:pear_slice', 'manors_bounty:peach_slice', 'muffins_thaidelight:papaya_slice', 'fruitsdelight:pineapple_slice', 'manors_bounty:plum_slice', 'collectorsreap:pomegranate_slice', 'rusticdelight:potato_slices', 'oceanic_delight:sea_pickle_slices', 'unusual_delight:shroomlight_slice', 'nethers_exoticism:sliced_kiwano', 'some_assembly_required:sliced_onion', 'bountifulfares:spongekin_slice', 'manors_bounty:mango_slice', 'manors_bounty:musang_king_durian_flesh', 'fruitsdelight:orange_slice',
        'manors_bounty:half_of_kiwifruit', 'manors_bounty:half_of_gold_kiwifruit', 'extravagantdelight:green_mango_slice', 'manors_bounty:green_apple_slice', 'manors_bounty:grapefruit_slice', 'some_assembly_required:golden_apple_slices', 'manors_bounty:gold_kiwifruit_slice', 'manors_bounty:end_pepper_slice', 'manors_bounty:fig_slice', 'some_assembly_required:apple_slices', 'manors_bounty:avocado_slice', 'manors_bounty:banana_slice', 'peruviansdelight:camote_cortado', 'delightful:cantaloupe_slice', 'some_assembly_required:chopped_beetroot', 'nethers_exoticism:chopped_bouddha_s_hand', 'some_assembly_required:chopped_carrot', 'some_assembly_required:chopped_golden_carrot', 'braziliandelight:coconut_slice', 'culturaldelights:cut_avocado', 'culturaldelights:cut_cucumber',
        'vintagedelight:cucumber_noodles', 'youkaishomecoming:cucumber_slice','collectorsreap:dried_pink_dragon_fruit','casualness_delight:potato_slice','oddsnends:anthesi_fruit_half','vietnam_delight:banana_blossom_shredded', 'vietnam_delight:lotus_embryo', 'delighto_flight:lotus_seeds', 'vietnam_delight:young_lotus_stem','vietnam_delight:mung_beans','vietnam_delight:golden_plum','immortalers_delight:gelpitaya_flesh','manors_bounty:blackberry', 'manors_bounty:black_olive_fruit', 'youkaishomecoming:black_grape', 'fruitsdelight:bayberry', 'neapolitan:banana_bunch', 'culturaldelights:avocado', 'cosmopolitan:arbutus_berries', 'manors_bounty:apricot', 'braziliandelight:acai_berries', 'nethers_exoticism:kiwano', 'brewincompatdelight:juniper_berries', 'vinery:jungle_grapes_white', 'vinery:jungle_grapes_red', 'nethers_exoticism:jaboticaba', 'ltc2:illage_lime', 'bountifulfares:hoary_apple', 'immortalers_delight:himekaido', 'braziliandelight:guarana_fruit', 'extravagantdelight:green_mango', 'manors_bounty:green_apple', 'manors_bounty:grapefruit', 'manors_bounty:cherries', 'vinery:cherry', 'manors_bounty:cherry_tomatoes', 'fruitfulfun:citron', 'delighto_flight:cloud_berries', 'nethervinery:crimson_grape', 'ramadandelight:date', 'bountifulfares:elderberries', 'forestry:fruit_chestnut', 'vintagedelight:gearo_berry', 'manors_bounty:gold_kiwifruit', 'manors_bounty:gooseberry', 'mynethersdelight:bullet_pepper', 'nethers_exoticism:bouddha_s_hand', 'manors_bounty:blackcurrant',
        'extravagantdelight:muscadine_grapes', 'argentinas_delight:membrillo', 'extravagantdelight:lush_mango', 'fruitfulfun:lime', 'collectorsreap:lime', 'bountifulfares:lapisberries', 'trailandtales_delight:lantern_fruit', 'foragersinsight:black_acorn', 'seeddelight:acorn', 'seeddelight:sunflower_seed', 'collectorsreap:stygian_pomegranate', 'neapolitan:strawberries', 'manors_bounty:starfruit', 'frightsdelight:soul_berry', 'extravagantdelight:sloe_berries', 'vinery:savanna_grapes_white', 'vinery:savanna_grapes_red', 'delightful:salmonberries', 'seeddelight:rosehip', 'fruitfulfun:redlove', 'vinery:red_grape', 'muffins_thaidelight:papaya', 'bountifulfares:passion_fruit', 'immortalers_delight:pearlip', 'fruitsdelight:persimmon', 'fruitsdelight:pineapple', 'collectorsreap:pink_dragon_fruit', 'bountifulfares:plum', 'collectorsreap:pomegranate', 'extravagantdelight:quince', 'nethers_exoticism:ramboutan', 'hearthandharvest:raspberry', 'muffins_thaidelight:raw_papaya', 'bountifulfares:orange', 'manors_bounty:olive_fruit', 'manors_bounty:muscat_grape','manors_bounty:ume', 'bountifulfares:walnut', 'nethervinery:warped_grape', 'immortalers_delight:warped_laurel', 'legendarysurvivaloverhaul:water_plant_bag', 'vinery:white_grape', 'neapolitan:white_strawberries', 'cosmopolitan:wildberry', 'frightsdelight:wither_berry', 'vinery:taiga_grapes_red', 'vinery:taiga_grapes_white', 'delighto_flight:thunder_fruit',
        'youkaishomecoming:udumbara_flower', 'netherdepthsupgrade:warped_kelp', 'cosmopolitan:fiddlehead', 'cosmopolitan:wheatgrass', 'vital_herbs:fizz_fruit', 'vital_herbs:iron_root', 'vintagedelight:peanut', 'immortalers_delight:pearlip', 'endersdelight:chorusflame', 'manors_bounty:jalapeno', 'spanishdelight:green_bean', 'argentinas_delight:espinacaitem', 'youkaishomecoming:mandrake_root', 'ramadandelight:parsley', 'culturaldelights:white_eggplant', 'culturaldelights:eggplant', 'rusticdelight:bell_pepper_yellow', 'rusticdelight:bell_pepper_red', 'ubesdelight:lemongrass', 'neapolitan:mint_leaves', 'muffins_thaidelight:pepper', 'dumplings_delight:fennel', 'peruviansdelight:aji_amarillo', 'vintagedelight:cucumber', 'veggiesdelight:dandelion_leaf', 'foragersinsight:dandelion_root', 'extravagantdelight:rhubarb', 'manors_bounty:end_pepper', 'vintagedelight:ghost_pepper', 'vital_herbs:snap_pepper', 'ltc2:pepper_frost', 'ltc2:pepper_bloody', 'ltc2:pepper_complained', 'ltc2:pepper_green', 'yeastnfeast:ginger', 'netherdepthsupgrade:crimson_kelp',
        'veggiesdelight:broccoli', 'avaritia_delight:blaze_tomato', 'bountifulfares:leek', 'avaritia_delight:crystal_cabbage', 'dumplings_delight:chinese_cabbage', 'rusticdelight:bell_pepper_green', 'manors_bounty:wild_jalapeno', 'veggiesdelight:zucchini', 'manors_bounty:tomato', 'braziliandelight:collard_greens', 'dumplings_delight:garlic_chive', 'veggiesdelight:turnip', 'braziliandelight:garlic_bulb', 'veggiesdelight:cauliflower', 'dumplings_delight:greenonion',
        'manors_bounty:dragon_fruit','collectorsreap:lucuma','oddsnends:ciderine','oddsnends:anthesi_fruit','collectorsreap:lucuma','vietnam_delight:bird_eye_chilis', 'vietnam_delight:turmeric', 'vietnam_delight:shallot', 'vietnam_delight:lotot_leaf', 'vietnam_delight:pandan_leaf', 'delighto_flight:lotus_root', 'vietnam_delight:green_banana_bunch', 'vietnam_delight:banana_blossom', 'vietnam_delight:basil_leaf', 'vietnam_delight:bean_sprouts', 'vietnam_delight:green_kumquat', 'vietnam_delight:kumquat','vietnam_delight:garlic_chives',
        'manors_bounty:banana_tree_flower_item','farm_and_charm:lettuce','immortalers_delight:gelpitaya','manors_bounty:holly_berry','immortalers_delight:sextlotus_root','immortalers_delight:oxygrape',
        'avaritia_delight:diamond_lattice_potato','trailandtales_delight:pitcher_taro','uwabami_breakers:konjak','manors_bounty:baby_corn', 'braziliandelight:corn','mynethersdelight:ghasta','avaritia_delight:raw_crystal_pasta','dungeonsdelight:slime_noodles','ubesdelight:ube','dungeonsdelight:rotbulb','peruviansdelight:papas_fritas','avaritia_delight:diamond_lattice_fries','create_bic_bit:raw_fries',
        'mynethersdelight:ghasta',
        'mynethersdelight:ghasmati',
        'dungeonsdelight:slime_noodles',
        'seeddelight:raw_acorn_noodle',
        'vietnam_delight:sticky_rice',
        'immortalers_delight:travarice'
    ];
    
    feeding_trough_fodder.forEach(item => {
        event.add('farm_and_charm:feeding_trough_fodder', item);
    });

});

//event.remove('','');
//farm_and_charm:feeding_trough_fodder


