ServerEvents.tags('item', event => {

    /*
    VEG 蔬菜
    VEG_SZIE_ONE
    VEG_SZIE_TWO
    
    MEAT 肉类
    MEAT_EGG_SIZE_ONE
    MEAT_EGG_SIZE_THREE
    MEAT_SIZE_ONE_NUTRITION_ONE
    MEAT_SIZE_ONE_NUTRITION_TEN

    CARB 主食
    CARB_SIZE_ONE
    
    NONE 调料
    */

    //蔬菜 份量1
    const VEG_SZIE_ONE = [
        'dumplings_delight:chinese_cabbage_leaf', 'avaritia_delight:crystal_cabbage_leaf', 'manors_bounty:pomegranate_seed', 'veggiesdelight:garlic_clove', 'immortalers_delight:pearlipearl', 'veggiesdelight:zucchini_slice', 'manors_bounty:yuzumelo_wedge', 'peruviansdelight:yuca_cortada', 'manors_bounty:wild_jalapeno_slice', 'culturaldelights:cut_eggplant', 'manors_bounty:dragon_fruit_slice', 'some_assembly_required:enchanted_golden_apple_slices', 'manors_bounty:hawthorn_flakes', 'manors_bounty:jalapeno_slice', 'manors_bounty:kiwifruit_slice', 'fruitsdelight:lemon_slice', 'collectorsreap:lime_slice', 'extravagantdelight:lush_mango_slice', 'manors_bounty:starfruit_slice', 'manors_bounty:tomato_slice', 'some_assembly_required:tomato_slices', 'manors_bounty:pear_slice', 'manors_bounty:peach_slice', 'muffins_thaidelight:papaya_slice', 'fruitsdelight:pineapple_slice', 'manors_bounty:plum_slice', 'collectorsreap:pomegranate_slice', 'rusticdelight:potato_slices', 'oceanic_delight:sea_pickle_slices', 'unusual_delight:shroomlight_slice', 'nethers_exoticism:sliced_kiwano', 'some_assembly_required:sliced_onion', 'bountifulfares:spongekin_slice', 'manors_bounty:mango_slice', 'manors_bounty:musang_king_durian_flesh', 'fruitsdelight:orange_slice',
        'manors_bounty:half_of_kiwifruit', 'manors_bounty:half_of_gold_kiwifruit', 'extravagantdelight:green_mango_slice', 'manors_bounty:green_apple_slice', 'manors_bounty:grapefruit_slice', 'some_assembly_required:golden_apple_slices', 'manors_bounty:gold_kiwifruit_slice', 'manors_bounty:end_pepper_slice', 'manors_bounty:fig_slice', 'some_assembly_required:apple_slices', 'manors_bounty:avocado_slice', 'manors_bounty:banana_slice', 'peruviansdelight:camote_cortado', 'delightful:cantaloupe_slice', 'some_assembly_required:chopped_beetroot', 'nethers_exoticism:chopped_bouddha_s_hand', 'some_assembly_required:chopped_carrot', 'some_assembly_required:chopped_golden_carrot', 'braziliandelight:coconut_slice', 'culturaldelights:cut_avocado', 'culturaldelights:cut_cucumber',
        'vintagedelight:cucumber_noodles', 'youkaishomecoming:cucumber_slice',
        'collectorsreap:dried_pink_dragon_fruit',
        'casualness_delight:potato_slice',
        'oddsnends:anthesi_fruit_half',
        'vietnam_delight:banana_blossom_shredded', 'vietnam_delight:lotus_embryo', 'delighto_flight:lotus_seeds', 'vietnam_delight:young_lotus_stem',
        'vietnam_delight:mung_beans',
        'vietnam_delight:golden_plum',
        'immortalers_delight:gelpitaya_flesh',
    ];

    VEG_SZIE_ONE.forEach(item_cuisinedlight => {
        event.add('veg_size_one', item_cuisinedlight);
    });

    //蔬菜 份量2
    const VEG_SZIE_TWO = [
        'manors_bounty:blackberry', 'manors_bounty:black_olive_fruit', 'youkaishomecoming:black_grape', 'fruitsdelight:bayberry', 'neapolitan:banana_bunch', 'culturaldelights:avocado', 'cosmopolitan:arbutus_berries', 'manors_bounty:apricot', 'braziliandelight:acai_berries', 'nethers_exoticism:kiwano', 'brewincompatdelight:juniper_berries', 'vinery:jungle_grapes_white', 'vinery:jungle_grapes_red', 'nethers_exoticism:jaboticaba', 'ltc2:illage_lime', 'bountifulfares:hoary_apple', 'immortalers_delight:himekaido', 'braziliandelight:guarana_fruit', 'extravagantdelight:green_mango', 'manors_bounty:green_apple', 'manors_bounty:grapefruit', 'manors_bounty:cherries', 'vinery:cherry', 'manors_bounty:cherry_tomatoes', 'fruitfulfun:citron', 'delighto_flight:cloud_berries', 'nethervinery:crimson_grape', 'ramadandelight:date', 'bountifulfares:elderberries', 'forestry:fruit_chestnut', 'vintagedelight:gearo_berry', 'manors_bounty:gold_kiwifruit', 'manors_bounty:gooseberry', 'mynethersdelight:bullet_pepper', 'nethers_exoticism:bouddha_s_hand', 'manors_bounty:blackcurrant',
        'extravagantdelight:muscadine_grapes', 'argentinas_delight:membrillo', 'extravagantdelight:lush_mango', 'fruitfulfun:lime', 'collectorsreap:lime', 'bountifulfares:lapisberries', 'trailandtales_delight:lantern_fruit', 'foragersinsight:black_acorn', 'seeddelight:acorn', 'seeddelight:sunflower_seed', 'collectorsreap:stygian_pomegranate', 'neapolitan:strawberries', 'manors_bounty:starfruit', 'frightsdelight:soul_berry', 'extravagantdelight:sloe_berries', 'vinery:savanna_grapes_white', 'vinery:savanna_grapes_red', 'delightful:salmonberries', 'seeddelight:rosehip', 'fruitfulfun:redlove', 'vinery:red_grape', 'muffins_thaidelight:papaya', 'bountifulfares:passion_fruit', 'immortalers_delight:pearlip', 'fruitsdelight:persimmon', 'fruitsdelight:pineapple', 'collectorsreap:pink_dragon_fruit', 'bountifulfares:plum', 'collectorsreap:pomegranate', 'extravagantdelight:quince', 'nethers_exoticism:ramboutan', 'hearthandharvest:raspberry', 'muffins_thaidelight:raw_papaya', 'bountifulfares:orange', 'manors_bounty:olive_fruit', 'manors_bounty:muscat_grape',
        'manors_bounty:ume', 'bountifulfares:walnut', 'nethervinery:warped_grape', 'immortalers_delight:warped_laurel', 'legendarysurvivaloverhaul:water_plant_bag', 'vinery:white_grape', 'neapolitan:white_strawberries', 'cosmopolitan:wildberry', 'frightsdelight:wither_berry', 'vinery:taiga_grapes_red', 'vinery:taiga_grapes_white', 'delighto_flight:thunder_fruit',
        'youkaishomecoming:udumbara_flower', 'netherdepthsupgrade:warped_kelp', 'cosmopolitan:fiddlehead', 'cosmopolitan:wheatgrass', 'vital_herbs:fizz_fruit', 'vital_herbs:iron_root', 'vintagedelight:peanut', 'immortalers_delight:pearlip', 'endersdelight:chorusflame', 'manors_bounty:jalapeno', 'spanishdelight:green_bean', 'argentinas_delight:espinacaitem', 'youkaishomecoming:mandrake_root', 'ramadandelight:parsley', 'culturaldelights:white_eggplant', 'culturaldelights:eggplant', 'rusticdelight:bell_pepper_yellow', 'rusticdelight:bell_pepper_red', 'ubesdelight:lemongrass', 'neapolitan:mint_leaves', 'muffins_thaidelight:pepper', 'dumplings_delight:fennel', 'peruviansdelight:aji_amarillo', 'vintagedelight:cucumber', 'veggiesdelight:dandelion_leaf', 'foragersinsight:dandelion_root', 'extravagantdelight:rhubarb', 'manors_bounty:end_pepper', 'vintagedelight:ghost_pepper', 'vital_herbs:snap_pepper', 'ltc2:pepper_frost', 'ltc2:pepper_bloody', 'ltc2:pepper_complained', 'ltc2:pepper_green', 'yeastnfeast:ginger', 'netherdepthsupgrade:crimson_kelp',
        'veggiesdelight:broccoli', 'avaritia_delight:blaze_tomato', 'bountifulfares:leek', 'avaritia_delight:crystal_cabbage', 'dumplings_delight:chinese_cabbage', 'rusticdelight:bell_pepper_green', 'manors_bounty:wild_jalapeno', 'veggiesdelight:zucchini', 'manors_bounty:tomato', 'braziliandelight:collard_greens', 'dumplings_delight:garlic_chive', 'veggiesdelight:turnip', 'braziliandelight:garlic_bulb', 'veggiesdelight:cauliflower', 'dumplings_delight:greenonion',
        'manors_bounty:dragon_fruit',
        'collectorsreap:lucuma',
        'oddsnends:ciderine',
        'oddsnends:anthesi_fruit',
        'collectorsreap:lucuma',
        'vietnam_delight:bird_eye_chilis', 'vietnam_delight:turmeric', 'vietnam_delight:shallot', 'vietnam_delight:lotot_leaf', 'vietnam_delight:pandan_leaf', 'delighto_flight:lotus_root', 'vietnam_delight:green_banana_bunch', 'vietnam_delight:banana_blossom', 'vietnam_delight:basil_leaf', 'vietnam_delight:bean_sprouts', 'vietnam_delight:green_kumquat', 'vietnam_delight:kumquat',
        'vietnam_delight:garlic_chives',
        'manors_bounty:banana_tree_flower_item',
        'farm_and_charm:lettuce',
        'immortalers_delight:gelpitaya',
        'manors_bounty:holly_berry','immortalers_delight:sextlotus_root','immortalers_delight:oxygrape',

    ];

    VEG_SZIE_TWO.forEach(item_cuisinedlight => {
        event.add('veg_size_two', item_cuisinedlight);
    });

    //肉类-小型蛋类 份量1
    const MEAT_EGG_SIZE_ONE = [
        'unusualprehistory:ulugh_eggs', 'unusualprehistory:antarcto_eggs', 'unusualprehistory:austro_eggs', 'unusualprehistory:anuro_eggs', 'manors_bounty:turkey_egg', 'manors_bounty:bresse_chicken_egg', 'manors_bounty:mallard_duck_egg', 'untitledduckmod:goose_egg', 'minecraft:egg', 'unusualprehistory:rex_eggs', 'unusual_delight:sculked_egg', 'unusualprehistory:trike_eggs', 'unusualprehistory:majunga_eggs', 'unusualprehistory:raptor_eggs', 'unusualprehistory:barina_eggs', 'alexscaves:vallumraptor_egg', 'unusualprehistory:megala_eggs', 'alexscaves:subterranodon_egg', 'minecraft:turtle_egg', 'naturalist:alligator_egg', 'naturalist:tortoise_egg', 'unusualprehistory:pachy_eggs', 'unusualprehistory:hwacha_eggs', 'unusualprehistory:kentro_eggs',
        'alexsmobs:terrapin_egg','alexsmobs:crocodile_egg','alexsmobs:platypus_egg','alexsmobs:caiman_egg','alexsmobs:emu_egg'
    ];

    MEAT_EGG_SIZE_ONE.forEach(item_cuisinedlight => {
        event.add('meat_egg_size_one', item_cuisinedlight);
    });

    //肉类-大型蛋类 份量3 营养10
    const MEAT_EGG_SIZE_THREE = [
        'alexscaves:tremorzilla_egg', 'alexscaves:atlatitan_egg', 'alexscaves:relicheirus_egg', 'alexscaves:tremorsaurus_egg', 'alexscaves:grottoceratops_egg', 'unusualprehistory:brachi_egg', 'unusualprehistory:coty_eggs', 'minecraft:sniffer_egg', 'ends_delight:non_hatchable_dragon_egg', 'unusualprehistory:talpanas_egg',

    ];

    MEAT_EGG_SIZE_THREE.forEach(item_cuisinedlight => {
        event.add('meat_egg_size_three', item_cuisinedlight);
    });

    //肉类 份量1 营养1
    const MEAT_SIZE_ONE_NUTRITION_ONE = [
        'unusual_delight:raw_phantom_meat',
        'dungeonsdelight:spider_meat',
        'unusual_delight:soggy_flesh',
        'dungeonsdelight:silverfish_abdomen',
        'crabbersdelight:raw_frog_leg',
        'dungeonsdelight:sculk_polyp',
        'unusualfoodsdelight:spider_legs',
        'unusual_delight:rotten_ham',
        'untamedwilds:food_hakarl',
        'unusual_delight:silver_cube',
        'unusual_delight:frozen_flesh',
        'unusual_delight:raw_mite_meat',
        'argentinas_delight:carnepicadaitem',
        'dungeonsdelight:gritty_flesh',
        'unusual_delight:cut_lost_tentacle',
        'dungeonsdelight:brined_flesh',
        'youkaishomecoming:flesh_slice',
        'youkaishomecoming:flesh',
        'netherdepthsupgrade:glowdine',
        'netherdepthsupgrade:blazefish',
        'muffins_thaidelight:dragonfly', 'cavedelight:curious_insect', 'netherdepthsupgrade:bonefish', 'netherdepthsupgrade:eyeball_fish', 'netherdepthsupgrade:wither_bonefish', 'netherdepthsupgrade:magmacubefish', 'muffins_thaidelight:flower_crab', 'collectorsreap:chieftain_leg', 'collectorsreap:chieftain_claw', 'unusualfishmod:raw_blizzard_tuna',
        'alexsmobsdelight:raw_devils_hole_pupfish_slice','alexsmobsdelight:raw_catfish_slice','alexsmobsdelight:raw_mudskipper_slice','alexsmobsdelight:raw_flying_fish_slice'

    ];

    MEAT_SIZE_ONE_NUTRITION_ONE.forEach(item_cuisinedlight => {
        event.add('meat_size_one_nutrition_one', item_cuisinedlight);
    });

    //肉类 份量1 营养10
    const MEAT_SIZE_ONE_NUTRITION_TEN = [
        'netherdepthsupgrade:searing_cod_slice',
        'netherdepthsupgrade:blazefish_slice',
        'netherdepthsupgrade:magmacubefish_slice',
        'netherdepthsupgrade:glowdine_slice',
        'netherdepthsupgrade:soulsucker_slice',
        'unusualfishmod:raw_shockcat',
        'untameddelight:sunfish_slice',
        'culturaldelights:raw_calamari',
        'cavedelight:raw_trilocaris_slice',
        'collectorsreap:clam_meat',
        'collectorsreap:chieftain_crab_meat',
        'crabbersdelight:raw_clam_meat',
        'brain_delight:meatpiece',
        'list:crab_meat',
        'aquaculture:fish_fillet_raw',
        'oceanic_delight:shrimp_slices',
        'manors_bounty:raw_beef_cubes',
        'manors_bounty:raw_chicken_breast',
        'manors_bounty:raw_duck_breast',
        'manors_bounty:spam_slice',
        'luncheonmeatsdelight:minced_pork',
        'aquaculturedelight:small_turtle_meat',
        'collectorsreap:platinum_bass_slice',
        'youkaishomecoming:raw_tuna_slice',
        'unusual_delight:cosmic_cod_slice',
        'rusticdelight:calamari_slice',
        'untameddelight:cooked_trevally_slice',
        'peruviansdelight:filete_atun',
        'peruviansdelight:tentaculo_pota',
        'peruviansdelight:pota_cortado',
        'netherdepthsupgrade:obsidianfish_slice',
        'untameddelight:trevally_slice',
        'unusualfishmod:raw_lobster',
        'alexscaves:trilocaris_tail',
        'untameddelight:sliced_bear',
        'peruviansdelight:raw_heart_slices',
        'manors_bounty:raw_chicken_wing',
        'manors_bounty:raw_chicken_neck',
        'manors_bounty:raw_duck_drumstick',
        'manors_bounty:raw_duck_wing',
        'manors_bounty:raw_duck_neck',
        'manors_bounty:raw_chicken_foot',
        'youkaishomecoming:raw_tuna',
        'youkaishomecoming:otoro',
        'unusualfoodsdelight:minced_bad_flesh',
        'manors_bounty:raw_duck_foot',
        'manors_bounty:raw_chicken_drumstick'
    ];

    MEAT_SIZE_ONE_NUTRITION_TEN.forEach(item_cuisinedlight => {
        event.add('meat_size_one_nutrition_ten', item_cuisinedlight);
    });

    //肉类 份量2 营养10
    const MEAT_SIZE_TWO_NUTRITION_TEN = [
        'argentinas_delight:tirasdeasado',
        'dungeonsdelight:ghast_calamari',
        'avaritia_delight:cosmic_beef', 'argentinas_delight:chorizos_crudositem', 'unusualfoodsdelight:bad_flesh', 'peruviansdelight:beef_heart', 'untameddelight:boar_chop', 'wildernature:venison', 'naturalist:bushmeat', 'untameddelight:camel_meat', 'wildernature:bison_meat','alexsmobsdelight:raw_bison_meat', 'argentinas_delight:tirasdechancho', 'unusualprehistory:raw_stetha', 'unusual_delight:raw_sniffer_meat', 'unusualfishmod:raw_mossthorn', 'argentinas_delight:nalga', 'neapolitan:mint_chops', 'mynethersdelight:hoglin_loin', 'untamedwilds:food_turtle_raw', 'meadow:raw_buffalo_meat', 'untamedwilds:food_bear_raw','alexsmobsdelight:raw_bear_meat', 'wildernature:pelican_meat', 'unusual_delight:raw_zork_chop', 'unusual_delight:fish_blob', 'casualness_delight:raw_donkey_meat',
        'aquaculture:atlantic_herring', 'aquaculture:atlantic_halibut', 'aquaculture:atlantic_cod', 'lavafishing:arowana_fish', 'untameddelight:arowana', 'aquaculture:arapaima', 'lavafishing:agni_fish', 'manors_bounty:abalone', 'lavafishing:quartz_fish', 'collectorsreap:platinum_bass', 'aquaculture:piranha', 'aquaculture:perch', 'aquaculture:pacific_halibut', 'netherdepthsupgrade:obsidianfish', 'lavafishing:obsidian_sword_fish', 'alexscaves:mussel', 'aquaculture:muskellunge', 'aquaculture:minnow', 'aquaculture:brown_shrooma', 'untameddelight:king_crab', 'alexscaves:lanternfish', 'aquaculture:brown_trout', 'aquaculture:carp', 'aquaculture:catfish', 'collectorsreap:clam', 'crabbersdelight:clam', 'crabbersdelight:clawster', 'crabbersdelight:crab', 'lavafishing:flame_squat_lobster', 'untameddelight:football_fish', 'culturaldelights:glow_squid', 'aquaculture:goldfish', 'aquaculture:boulti', 'aquaculture:bluegill', 'aquaculture:blackfish', 'aquaculture:bayad',
        'alexscaves:sweetish_fish_blue', 'untameddelight:sunfish', 'lavafishing:steam_flying_fish', 'culturaldelights:squid', 'untameddelight:spadefish', 'alexscaves:tripodfish', 'aquaculture:tuna', 'collectorsreap:urchin', 'lavafishing:yeti_crab', 'unusualfishmod:raw_circus_fish', 'unusualfishmod:raw_blind_sailfin', 'unusualfishmod:raw_beaked_herring', 'unusualfishmod:raw_bark_angelfish', 'unusualfishmod:raw_amber_goby', 'unusualfishmod:raw_aero_mono', 'create_bic_bit:raw_herring', 'unusualfishmod:raw_demon_herring', 'aquaculture:rainbow_trout', 'youkaishomecoming:raw_lamprey', 'unusualfishmod:raw_picklefish', 'unusualfishmod:raw_sailor_barb', 'unusualprehistory:raw_scau', 'unusualfishmod:raw_sneep_snorp', 'unusualfishmod:raw_snowflake', 'aquaculture:red_grouper', 'aquaculture:red_shrooma', 'netherdepthsupgrade:searing_cod', 'braziliandelight:shrimp', 'netherdepthsupgrade:soulsucker', 'untameddelight:trevally', 'collectorsreap:tiger_prawn', 'aquaculture:synodontis', 'alexscaves:sweetish_fish_yellow', 'alexscaves:sweetish_fish_red', 'alexscaves:sweetish_fish_pink', 'alexscaves:sweetish_fish_green',
        'unusualfishmod:raw_eyelash','unusualfishmod:raw_forkfish','unusualfishmod:raw_hatchetfish','alexscaves:radgill',
        'alexsmobs:flying_fish','alexsmobsdelight:raw_mudskipper','alexsmobsdelight:raw_devils_hole_pupfish'
        ];

    MEAT_SIZE_TWO_NUTRITION_TEN.forEach(item_cuisinedlight => {
        event.add('meat_size_two_nutrition_ten', item_cuisinedlight);
    });

    //肉类 份量3 营养10
    const MEAT_SIZE_THREE_NUTRITION_TEN = [
        'untameddelight:terror_bird_leg',
        'dungeonsdelight:ghast_tentacle',
        'lavafishing:lava_lamprey',
        'lavafishing:scaly_foot_snail',
        'dungeonsdelight:sniffer_shank', 'cavedelight:raw_dino_cut', 'wildernature:cassowary_meat', 'manors_bounty:raw_mallard_duck', 'manors_bounty:raw_turkey', 'wildernature:turkey_meat', 'untitledduckmod:raw_goose', 'manors_bounty:raw_bresse_chicken', 'untamedwilds:food_pachyderm_raw', 'unusualprehistory:raw_coty', 'delightful:raw_goat'
        ];

    MEAT_SIZE_THREE_NUTRITION_TEN.forEach(item_cuisinedlight => {
        event.add('meat_size_three_nutrition_ten', item_cuisinedlight);
    });

    //肉类 份量4 营养10
    const MEAT_SIZE_FOUR_NUTRITION_TEN = [
        'unusualprehistory:raw_mammoth',
        'alexscaves:dinosaur_chop'
        ];

    MEAT_SIZE_FOUR_NUTRITION_TEN.forEach(item_cuisinedlight => {
        event.add('meat_size_four_nutrition_ten', item_cuisinedlight);
    });

    //主食 份量1
    const CARB_SIZE_ONE = [
        'avaritia_delight:diamond_lattice_potato',
        'trailandtales_delight:pitcher_taro',
        'uwabami_breakers:konjak',
        'manors_bounty:baby_corn',
        'braziliandelight:corn',
        'mynethersdelight:ghasta',
        'avaritia_delight:raw_crystal_pasta',
        'dungeonsdelight:slime_noodles',
        'ubesdelight:ube',
        'dungeonsdelight:rotbulb',
        'peruviansdelight:papas_fritas',
        'avaritia_delight:diamond_lattice_fries',
        'create_bic_bit:raw_fries',
        'mynethersdelight:ghasta',
        'mynethersdelight:ghasmati',
        'dungeonsdelight:slime_noodles',
        'seeddelight:raw_acorn_noodle',
        'vietnam_delight:sticky_rice',
        'immortalers_delight:travarice'
    ];

    CARB_SIZE_ONE.forEach(item_cuisinedlight => {
        event.add('carb_size_one', item_cuisinedlight);
    });

    //调料 份量1
    const NONE_SIZE_ONE = [
        'braziliandelight:butter','unusualfoodsdelight:zombie_oil_block','unusual_delight:magic_butter','ltc2:refined_salt','meadow:alpine_salt','endersdelight:crushed_voidpepper','ltc2:pepper_white_powder','ltc2:pepper_black_powder','manors_bounty:salt_shaker','spanishdelight:paprika','vintagedelight:salt_dust','endersdelight:voidpepper','ltc2:sculk_mint','alexscaves:peppermint_powder','neapolitan:vanilla_pods','minecraft:ghast_tear','festive_delight:cinnamon_sticks','endersdelight:ethereal_saffron','ltc2:pepper_endbond','ltc2:pepper_umbrvol','ltc2:pepper_white',
        'festive_delight:cinnamon_powder',
        'vietnam_delight:black_peppercorn',
        'vietnam_delight:green_peppercorn',
        'vietnam_delight:white_peppercorn',
        'manors_bounty:clove',
        'manors_bounty:dried_star_anise',
        'manors_bounty:dried_nutmeg'
    ];

    NONE_SIZE_ONE.forEach(item_cuisinedlight => {
        event.add('none_size_one', item_cuisinedlight);
    });

    //调料 份量2 液体
    const NONE_SIZE_ONE_LIQUID = [
        
    ];

    NONE_SIZE_ONE_LIQUID.forEach(item_cuisinedlight => {
        event.add('none_size_one_liquid', item_cuisinedlight);
    });


});



