ServerEvents.tags('item', event => {
    event.add('forge:oreberry', 'oreberriesreplanted:zinc_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:silver_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:osmium_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:uranium_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:nickel_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:lead_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:aluminum_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:tin_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:copper_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:gold_oreberry_bush')
    event.add('forge:oreberry', 'oreberriesreplanted:iron_oreberry_bush')

    

    //event.add('shopcore:',

    //)
});