ServerEvents.tags('block', event => {
    event.remove('sereneseasons:winter_crops','fruitfulfun:lime_sapling');
    event.remove('sereneseasons:spring_crops','fruitfulfun:lime_sapling');

    event.remove('sereneseasons:autumn_crops','fruitfulfun:grapefruit_sapling');
    event.remove('sereneseasons:spring_crops','fruitfulfun:grapefruit_sapling');
    event.remove('sereneseasons:summer_crops','fruitfulfun:grapefruit_sapling');

    event.remove('sereneseasons:spring_crops','fruitfulfun:pomelo_sapling');
    event.remove('sereneseasons:autumn_crops','fruitfulfun:pomelo_sapling');
    event.remove('sereneseasons:winter_crops','fruitfulfun:pomelo_sapling');

    //event.remove('sereneseasons:spring_crops',);
    //event.remove('sereneseasons:summer_crops',);
    //event.remove('sereneseasons:autumn_crops',);
    //event.remove('sereneseasons:winter_crops',);

    event.remove('sereneseasons:spring_crops','fruitfulfun:citron_sapling');
    event.remove('sereneseasons:summer_crops','fruitfulfun:citron_sapling');
    event.remove('sereneseasons:winter_crops','fruitfulfun:citron_sapling');

    event.remove('sereneseasons:winter_crops','fruitfulfun:redlove_sapling');
    event.remove('sereneseasons:spring_crops','fruitfulfun:redlove_sapling');

    event.remove('sereneseasons:summer_crops','foragersinsight:bountiful_spruce_sapling');


});