/*
ServerEvents.tags('item', event => {
    event.add('forge:salt', 'ratatouille:salt');//乡村乐事盐
    event.add('forge:salt', 'hearthandharvest:salt'); //暖灶丰年盐
});
*/


ServerEvents.tags('item', event => {
    event.add('forge:plum', 'bountifulfares:plum');
    event.add('forge:plum', 'forestry:fruit_plum'); 
    event.add('forge:plum', 'manors_bounty:plum');

    event.add('forge:lime', 'muffins_thaidelight:lime'); 
    event.add('forge:lime', 'collectorsreap:lime'); 
    event.add('forge:lime', 'manors_bounty:lime');

    event.add('forge:redbean', 'youkaishomecoming:redbean'); 
    event.add('forge:redbean', 'neapolitan:adzuki_beans'); 

    event.add('forge:mango', 'manors_bounty:mango'); 
    event.add('forge:mango', 'fruitsdelight:mango'); 

    event.add('neoforge:coconut', 'ecologics:coconut'); 
    event.add('neoforge:coconut', 'braziliandelight:coconut'); 
    event.add('neoforge:coconut', 'manors_bounty:coconut');

    event.add('forge:strawberry', 'manors_bounty:strawberry'); 
    event.add('forge:strawberry', 'neapolitan:strawberries'); 

    event.add('forge:white_strawberry', 'neapolitan:white_strawberries'); 
    event.add('forge:white_strawberry', 'manors_bounty:pineberry'); 

    event.add('forge:eggplant', 'culturaldelights:eggplant'); 
    event.add('forge:eggplant', 'minecolonies:eggplant'); 
    event.add('forge:eggplant', 'dumplings_delight:eggplant'); 

    event.add('forge:peach', 'manors_bounty:peach'); 
    event.add('forge:peach', 'fruitsdelight:peach'); 

    event.add('forge:coconut_slice', 'ecologics:coconut_slice'); 
    event.add('forge:coconut_slice', 'braziliandelight:coconut_slice'); 
    event.add('forge:coconut_slice', 'manors_bounty:half_of_coconut');

    event.add('forge:hamimelon', 'manors_bounty:hamimelon'); 
    event.add('forge:hamimelon', 'fruitsdelight:hamimelon'); 
    
    event.add('forge:hm_slice', 'fruitsdelight:hamimelon_slice'); 
    event.add('forge:hm_slice', 'manors_bounty:hamimelon_slice'); 

    event.add('forge:pineapple_slice', 'manors_bounty:pineapple_slice'); 
    event.add('forge:pineapple_slice', 'fruitsdelight:pineapple_slice'); 
    event.add('forge:pineapple_slice', 'pineapple_delight:pineapple_side');
    event.add('forge:pineapple_slice', 'pizzacraft:pineapple_slice');

    event.add('forge:cranberry', 'fruitsdelight:cranberry'); 
    event.add('forge:cranberry', 'manors_bounty:cranberry'); 
    event.add('forge:cranberry', 'biologica:cranberry'); 

    //event.add('forge:orange', 'bountifulfares:orange'); 
    event.add('forge:orange', 'fruitfulfun:orange'); 
    event.add('forge:orange', 'manors_bounty:orange'); 

    event.add('forge:orangetwo', 'fruitsdelight:orange'); 
    event.add('forge:orangetwo', 'fruitfulfun:tangerine'); 

    event.add('forge:orange_sapling', 'fruitsdelight:orange_sapling');
    event.add('forge:orange_sapling', 'fruitfulfun:tangerine_sapling');

    event.add('forge:cut_avocado', 'culturaldelights:cut_avocado'); 
    event.add('forge:cut_avocado', 'manors_bounty:half_of_avocado'); 
    event.add('forge:cut_avocado', 'peruviansdelight:palta_cortada');

    event.add('forge:onion', 'farmersdelight:onion'); 
    event.add('forge:onion', 'minecolonies:onion'); 

    event.add('forge:yellow_papper', 'rusticdelight:bell_pepper_yellow'); 
    event.add('forge:yellow_papper', 'veggiesdelight:bellpepper'); 
    event.add('forge:yellow_papper', 'ltc2:pepper_yellow'); 

    event.add('forge:green_papper', 'rusticdelight:bell_pepper_green'); 
    event.add('forge:green_papper', 'spanishdelight:green_pepper'); 
    event.add('forge:green_papper', 'manors_bounty:green_bell_pepper'); 

    event.add('forge:avocade', 'culturaldelights:avocado'); 
    event.add('forge:avocade', 'manors_bounty:avocado'); 
    event.add('forge:avocade', 'peruviansdelight:palta'); 

    event.add('forge:pear', 'fruitsdelight:pear'); 
    event.add('forge:pear', 'manors_bounty:pear'); 

    event.add('forge:cabbage', 'minecolonies:cabbage'); 
    event.add('forge:cabbage', 'farmersdelight:cabbage'); 

    event.add('forge:cooked_corn', 'corn_delight:grilled_corn'); 
    event.add('forge:cooked_corn', 'braziliandelight:cooked_corn'); 

    event.add('forge:pod', 'braziliandelight:bean_pod'); 
    event.add('forge:pod', 'youkaishomecoming:pods'); 

    event.add('forge:hazelnut', 'wildernature:hazelnut'); 
    event.add('forge:hazelnut', 'manors_bounty:filbert'); 

    event.add('forge:truffle', 'manors_bounty:truffle'); 
    event.add('forge:truffle', 'wildernature:truffle'); 
    event.add('forge:truffle', 'fungidelight:truffle');
    event.add('forge:truffle', 'mooncake_delight:truffle');


    event.add('forge:rice', 'farmersdelight:rice'); 
    event.add('forge:rice', 'minecolonies:rice'); 
    event.add('forge:rice', 'manors_bounty:raw_rice');

    event.add('forge:pitaya', 'manors_bounty:dragon_fruit'); 
    event.add('forge:pitaya', 'nethers_exoticism:pitaya');
    //event.add('forge:pitaya', 'collectorsreap:pink_dragon_fruit'); 

    event.add('forge:cooked_venison', 'wildernature:cooked_venison'); 
    event.add('forge:cooked_venison', 'naturalist:cooked_venison'); 

    event.add('forge:venison', 'wildernature:venison'); 
    event.add('forge:venison', 'naturalist:venison'); 
    event.add('forge:venison', 'youkaishomecoming:raw_venison');

    event.add('forge:turkey', 'wildernature:turkey_meat'); 
    event.add('forge:turkey', 'bountifulharvest:raw_turkey'); 

    event.add('forge:cooked_turkey', 'wildernature:cooked_turkey_meat'); 
    event.add('forge:cooked_tirkey', 'bountifulharvest:cooked_turkey'); 

    event.add('forge:peanut', 'hearthandharvest:peanut'); 
    event.add('forge:peanut', 'vintagedelight:peanut'); 
    event.add('forge:peanut', 'braziliandelight:peanut');
    event.add('forge:peanut', 'manors_bounty:peanut');

    event.add('forge:cassava_flour', 'braziliandelight:cassava_flour'); 
    event.add('forge:cassava_flour', 'createcafe:tapioca_flour'); 

    event.add('forge:red_grape', 'hearthandharvest:red_grapes'); 
    event.add('forge:red_grape', 'vinery:red_grape'); 
    event.add('forge:red_grape', 'manors_bounty:grape');
    event.add('forge:red_grape', 'youkaishomecoming:red_grape');
    event.add('forge:red_grape', 'brewincompatdelight:red_grapes');

    event.add('forge:pickle', 'culturaldelights:pickle'); 
    event.add('forge:pickle', 'vintagedelight:pickle'); 
    event.add('forge:pickle', 'manors_bounty:pickle');
    event.add('forge:pickle', 'youkaishomecoming:pickle');
    event.add('forge:pickle', 'blockdonalds:pickle');

    event.add('forge:cooked_squid', 'culturaldelights:cooked_squid'); 
    event.add('forge:cooked_squid', 'miners_delight:baked_squid'); 

    event.add('forge:glow_squid', 'culturaldelights:glow_squid'); 
    event.add('forge:glow_squid', 'miners_delight:glow_squid'); 

    event.add('forge:squid', 'culturaldelights:squid'); 
    event.add('forge:squid', 'miners_delight:squid'); 

    event.add('forge:squid_tentacles', 'kubejs:glow_squid_tentacles'); //要更改
    event.add('forge:squid_tentacles', 'oceanic_delight:glow_squid_tentacles'); 
    event.add('forge:squid_tentacles', 'crabbersdelight:raw_glow_squid_tentacles'); 
//完成了上面的
    event.add('forge:duck', 'naturalist:duck'); 
    event.add('forge:duck', 'untitledduckmod:raw_duck'); 
    event.add('forge:duck', 'manors_bounty:raw_mallard_duck');

    event.add('forge:cooked_duck', 'untitledduckmod:cooked_duck'); 
    event.add('forge:cooked_duck', 'naturalist:cooked_duck'); 
    event.add('forge:cooked_duck', 'manors_bounty:cooked_mallard_duck');

    event.add('forge:duck_egg', 'untitledduckmod:duck_egg'); 
    event.add('forge:duck_egg', 'naturalist:duck_egg'); 
    event.add('forge:duck_egg', 'manors_bounty:mallard_duck_egg');
    
    event.add('quilt:cook_wing','manors_bounty:cooked_chicken_wing')
    event.add('quilt:cook_wing','pizzacraft:cooked_wing')

    event.add('quilt:wing','manors_bounty:raw_chicken_wing')
    event.add('quilt:wing','pizzacraft:wing')


    event.add('forge:soybean', 'minecolonies:soybean'); 
    event.add('forge:soybean', 'vegandelight:soybean'); 
    event.add('forge:soybean', 'peruviansdelight:granos_soya');

    event.add('forge:ginko', 'unusualprehistory:ginkgo_fruit'); 
    event.add('forge:ginko', 'prehistoricfauna:ginkgo_berry'); 

    event.add('forge:cooked_ginko', 'unusualprehistory:cooked_ginkgo_seeds'); 
    event.add('forge:cooked_ginko', 'prehistoricfauna:cooked_ginkgo_nuts'); 

    event.add('forge:green_tea', 'farmersrespite:green_tea_leaves'); 
    event.add('forge:green_tea', 'youkaishomecoming:green_tea_leaves');
    event.add('forge:green_tea', 'manors_bounty:green_tea_leaves');
    event.add('forge:green_tea', 'bountifulfares:tea_leaves'); 
    //event.add('forge:green_tea', 'youkaishomecoming:tea_leaves');

    event.add('forge:red_tea', 'farmersrespite:black_tea_leaves'); 
    event.add('forge:red_tea', 'youkaishomecoming:black_tea_leaves'); 
    event.add('forge:red_tea', 'manors_bounty:black_tea_leaves');
    //event.add('forge:red_tea', 'bountifulfares:dried_tea_leaves'); 

    event.add('forge:green_grape', 'hearthandharvest:green_grapes'); 
    event.add('forge:green_grape', 'vinery:white_grape'); 
    event.add('forge:green_grape', 'youkaishomecoming:white_grape');
    event.add('forge:green_grape', 'brewincompatdelight:white_grapes');

    event.add('forge:cassava', 'braziliandelight:cassava_root'); 
    event.add('forge:cassava', 'create_deepfried:yuca'); 
    event.add('forge:cassava', 'createcafe:cassava_root'); 
    event.add('forge:cassava', 'peruviansdelight:yuca'); 

    event.add('forge:cooked_prawn', 'manors_bounty:cooked_prawn'); 
    event.add('forge:cooked_prawn', 'crabbersdelight:cooked_shrimp'); 
    event.add('forge:cooked_prawn', 'braziliandelight:cooked_shrimp'); 

    event.add('forge:red_papper', 'spanishdelight:red_pepper'); 
    event.add('forge:red_papper', 'minecolonies:bell_pepper'); 
    event.add('forge:red_papper', 'rusticdelight:bell_pepper_red'); 
    event.add('forge:red_papper', 'pizzacraft:pepper');
    event.add('forge:red_papper', 'manors_bounty:pimento');
    event.add('forge:red_papper','ltc2:pepper_sweet')

    event.add('forge:walnut', 'forestry:fruit_walnut'); 
    event.add('forge:walnut', 'ecologics:walnut'); 
    event.add('forge:walnut', 'bountifulfares:walnut'); 

    event.add('forge:kiwi', 'manors_bounty:kiwifruit'); 
    event.add('forge:kiwi', 'fruitsdelight:kiwi'); 
    event.add('forge:kiwi', 'jagmkiwis:kiwi_fruit'); 

    event.add('forge:blueberry', 'fruitsdelight:blueberry'); 
    event.add('forge:blueberry', 'hearthandharvest:blueberries'); 
    event.add('forge:blueberry', 'manors_bounty:blueberry'); 

    event.add('forge:mint', 'neapolitan:mint_leaves'); 
    event.add('forge:mint', 'minecolonies:mint'); 

    event.add('forge:sweet_potato', 'argentinas_delight:batata'); 
    event.add('forge:sweet_potato', 'veggiesdelight:sweet_potato'); 
    event.add('forge:sweet_potato', 'bountifulharvest:sweet_potato'); 
    event.add('forge:sweet_potato', 'peruviansdelight:camote');

    event.add('forge:pineapple', 'fruitsdelight:pineapple'); 
    event.add('forge:pineapple', 'manors_bounty:pineapple'); 
    event.add('forge:pineapple', 'pineapple_delight:pineapple'); 
    event.add('forge:pineapple', 'pizzacraft:pineapple'); 

    event.add('forge:corn_seeds', 'braziliandelight:kernels'); 
    event.add('forge:corn_seeds', 'manors_bounty:corn_seed'); 
    event.add('forge:corn_seeds', 'corn_delight:corn_seeds'); 
    event.add('forge:corn_seeds', 'culturaldelights:corn_kernels');
    event.add('forge:corn_seeds', 'bountifulfares:maize_seeds');

    event.add('forge:flour', 'create:wheat_flour'); 
    event.add('forge:flour', 'foragersinsight:wheat_flour'); 
    event.add('forge:flour', 'bountifulfares:flour'); 
    event.add('forge:flour', 'argentinas_delight:harinadetrigo'); 
    event.add('forge:flour', 'pizzacraft:flour'); 
    event.add('forge:flour', 'manors_bounty:flour'); 

    event.add('forge:acorn', 'seeddelight:acorn'); 
    event.add('forge:acorn', 'delightful:acorn'); 
    event.add('forge:acorn', 'manors_bounty:acorn'); 

    event.add('forge:rose_hip', 'farmersrespite:rose_hips'); 
    event.add('forge:rose_hip', 'seeddelight:rosehip'); 
    event.add('forge:rose_hip', 'foragersinsight:rose_hip'); 

    event.add('forge:apple_slices', 'some_assembly_required:apple_slices'); 
    event.add('forge:apple_slices', 'foragersinsight:apple_slice'); 
    event.add('forge:apple_slices', 'create_deepfried:apple_slices'); 
    event.add('forge:apple_slices', 'manors_bounty:apple_slice'); 
    event.add('forge:apple_slices', 'blockdonalds:apple_slices');

    event.add('forge:tofu', 'vegandelight:tofu'); 
    event.add('forge:tofu', 'youkaishomecoming:tofu'); 
    event.add('forge:tofu', 'minecolonies:tofu'); 

    event.add('forge:cooked_calamari', 'culturaldelights:cooked_calamari'); 
    event.add('forge:cooked_calamari', 'oceanic_delight:grilled_squid_tentacles'); 
    event.add('forge:cooked_calamari', 'miners_delight:baked_tentacles'); 
    event.add('forge:cooked_calamari', 'crabbersdelight:cooked_squid_tentacles'); 
    event.add('forge:cooked_calamari', 'rusticdelight:cooked_calamari'); 

    event.add('forge:cherry', 'vinery:cherry'); 
    event.add('forge:cherry', 'hearthandharvest:cherry'); 
    event.add('forge:cherry', 'seeddelight:cherry'); 
    event.add('forge:cherry', 'forestry:fruit_cherry'); 
    event.add('forge:cherry', 'fruitfulfun:cherry'); 

    event.add('forge:salt2', 'braziliandelight:salt'); 
    event.add('forge:salt2', 'vintagedelight:salt_dust'); 
    event.add('forge:salt2', 'vegandelight:salt'); 
    event.add('forge:salt2', 'unusualfoodsdelight:salt'); 
    event.add('forge:salt2', 'ratatouille:salt'); 
    event.add('forge:salt2', 'hearthandharvest:salt'); 
    event.add('forge:salt2', 'ltc2:salt'); 
    event.add('forge:salt2', 'ltc2:refined_salt');

    event.add('forge:coffee_beans', 'braziliandelight:coffee_beans'); 
    event.add('forge:coffee_beans', 'youkaishomecoming:coffee_beans'); 
    event.add('forge:coffee_beans', 'rusticdelight:coffee_beans'); 
    event.add('forge:coffee_beans', 'coffee_delight:coffee_beans'); 
    event.add('forge:coffee_beans', 'createcafe:coffee_beans'); 
    event.add('forge:coffee_beans', 'farmersrespite:coffee_bush'); 
    event.add('forge:coffee_beans', 'manors_bounty:coffee_beans');

    event.add('forge:corn', 'braziliandelight:corn'); 
    event.add('forge:corn', 'argentinas_delight:choclo'); 
    event.add('forge:corn', 'corn_delight:corn'); 
    event.add('forge:corn', 'culturaldelights:corn_cob'); 
    event.add('forge:corn', 'manors_bounty:corn');
    event.add('forge:corn', 'bountifulfares:maize'); 
    event.add('forge:corn', 'minecolonies:corn'); 
    event.add('forge:corn', 'pizzacraft:corn');

    event.add('forge:shrimp', 'braziliandelight:shrimp'); 
    event.add('forge:shrimp', 'manors_bounty:raw_prawn'); 
    event.add('forge:shrimp', 'crabbersdelight:shrimp'); 
    event.add('forge:shrimp', 'oceanic_delight:shrimp'); 

    event.add('forge:lemon', 'fruitsdelight:lemon'); 
    event.add('forge:lemon', 'fruitfulfun:lemon'); 
    event.add('forge:lemon', 'bountifulfares:lemon'); 
    event.add('forge:lemon', 'manors_bounty:lemon');
    event.add('forge:lemon', 'braziliandelight:lemon'); 
    event.add('forge:lemon', 'forestry:fruit_lemon'); 
    event.add('forge:lemon', 'yeastnfeast:lemon'); 
    event.add('forge:lemon', 'peruviansdelight:limon'); 

    event.add('forge:garlic', 'braziliandelight:garlic_bulb'); 
    event.add('forge:garlic', 'minecolonies:garlic'); 
    event.add('forge:garlic', 'ubesdelight:garlic'); 
    event.add('forge:garlic', 'dumplings_delight:garlic'); 
    event.add('forge:garlic', 'spanishdelight:garlic'); 
    event.add('forge:garlic', 'manors_bounty:garlic'); 
    event.add('forge:garlic', 'veggiesdelight:garlic');
    event.add('forge:garlic', 'yeastnfeast:garlic');

    event.add('forge:calamari2', 'culturaldelights:raw_calamari'); 
    event.add('forge:calamari2', 'miners_delight:tentacles');
    event.add('forge:calamari2', 'dumplings_delight:calamari'); 
    event.add('forge:calamari2', 'rusticdelight:calamari'); 
    event.add('forge:calamari2', 'oceanic_delight:squid_tentacles'); 
    event.add('forge:calamari2', 'oceansdelight:tentacles'); 
    event.add('forge:calamari2', 'crabbersdelight:raw_squid_tentacles'); 

    event.add('forge:cucumber', 'vintagedelight:cucumber');
    event.add('forge:cucumber', 'culturaldelights:cucumber');
    event.add('forge:cucumber', 'pizzacraft:cucumber');  
    event.add('forge:cucumber', 'youkaishomecoming:cucumber');
    event.add('forge:cucumber', 'manors_bounty:cucumber');
    event.add('forge:cucumber', 'blockdonalds:cucumber')

    event.add('forge:butter', 'gourmet:butter'); 
    event.add('forge:butter', 'braziliandelight:butter'); 
    event.add('forge:butter', 'youkaishomecoming:butter'); 
    event.add('forge:butter', 'manors_bounty:butter')

    event.add('forge:lime', 'collectorsreap:lime'); 
    event.add('forge:lime', 'muffins_thaidelight:lime'); 

    event.add('forge:food_oil', 'rusticdelight:cooking_oil');
    event.add('forge:food_oil', 'gourmet:seed_oil_bottle'); 
    event.add('forge:food_oil', 'delightful:animal_oil_bottle'); 

    event.add('neoforge:hawberry', 'fruitsdelight:hawberry'); 
    event.add('neoforge:hawberry', 'yeastnfeast:hawthorn_berries'); 
    event.add('neoforge:hawberry', 'manors_bounty:hawthorn'); 

    event.add('forge:ginger', 'ubesdelight:ginger'); 
    event.add('forge:ginger', 'yeastnfeast:ginger');
    event.add('forge:ginger', 'peruviansdelight:kion');

    event.add('forge:elderberries', 'bountifulfares:elderberries'); 
    event.add('forge:elderberries', 'yeastnfeast:elderberries'); 

    event.add('forge:mint', 'neapolitan:mint_leaves');
    event.add('forge:mint', 'yeastnfeast:mint'); 

    event.add('forge:vanilla_pods', 'neapolitan:vanilla_pods'); 
    event.add('forge:vanilla_pods', 'gelato_galore:vanilla_pods'); 

    event.add('neoforge:rose_hips', 'yeastnfeast:rose_hips'); 
    event.add('neoforge:rose_hips', 'foragersinsight:rose_hip'); 
    event.add('neoforge:rose_hips', 'seeddelight:rosehip'); 
    event.add('neoforge:rose_hips', 'farmersrespite:rose_hips'); 

    event.add('fabric:date', 'ramadandelight:date'); 
    event.add('fabric:date', 'forestry:fruit_dates');

    event.add('fabric:papaya', 'muffins_thaidelight:papaya'); 
    event.add('fabric:papaya', 'forestry:fruit_papaya');  

    event.add('fabric:dried_vanilla_pods', 'gelato_galore:dried_vanilla_pods'); 
    event.add('fabric:dried_vanilla_pods', 'neapolitan:dried_vanilla_pods'); 

    event.add('fabric:ice_cream_cone', 'gelato_galore:ice_cream_cone');
    event.add('fabric:ice_cream_cone', 'manors_bounty:ice_cream_cone');
    event.add('fabric:ice_cream_cone', 'cosmopolitan:wafer_cone');
    event.add('fabric:ice_cream_cone', 'brain_delight:cone');
    
    event.add('fabric:cotton', 'rusticdelight:cotton_boll');
    event.add('fabric:cotton', 'hearthandharvest:cotton');
    event.add('fabric:cotton', 'miners_delight:gossypium');

    event.add('fabric:portobello', 'collectorsreap:portobello');
    event.add('fabric:portobello', 'manors_bounty:botton_mushroom');

    event.add('fabric:cooked_bison_meat', 'wildernature:cooked_bison_meat');
    event.add('fabric:cooked_bison_meat', 'untameddelight:cooked_bison_meat');

    event.add('fabric:bison_meat', 'wildernature:bison_meat');
    event.add('fabric:bison_meat', 'untameddelight:bison_meat');
    event.add('fabric:bison_meat', 'alexsmobsdelight:raw_bison_meat');

    event.add('fabric:sliced_pickle', 'kubejs:sliced_pickle');
    event.add('fabric:sliced_pickle', 'culturaldelights:cut_pickle');
    event.add('fabric:sliced_pickle', 'manors_bounty:pickle_slice');
    event.add('fabric:sliced_pickle', 'blockdonalds:pickle_slices');

    event.add('fabric:onion_slice', 'some_assembly_required:sliced_onion');
    event.add('fabric:onion_slice', 'pizzadelight:onion_slice');
    event.add('fabric:onion_slice', 'spanishdelight:sliced_onion');
    event.add('fabric:onion_slice', 'pizzacraft:onion_slice');

    event.add('fabric:tankard', 'brewinandchewin:tankard');
    event.add('fabric:tankard', 'alcocraftplus:mug');
    event.add('fabric:tankard', 'yeastnfeast:tankard');

    event.add('fabric:fiddlehead', 'alexscaves:fiddlehead');
    event.add('fabric:fiddlehead', 'cosmopolitan:fiddlehead');

    event.add('forge:jar', 'vintagedelight:mason_jar');
    event.add('forge:jar', 'hearthandharvest:jar');
    event.add('forge:jar', 'yeastnfeast:jar');
    
    event.add('fabric:lemon_slice', 'fruitsdelight:lemon_slice');
    event.add('fabric:lemon_slice', 'manors_bounty:lemon_slice');

    event.add('neoforge:apple_jam', 'fruitsdelight:apple_jelly');
    event.add('neoforge:apple_jam', 'yeastnfeast:apple_jam');
    event.add('neoforge:apple_jam', 'brewinandchewin:apple_jelly');
    event.add('neoforge:apple_jam', 'vintagedelight:apple_sauce_mason_jar');
    event.add('neoforge:apple_jam', 'hearthandharvest:apple_jam');

    event.add('neoforge:chorus_jelly', 'fruitsdelight:chorus_jelly');
    event.add('neoforge:chorus_jelly', 'yeastnfeast:chorus_fruit_jam');

    event.add('neoforge:sweetberry_jelly', 'fruitsdelight:sweetberry_jelly');
    event.add('neoforge:sweetberry_jelly', 'hearthandharvest:sweet_berry_jam');
    event.add('neoforge:sweetberry_jelly', 'yeastnfeast:sweet_berries_jam');
    event.add('neoforge:sweetberry_jelly', 'brewinandchewin:sweet_berry_jam');
    event.add('neoforge:sweetberry_jelly', 'vintagedelight:sweet_berry_mason_jar');

    event.add('neoforge:glowberry_jelly', 'fruitsdelight:glowberry_jelly');
    event.add('neoforge:glowberry_jelly', 'hearthandharvest:glow_berry_jam');
    event.add('neoforge:glowberry_jelly', 'yeastnfeast:glow_berries_jam');
    event.add('neoforge:glowberry_jelly', 'vintagedelight:glow_berry_mason_jar');
    event.add('neoforge:glowberry_jelly', 'brewinandchewin:glow_berry_marmalade');

    event.add('neoforge:lemon_jelly', 'fruitsdelight:lemon_jelly');
    event.add('neoforge:lemon_jelly', 'yeastnfeast:lemon_jam');

    event.add('neoforge:hawberry_jelly', 'fruitsdelight:hawberry_jelly');
    event.add('neoforge:hawberry_jelly', 'yeastnfeast:hawthorn_berries_jam');

    event.add('neoforge:melon_jelly', 'fruitsdelight:melon_jelly');
    event.add('neoforge:melon_jelly', 'yeastnfeast:melon_jam');
    event.add('neoforge:melon_jelly', 'hearthandharvest:melon_jam');

    event.add('neoforge:blueberry_jelly', 'fruitsdelight:blueberry_jelly');
    event.add('neoforge:blueberry_jelly', 'hearthandharvest:blueberry_jam');

    event.add('neoforge:rose_hips_jam', 'yeastnfeast:rose_hips_jam');
    event.add('neoforge:rose_hips_jam', 'seeddelight:rosehip_jam_jar');

    event.add('neoforge:milk_bottle', 'neapolitan:milk_bottle');
    event.add('neoforge:milk_bottle', 'yeastnfeast:milk_bottle');
    event.add('neoforge:milk_bottle', 'farmersdelight:milk_bottle');

    event.add('neoforge:tomato_slice', 'some_assembly_required:tomato_slices');
    event.add('neoforge:tomato_slice', 'pizzacraft:tomato_slice');

    event.add('neoforge:onion', 'pizzacraft:onion');
    event.add('neoforge:onion', 'farmersdelight:onion');

    event.add('neoforge:hum', 'kubejs:sliced_ham');
    event.add('neoforge:hum', 'pizzacraft:ham');

    event.add('neoforge:tomato', 'pizzacraft:tomato');
    event.add('neoforge:tomato', 'farmersdelight:tomato');

    event.add('neoforge:olive', 'pizzacraft:olive');
    event.add('neoforge:olive', 'manors_bounty:olive_fruit');

    event.add('neoforge:corn_flour', 'pizzacraft:corn_flour');
    event.add('neoforge:corn_flour', 'braziliandelight:corn_flour');

    event.add('neoforge:pickled_beetroot', 'hearthandharvest:pickled_beetroots');
    event.add('neoforge:pickled_beetroot', 'vintagedelight:pickled_beetroot');

    event.add('neoforge:pickled_onion', 'vintagedelight:pickled_onion');
    event.add('neoforge:pickled_onion', 'hearthandharvest:pickled_onions');

    event.add('neoforge:pomegranate', 'manors_bounty:pomegranate');
    event.add('neoforge:pomegranate', 'collectorsreap:pomegranate');

    event.add('neoforge:yellow_tea', 'farmersrespite:yellow_tea_leaves');
    event.add('neoforge:yellow_tea', 'youkaishomecoming:yellow_tea_leaves');

    event.add('neoforge:fig', 'fruitsdelight:fig');
    event.add('neoforge:fig', 'manors_bounty:fig');

    event.add('neoforge:banana_bunch', 'manors_bounty:banana_bunch');
    event.add('neoforge:banana_bunch', 'neapolitan:banana_bunch');

    event.add('neoforge:banana', 'manors_bounty:banana');
    event.add('neoforge:banana', 'neapolitan:banana');

    event.add('neoforge:lime_slice', 'collectorsreap:lime_slice');
    event.add('neoforge:lime_slice', 'muffins_thaidelight:lime_slice');
    event.add('neoforge:lime_slice', 'manors_bounty:lime_slice');
    event.add('neoforge:lime_slice', 'peruviansdelight:gajo_limon');

    event.add('neoforge:grapefruit', 'manors_bounty:grapefruit');
    event.add('neoforge:grapefruit', 'fruitfulfun:grapefruit');

    event.add('neoforge:pomelo', 'manors_bounty:yuzumelo');
    event.add('neoforge:pomelo', 'fruitfulfun:pomelo');

    event.add('neoforge:pomegranate_wedge', 'manors_bounty:pomegranate_wedge');
    event.add('neoforge:pomegranate_wedge', 'collectorsreap:pomegranate_slice');

    event.add('neoforge:broccoli', 'veggiesdelight:broccoli');
    event.add('neoforge:broccoli', 'pizzacraft:broccoli');

    event.add('neoforge:wheat_dough', 'farmersdelight:wheat_dough');
    event.add('neoforge:wheat_dough', 'create:dough');
    event.add('neoforge:wheat_dough', 'manors_bounty:dough');

    event.add('neoforge:tea_leaves', 'bountifulfares:tea_leaves');
    event.add('neoforge:tea_leaves', 'youkaishomecoming:tea_leaves');
    event.add('neoforge:tea_leaves', 'manors_bounty:tea_leaves');

    event.add('neoforge:coffee_beans_cooked', 'coffee_delight:coffee_beans_cooked');
    event.add('neoforge:coffee_beans_cooked', 'createcafe:roasted_coffee_beans');
    event.add('neoforge:coffee_beans_cooked', 'rusticdelight:roasted_coffee_beans');

    event.add('neoforge:raspberry', 'hearthandharvest:raspberry');
    event.add('neoforge:raspberry', 'manors_bounty:raspberry');

    event.add('neoforge:camellia', 'youkaishomecoming:camellia');
    event.add('neoforge:camellia', 'manors_bounty:camelia');

    event.add('neoforge:coffee_powder', 'youkaishomecoming:coffee_powder');
    event.add('neoforge:coffee_powder', 'createcafe:coffee_grounds');
    event.add('neoforge:coffee_powder', 'coffee_delight:coffee_flour');
    event.add('neoforge:coffee_powder', 'manors_bounty:coffee_powder');

    event.add('neoforge:rice_panicle', 'farmersdelight:rice_panicle');
    event.add('neoforge:rice_panicle', 'manors_bounty:rice_panicle');

    event.add('neoforge:sillao', 'youkaishomecoming:soy_sauce_bottle');
    event.add('neoforge:sillao', 'peruviansdelight:sillao');
    
    event.add('neoforge:vinegar', 'vintagedelight:vinegar_bottle');
    event.add('neoforge:vinegar', 'dumplings_delight:vinegar');
    
    event.add('neoforge:corn_flour', 'braziliandelight:corn_flour');
    event.add('neoforge:corn_flour', 'argentinas_delight:harinamaiz');
    event.add('neoforge:corn_flour', 'manors_bounty:corn_flour');

    event.add('neoforge:cucumber_slice', 'culturaldelights:cut_cucumber');
    event.add('neoforge:cucumber_slice', 'manors_bounty:cucumber_slice');
    event.add('neoforge:cucumber_slice','blockdonalds:cucumber_slices')

    event.add('neoforge:corn_dough', 'manors_bounty:corn_dough');
    event.add('neoforge:corn_dough', 'culturaldelights:corn_dough');

    event.add('neoforge:applesauce', 'vegandelight:applesauce');
    event.add('neoforge:applesauce', 'fastfooddelight:apple_sauce');

    event.add('neoforge:matcha', 'manors_bounty:matcha_powder');
    event.add('neoforge:matcha', 'youkaishomecoming:matcha');

    //杜松子
    event.add('neoforge:juniper_berries', 'brewincompatdelight:juniper_berries');
    event.add('neoforge:juniper_berries', 'manors_bounty:juniper_berry');

    event.add('neoforge:apple_slices', 'some_assembly_required:apple_slices');
    event.add('neoforge:apple_slices', 'manors_bounty:apple_slice');

    event.add('neoforge:golden_apple_slices', 'some_assembly_required:golden_apple_slices');
    event.add('neoforge:golden_apple_slices', 'manors_bounty:golden_apple_slice');

    event.add('neoforge:enchanted_golden_apple_slices', 'some_assembly_required:enchanted_golden_apple_slices');
    event.add('neoforge:enchanted_golden_apple_slices', 'manors_bounty:enchanted_golden_apple_slice');

    event.add('neoforge:green_coconut', 'braziliandelight:green_coconut');
    event.add('neoforge:green_coconut', 'manors_bounty:young_coconut');

    event.add('neoforge:passion_fruit', 'bountifulfares:passion_fruit');
    event.add('neoforge:passion_fruit', 'manors_bounty:passion_fruit');

    event.add('neoforge:cook_rice', 'manors_bounty:cooked_rice');
    event.add('neoforge:cook_rice', 'farmersdelight:cooked_rice');

    event.add('neoforge:paprika', 'manors_bounty:jalapeno_powder');
    event.add('neoforge:paprika', 'spanishdelight:paprika');
    event.add('neoforge:paprika', 'ltc2:pepper_red_powder');

    event.add('neoforge:potato_slices', 'rusticdelight:potato_slices');
    event.add('neoforge:potato_slices', 'cosmopolitan:cut_potatoes');
    event.add('neoforge:potato_slices', 'spanishdelight:sliced_potato');
    event.add('neoforge:potato_slices', 'manors_bounty:potato_slice');
    event.add('neoforge:potato_slices', 'casualness_delight:potato_slice');
    event.add('neoforge:potato_slices', 'peruviansdelight:papas_cortadas');
    event.add('neoforge:potato_slices', 'moredelight:diced_potatoes');

    event.add('neoforge:carrot_slices', 'some_assembly_required:chopped_carrot');
    event.add('neoforge:carrot_slices', 'manors_bounty:carrot_slice');

    event.add('neoforge:cook_egg', 'farmersdelight:fried_egg');
    event.add('neoforge:cook_egg', 'naturalist:cooked_egg');
    event.add('neoforge:cook_egg', 'manors_bounty:sunny_side_up_egg');

    event.add('neoforge:beef', 'farmersdelight:minced_beef');
    event.add('neoforge:beef', 'manors_bounty:raw_beef_patty');

    event.add('neoforge:cooked_beef', 'farmersdelight:beef_patty');
    event.add('neoforge:cooked_beef', 'manors_bounty:cooked_beef_patty');

    event.add('neoforge:cut_pitaya', 'nethers_exoticism:cut_pitaya');
    event.add('neoforge:cut_pitaya', 'manors_bounty:dragon_fruit_slice');
//未
    event.add('neoforge:salmon_slice', 'manors_bounty:raw_salmon_slice');
    event.add('neoforge:salmon_slice', 'farmersdelight:salmon_slice');

    event.add('neoforge:cod_slice', 'farmersdelight:cod_slice');
    event.add('neoforge:cod_slice', 'manors_bounty:raw_cod_slice');

    event.add('neoforge:tropical_fish_slice', 'crabbersdelight:tropical_fish_slice');
    event.add('neoforge:tropical_fish_slice', 'manors_bounty:tropical_fish_slice');

    event.add('neoforge:cooked_bacon', 'farmersdelight:cooked_bacon');
    event.add('neoforge:cooked_bacon', 'manors_bounty:bacon');
    event.add('neoforge:cooked_bacon', 'argentinas_delight:pancetaitem');

    event.add('neoforge:bacon', 'farmersdelight:bacon');
    event.add('neoforge:bacon', 'manors_bounty:raw_pork_belly');

    event.add('neoforge:mutton_chops', 'farmersdelight:mutton_chops');
    event.add('neoforge:mutton_chops', 'manors_bounty:raw_mutton_ribs');

    event.add('neoforge:cooked_mutton_chops', 'farmersdelight:cooked_mutton_chops');
    event.add('neoforge:cooked_mutton_chops', 'manors_bounty:cooked_mutton_ribs');

    event.add('neoforge:pumpkin_slice', 'farmersdelight:pumpkin_slice');
    event.add('neoforge:pumpkin_slice', 'manors_bounty:pumpkin_slice');

    event.add('neoforge:salmon_roll', 'farmersdelight:salmon_roll');
    event.add('neoforge:salmon_roll', 'manors_bounty:salmon_nigiri');

    event.add('neoforge:fugu_roll', 'oceansdelight:fugu_roll');
    event.add('neoforge:fugu_roll', 'manors_bounty:fugu_nigiri');

    event.add('neoforge:cod_roll', 'farmersdelight:cod_roll');
    event.add('neoforge:cod_roll', 'manors_bounty:cod_nigiri');

    event.add('neoforge:tropical_roll', 'culturaldelights:tropical_roll');
    event.add('neoforge:tropical_roll', 'manors_bounty:tropical_fish_nigiri');

    event.add('neoforge:orange_slice', 'fruitsdelight:orange_slice');
    event.add('neoforge:orange_slice', 'manors_bounty:orange_segment');

    event.add('neoforge:dragon_fruit_slice', 'manors_bounty:dragon_fruit_slice');
    event.add('neoforge:dragon_fruit_slice', 'nethers_exoticism:cut_pitaya');

    event.add('neoforge:pinecone', 'seeddelight:pinecone');
    //event.add('neoforge:pinecone', 'manors_bounty:scots_pine_cone');

    event.add('neoforge:roe', 'youkaishomecoming:roe');
    event.add('neoforge:roe', 'manors_bounty:ikura');

    event.add('neoforge:fugu_slice', 'crabbersdelight:pufferfish_slice');
    event.add('neoforge:fugu_slice', 'oceansdelight:fugu_slice');
    event.add('neoforge:fugu_slice', 'manors_bounty:fugu_slice');

    //厨具系列，随时ban
    event.add('neoforge:cutting_board', 'farmersdelight:cutting_board');
    //event.add('neoforge:cutting_board', 'manors_bounty_machine:cutting_board');
    event.add('neoforge:cooking_pot', 'farmersdelight:cooking_pot');
    event.add('neoforge:cooking_pot', 'manors_bounty_machine:stock_pot');

    event.add('neoforge:copper_nugget', 'orecrop:copper_nugget');
    event.add('neoforge:copper_nugget', 'create:copper_nugget');

    event.add('quilt:crab','crabbersdelight:crab')
    event.add('quilt:crab','youkaishomecoming:crab')

    event.add('quilt:imitation_crab','youkaishomecoming:imitation_crab')
    event.add('quilt:imitation_crab','manors_bounty:surimi_crab_stick')

    event.add('quilt:bun','some_assembly_required:burger_bun')
    event.add('quilt:bun','blockdonalds:bun')

    event.add('quilt:coke','blockdonalds:coke')
    event.add('quilt:coke','fastfooddelight:cola_soda')

    event.add('quilt:catfish','aquaculture:catfish')
    event.add('quilt:catfish','naturalist:catfish')
    event.add('quilt:catfish','untameddelight:catfish')

    event.add('quilt:cheese_slice','vintagedelight:cheese_slice')
    event.add('quilt:cheese_slice','argentinas_delight:queso')
    event.add('quilt:cheese_slice','blockdonalds:cheese')
    event.add('quilt:cheese_slice','pizzadelight:cheese')
    event.add('quilt:cheese_slice','pizzacraft:cheese')
    event.add('quilt:cheese_slice','trailandtales_delight:cheese_slice')

    event.add('quilt:cucumber_seeds','vintagedelight:cucumber_seeds')
    event.add('quilt:cucumber_seeds','culturaldelights:cucumber_seeds')
    event.add('quilt:cucumber_seeds','youkaishomecoming:cucumber_seeds')
    event.add('quilt:cucumber_seeds','manors_bounty:cucumber_seed')
    event.add('quilt:cucumber_seeds','blockdonalds:cucumber_seeds')
    event.add('quilt:cucumber_seeds','pizzacraft:cucumber_seeds')

    event.add('quilt:mango_jelly','fruitsdelight:mango_jelly')
    event.add('quilt:mango_jelly','extravagantdelight:mango_jam')

    event.add('quilt:hops','extravagantdelight:hops')
    event.add('quilt:hops','alcocraftplus:hop')

    event.add('quilt:hop_seeds','extravagantdelight:hops_seeds')
    event.add('quilt:hop_seeds','alcocraftplus:hop_seeds')

    event.add('quilt:barley','extravagantdelight:barley')
    event.add('quilt:barley','yeastnfeast:barley')

    event.add('quilt:starfruit','extravagantdelight:starfruit')
    event.add('quilt:starfruit','manors_bounty:starfruit')

    event.add('quilt:grapefruit','extravagantdelight:grapefruit')
    event.add('quilt:grapefruit','manors_bounty:grapefruit')

    event.add('quilt:barley_seeds','yeastnfeast:barley_seeds')
    event.add('quilt:barley_seeds','extravagantdelight:barley_seeds')

    event.add('quilt:grapefruit_slice','manors_bounty:grapefruit_slice')
    event.add('quilt:grapefruit_slice','extravagantdelight:grapefruit_slice')

    event.add('quilt:starfruit_slice','extravagantdelight:starfruit_slice')
    event.add('quilt:starfruit_slice','manors_bounty:starfruit_slice')

    event.add('quilt:cheese_block','vintagedelight:cheese_wheel')
    event.add('quilt:cheese_block','pizzacraft:cheese_block')
    event.add('quilt:cheese_block','meadow:cheese_block')
    event.add('quilt:cheese_block','trailandtales_delight:cheese_wheel')

    event.add('quilt:beetroot_slice','some_assembly_required:chopped_beetroot')
    event.add('quilt:beetroot_slice','manors_bounty:beetroot_slice')

    event.add('quilt:ghost_pepper','ltc2:pepper_jolokia')
    event.add('quilt:ghost_pepper','vintagedelight:ghost_pepper')

    event.add('quilt:pepper_red','ltc2:pepper_red')
    event.add('quilt:pepper_red','muffins_thaidelight:pepper')

    event.add('quilt:bellpepper_seeds','rusticdelight:bell_pepper_seeds')
    event.add('quilt:bellpepper_seeds','pizzacraft:pepper_seeds')
    event.add('quilt:bellpepper_seeds','veggiesdelight:bellpepper_seeds')

    event.add('quilt:cotton_seeds','rusticdelight:cotton_seeds')
    event.add('quilt:cotton_seeds','hearthandharvest:cotton_seeds')

    event.add('quilt:strawberry_seed','manors_bounty:strawberry_seed')
    event.add('quilt:strawberry_seed','neapolitan:strawberry_pips')

    event.add('quilt:tomato_seeds','pizzacraft:tomato_seeds')
    event.add('quilt:tomato_seeds','farmersdelight:tomato_seeds')

    event.add('quilt:tea_seeds','youkaishomecoming:tea_seeds')
    event.add('quilt:tea_seeds','farmersrespite:tea_seeds')

    event.add('quilt:eggplant_seeds','dumplings_delight:eggplant_seeds')
    event.add('quilt:eggplant_seeds','culturaldelights:eggplant_seeds')

    event.add('quilt:broccoli_seeds','pizzacraft:broccoli_seeds')
    event.add('quilt:broccoli_seeds','veggiesdelight:broccoli_seeds')

    event.add('quilt:white_grape_seeds','youkaishomecoming:white_grape_seeds')
    event.add('quilt:white_grape_seeds','vinery:white_grape_seeds')
    event.add('quilt:white_grape_seeds','brewincompatdelight:white_grape_seeds')

    event.add('quilt:cherry_tomatoes','manors_bounty:cherry_tomatoes')
    event.add('quilt:cherry_tomatoes','argentinas_delight:tomatitos_cherry')

    event.add('quilt:garlic_clove','dumplings_delight:garlic_clove')
    event.add('quilt:garlic_clove','veggiesdelight:garlic_clove')

    event.add('quilt:pineapple_sapling','fruitsdelight:pineapple_sapling')
    event.add('quilt:pineapple_sapling','manors_bounty:pineapple_crop')

    event.add('quilt:starfruit_seed','extravagantdelight:starfruit_seeds')
    event.add('quilt:starfruit_seed','manors_bounty:starfruit_seed')

    event.add('quilt:red_grape_seeds','vinery:red_grape_seeds')
    event.add('quilt:red_grape_seeds','youkaishomecoming:red_grape_seeds')
    event.add('quilt:red_grape_seeds','manors_bounty:grape_seed')
    event.add('quilt:red_grape_seeds','brewincompatdelight:red_grape_seeds')

    event.add('quilt:lemon_seed','fruitsdelight:lemon_seeds')
    event.add('quilt:lemon_seed','manors_bounty:lemon_seed')
    event.add('quilt:lemon_seed','peruviansdelight:semillas_limon')

    event.add('fabric:mandrake_root', 'oddsnends:mandrake'); 
    event.add('fabric:mandrake_root', 'youkaishomecoming:mandrake_root'); 

    event.add('fabric:raw_chicken_breast', 'argentinas_delight:pechugacruda'); 
    event.add('fabric:raw_chicken_breast', 'manors_bounty:raw_chicken_breast'); 

    event.add('fabric:pineapple_pie', 'manors_bounty:pineapple_pies'); 
    event.add('fabric:pineapple_pie', 'fruitsdelight:pineapple_pie'); 

    event.add('fabric:dried_banana', 'neapolitan:dried_banana'); 
    event.add('fabric:dried_banana', 'manors_bounty:banana_chips'); 

    event.add('fabric:jerky', 'brewinandchewin:jerky'); 
    event.add('fabric:jerky', 'hearthandharvest:jerky'); 

    event.add('fabric:cooked_sniffer_egg_block', 'trailandtales_delight:cooked_sniffer_egg_block'); 
    event.add('fabric:cooked_sniffer_egg_block', 'sniffers_delight:boiled_sniffer_egg'); 

    event.add('fabric:fried_sniffer_egg', 'trailandtales_delight:fried_sniffer_egg'); 
    event.add('fabric:fried_sniffer_egg', 'unusual_delight:fried_sniffer_egg'); 

    event.add('fabric:wrapped_fries', 'fastfooddelight:french_fries'); 
    event.add('fabric:wrapped_fries', 'argentinas_delight:papasfritas'); 
    event.add('fabric:wrapped_fries', 'create_bic_bit:wrapped_fries'); 

    event.add('fabric:fries', 'manors_bounty:fries'); 
    event.add('fabric:fries', 'create_bic_bit:fries'); 
    event.add('fabric:fries', 'peruviansdelight:papas_fritas'); 

    event.add('fabric:fish_and_chips', 'casualness_delight:fish_and_chips'); 
    event.add('fabric:fish_and_chips', 'veggiesdelight:fish_and_chips'); 
    event.add('fabric:fish_and_chips', 'extravagantdelight:battered_fish_n_chips'); 
/* 
    event.add('fabric:', ); 
    event.add('fabric:', ); 

    event.add('neoforge:', );
    event.add('neoforge:', '');

    event.add('neoforge:', ''); 
    event.add('fabric:', ''); 
    event.add('forge:','');
    event.add('quilt:','')
    event.add('liteloader:', '');
    event.add('optfine:','')
*/

});


