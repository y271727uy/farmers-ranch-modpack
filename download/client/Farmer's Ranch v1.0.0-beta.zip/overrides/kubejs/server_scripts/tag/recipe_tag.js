//通用标签
//奶酪：modpack:cheese
//蔬菜：modpack:vegetables_singularity
//水果：modpack:fruit_singularity
//酱料：modpack:sauce
//食用油：modpack:food_oil


//酱料
ServerEvents.tags('item', event => {
    const sauce = [
        'farmersdelight:tomato_sauce',
        'barbequesdelight:buffalo_sauce',
        'barbequesdelight:honey_mustard_sauce',
        'barbequesdelight:barbeque_sauce',
        'list:bbq_sauce',
         'list:mayo_sauce',
          'cosmopolitan:green_sauce',
           'unusualfoodsdelight:slime_sauce',
            'ends_delight:chorus_sauce',
             'collectorsreap:prawn_spread',
              'list:pizza_sauce_blaze',
               'list:pizza_sauce_alfredo',
                'list:seafood_sauce',
                 'list:urchin_sauce',
                  'list:lime_sauce',
                   'list:pomegranate_sauce',
                    'list:pizza_sauce_tomato',
                     'list:pizza_sauce_seafood',
                      'list:pizza_sauce_torch',
                       'foragersinsight:green_sauce',
                        'peruviansdelight:huancaina',
        'list:pepper_sauce',
        'list:blaze_sauce',
        'list:ancient_sauce',
        'miners_delight:weird_caviar',
        'avaritia_delight:blaze_tomato_sauce'
    ];
    sauce.forEach(item => {
        event.add('modpack:sauce', item);
    });

    //食用油
    const food_oil = [
        'mooncake_delight:animal_fat',
        'alexsmobs:fish_oil',
        'create_bic_bit:frying_oil_bucket',
        'kubejs:bio_oil_two_bucket',
        'manors_bounty:olive_oil_bucket',
        'create_bic_bit:frying_oil_bottle',
        'manors_bounty:bottled_olive_oil',
        'rusticdelight:cooking_oil',
        'delightful:animal_oil_bottle'
    ];
    food_oil.forEach(item => {
        event.add('modpack:food_oil', item);
    });
 });
