ServerEvents.tags('block', event => {
    const Tapper_block = [
        'minecraft:mangrove_log',
        'forestry:teak_log',
        'forestry:baobab_log', 'forestry:orange_log', 'forestry:citrus_log', 'forestry:lime_log', 'extravagantdelight:grapefruit_log', 'manors_bounty:rutaceae_tree_log', 'fruitfulfun:citrus_log', 'collectorsreap:lucuma_log', 'manors_bounty:rosaceae_tree_log', 'forestry:papaya_log', 'forestry:plum_log', 'forestry:ipe_log', 'forestry:padauk_log', 'forestry:cocobolo_log', 'forestry:olive_log', 'forestry:macrocarpa_log', 'manors_bounty:alpine_tree_log','forestry:pewen_log', 'forestry:jacaranda_log', 'forestry:ginkgo_log', 'forestry:mahoe_log', 'forestry:greenheart_log', 'forestry:wenge_log', 'forestry:kapok_log', 'forestry:ebony_log', 'forestry:elm_log', 'forestry:mahogany_log', 'forestry:balsa_log', 'forestry:willow_log', 'forestry:walnut_log', 'forestry:chestnut_log', 'alexscaves:thornwood_log', 'forestry:coconut_log', 'forestry:palm_log', 'ramadandelight:palm_log',
        'fruitfulfun:redlove_log', 'culturaldelights:avocado_log', 'forestry:pear_log', 'forestry:kauri_log', 'forestry:fir_log', 'forestry:beech_log', 'forestry:feijoa_log', 'forestry:dogwood_log', 'forestry:poplar_log', 'vietnam_delight:plum_log', 'peruviansdelight:limonero_log', 'manors_bounty:avocado_tree_log', 'manors_bounty:kiwifruit_tree_log', 'manors_bounty:mango_tree_log', 'manors_bounty:durian_tree_log', 'manors_bounty:fig_tree_log', 'manors_bounty:coconut_tree_log', 'bountifulfares:walnut_log', 'nethers_exoticism:jabuticaba_log', 'peruviansdelight:palto_log', 'bountifulfares:hoary_log', 'nethers_exoticism:ramboutan_log', 'muffins_thaidelight:papaya_log', 'manors_bounty:cherries_tree_log', 'manors_bounty:starfruit_tree_log', 'manors_bounty:olive_tree_log', 'immortalers_delight:himekaido_log', 'immortalers_delight:ancient_wood_log', 'extravagantdelight:mango_log', 'extravagantdelight:quince_log', 'manors_bounty:hawthorn_tree_log', 'manors_bounty:pomegranate_tree_log', 'vinery:apple_log', 'unusualprehistory:dryo_log', 'unusualprehistory:ginkgo_log', 'unusualprehistory:foxxi_log'

    ];

    Tapper_block.forEach(block => {
        event.add('tapper_log', block);
    });

    const Tapper_block_pine = [
        'forestry:pine_log',
        'meadow:pine_log',
        'forestry:larch_log',
        'manors_bounty:scots_pine_log'
    ];

    Tapper_block_pine.forEach(block => {
        event.add('tapper_pine_log', block);
    });

});