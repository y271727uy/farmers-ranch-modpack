// Classify Regions Unexplored biomes using the vanilla and Forge biome tags
// shipped with this 1.20.1 Forge profile.
ServerEvents.tags('worldgen/biome', event => {
    const overworld = [
        'alpha_grove', 'autumnal_maple_forest', 'bamboo_forest', 'baobab_savanna',
        'barley_fields', 'bayou', 'blackwood_taiga', 'boreal_taiga', 'chalk_cliffs',
        'clover_plains', 'cold_boreal_taiga', 'cold_deciduous_forest', 'cold_river',
        'deciduous_forest', 'dry_bushland', 'eucalyptus_forest', 'fen', 'flower_fields',
        'frozen_pine_taiga', 'frozen_tundra', 'glistering_meadow', 'golden_boreal_taiga',
        'grassland', 'grassy_beach', 'gravel_beach', 'highland_fields', 'hyacinth_deeps',
        'icy_heights', 'joshua_desert', 'magnolia_woodland', 'maple_forest', 'marsh',
        'mauve_hills', 'mountains', 'muddy_river', 'old_growth_bayou', 'orchard',
        'outback', 'pine_slopes', 'pine_taiga', 'poppy_fields', 'prairie', 'prismachasm',
        'pumpkin_fields', 'rainforest', 'redstone_caves', 'redwoods', 'rocky_meadow',
        'rocky_reef', 'saguaro_desert', 'scorching_caves', 'shrubland',
        'silver_birch_forest', 'sparse_rainforest', 'sparse_redwoods', 'spires', 'steppe',
        'temperate_grove', 'towering_cliffs', 'tropical_river', 'tropics', 'willow_forest'
    ].map(id => `regions_unexplored:${id}`);

    const nether = [
        'ashen_woodland', 'blackstone_basin', 'infernal_holt',
        'mycotoxic_undergrowth', 'redstone_abyss', 'ancient_delta', 'bioshroom_caves'
    ].map(id => `regions_unexplored:${id}`);

    const add = (tag, ids) => ids.forEach(id => event.add(tag, id));
    const ru = ids => ids.map(id => `regions_unexplored:${id}`);

    add('minecraft:is_overworld', overworld);
    add('minecraft:is_nether', nether);

    add('minecraft:is_beach', ru(['grassy_beach', 'gravel_beach']));
    add('minecraft:is_forest', ru([
        'alpha_grove', 'autumnal_maple_forest', 'cold_deciduous_forest',
        'deciduous_forest', 'eucalyptus_forest', 'magnolia_woodland', 'maple_forest',
        'redwoods', 'silver_birch_forest', 'sparse_redwoods', 'temperate_grove',
        'willow_forest'
    ]));
    add('minecraft:is_hill', ru(['mauve_hills', 'rocky_meadow']));
    add('minecraft:is_jungle', ru(['bamboo_forest', 'rainforest', 'sparse_rainforest', 'tropics']));
    add('minecraft:is_mountain', ru([
        'chalk_cliffs', 'highland_fields', 'icy_heights', 'mountains', 'pine_slopes',
        'spires', 'towering_cliffs'
    ]));
    add('minecraft:is_river', ru(['cold_river', 'muddy_river', 'tropical_river']));
    add('minecraft:is_savanna', ru(['baobab_savanna', 'dry_bushland', 'outback', 'steppe']));
    add('minecraft:is_taiga', ru([
        'blackwood_taiga', 'boreal_taiga', 'cold_boreal_taiga', 'frozen_pine_taiga',
        'golden_boreal_taiga', 'pine_taiga'
    ]));

    add('forge:is_cave', ru(['bioshroom_caves', 'prismachasm', 'redstone_caves', 'scorching_caves']));
    add('forge:is_cold', ru([
        'cold_boreal_taiga', 'cold_deciduous_forest', 'cold_river', 'frozen_pine_taiga',
        'frozen_tundra', 'icy_heights', 'pine_slopes', 'pine_taiga', 'spires'
    ]));
    add('forge:is_desert', ru(['joshua_desert', 'saguaro_desert']));
    add('forge:is_dry', ru([
        'arid_mountains', 'dry_bushland', 'joshua_desert', 'mauve_hills', 'outback',
        'saguaro_desert', 'steppe'
    ]));
    add('forge:is_hot', ru([
        'baobab_savanna', 'dry_bushland', 'joshua_desert', 'rainforest', 'saguaro_desert',
        'steppe', 'tropical_river', 'tropics'
    ]));
    add('forge:is_lush', ru([
        'alpha_grove', 'bamboo_forest', 'clover_plains', 'flower_fields', 'glistering_meadow',
        'rainforest', 'redwoods', 'sparse_rainforest', 'tropics', 'willow_forest'
    ]));
    add('forge:is_mountain', ru([
        'arid_mountains', 'chalk_cliffs', 'highland_fields', 'icy_heights', 'mountains',
        'pine_slopes', 'rocky_meadow', 'spires', 'towering_cliffs'
    ]));
    add('forge:is_peak', ru(['arid_mountains', 'icy_heights', 'mountains', 'spires']));
    add('forge:is_plains', ru([
        'barley_fields', 'clover_plains', 'flower_fields', 'grassland', 'highland_fields',
        'orchard', 'poppy_fields', 'prairie', 'pumpkin_fields', 'shrubland', 'steppe'
    ]));
    add('forge:is_sandy', ru(['grassy_beach', 'joshua_desert', 'saguaro_desert']));
    add('forge:is_slope', ru(['pine_slopes', 'rocky_meadow']));
    add('forge:is_snowy', ru(['frozen_pine_taiga', 'frozen_tundra', 'icy_heights', 'spires']));
    add('forge:is_sparse', ru(['sparse_rainforest', 'sparse_redwoods']));
    add('forge:is_swamp', ru(['bayou', 'fen', 'fungal_fen', 'marsh', 'old_growth_bayou']));
    add('forge:is_underground', ru([
        'bioshroom_caves', 'hyacinth_deeps', 'prismachasm', 'redstone_caves', 'scorching_caves'
    ]));
    add('forge:is_water', ru(['ancient_delta', 'cold_river', 'hyacinth_deeps', 'muddy_river', 'rocky_reef', 'tropical_river']));
    add('forge:is_wet', ru([
        'bayou', 'fen', 'marsh', 'muddy_river', 'rainforest', 'rocky_reef',
        'sparse_rainforest', 'tropical_river', 'tropics'
    ]));
});
