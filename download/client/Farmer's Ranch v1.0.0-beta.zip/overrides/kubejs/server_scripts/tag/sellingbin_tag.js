ServerEvents.tags('item', event => {
    event.add('shopcore:seven_to_eleven', 
        'immortalers_delight:pearlip',
        'pineapple_delight:pineapple_old',
        'immortalers_delight:alfalfa',
        'immortalers_delight:gelpitaya',
        'immortalers_delight:contains_tea_leisamboo',
        'bountifulfares:hoary_apple',
        'immortalers_delight:warped_laurel',
        'immortalers_delight:himekaido',
        'immortalers_delight:sextlotus_root',
        'immortalers_delight:oxygrape',
        'trailandtales_delight:lantern_fruit',
        'immortalers_delight:a_bush',
        'immortalers_delight:kwat_wheat',
        'trailandtales_delight:pitcher_taro',
        'immortalers_delight:evolutcorn'
    )

    event.add('shopcore:five_to_eight',
        'delighto_flight:rainy_cloudshroom', 
        'delighto_flight:thunder_cloudshroom', 
        'delighto_flight:clear_cloudshroom', 
        'delighto_flight:cloud_berries', 
        'delighto_flight:thunder_fruit', 
        'pineapple_delight:huge_pineapple', 
        'oceanic_delight:sea_grape', 
        'bountifulfares:spongekin', 
        'untamedwilds:food_aardvark_cucumber', 
        'youkaishomecoming:mandrake_root', 
        'youkaishomecoming:udumbara_flower'
    )

    event.add('shopcore:seven_to_ten', 
        'ltc2:pepper_frost', 'collectorsreap:stygian_pomegranate', 'ltc2:pepper_umbrvol', 'ltc2:sculk_mint', 'manors_bounty:end_pepper', 'frightsdelight:wither_berry', 'ltc2:illage_lime', 'frightsdelight:soul_berry', 'ltc2:pepper_endbond', 'nethervinery:warped_grape', 'nethervinery:crimson_grape', 'mynethersdelight:bullet_pepper', 'endersdelight:chorusflame', 'ltc2:pepper_complained', 'endersdelight:ethereal_saffron', 'dungeonsdelight:rotbulb', 'ltc2:pepper_bloody', 'endersdelight:voidpepper'
    )

    event.add('shopcore:four_to_six', 
        'vital_herbs:grim_vine', 'vital_herbs:iron_root', 'vital_herbs:needle_heart', 'vital_herbs:bleeding_heart', 'vital_herbs:glow_leaf', 'vital_herbs:snap_pepper', 'vital_herbs:burst_bud', 'vital_herbs:fizz_fruit', 'vital_herbs:crimson_lily', 'vital_herbs:blue_spar', 'vital_herbs:razor_leaf', 'vital_herbs:mourning_bloom', 'vital_herbs:frost_mint'
    )

    event.add('shopcore:seven_to_twelve',
        'fungidelight:truffle', 'manors_bounty:muscat_grape', 'manors_bounty:gooseberry', 'manors_bounty:grapefruit', 'manors_bounty:blackberry', 'manors_bounty:black_olive_fruit', 'manors_bounty:ume', 'manors_bounty:green_apple', 'vietnam_delight:golden_plum', 'manors_bounty:gold_kiwifruit', 'neapolitan:white_strawberries'
    )

    event.add('shopcore:one_to_two',
        'cosmopolitan:wildberry', 'minecraft:warped_fungus', 'minecraft:crimson_fungus', 'minecraft:red_mushroom', 'minecraft:beetroot', 'minecraft:sweet_berries', 'minecraft:sugar_cane', 'minecraft:brown_mushroom', 'minecraft:cocoa_beans', 'minecraft:wheat', 'minecraft:nether_wart'
    )

    event.add('shopcore:three_to_five',
        'manors_bounty:apricot', 'bountifulfares:plum', 'muffins_thaidelight:papaya', 'vinery:white_grape', 'fruitsdelight:fig', 'muffins_thaidelight:raw_papaya', 'fruitsdelight:mangosteen', 'fruitsdelight:hawberry', 'hearthandharvest:raspberry', 'farmersdelight:rice', 'vietnam_delight:sticky_rice', 'fruitsdelight:kiwi', 'fruitsdelight:pear', 'youkaishomecoming:coffee_berries', 'createcafe:coffee_fruit', 'manors_bounty:coffee_berry', 'delightful:salmonberries', 'collectorsreap:pomegranate', 'bountifulfares:passion_fruit', 'manors_bounty:starfruit', 'manors_bounty:yuzumelo', 'fruitsdelight:persimmon', 'braziliandelight:coffee_berries', 'coffee_delight:coffee_berries', 'farmersrespite:coffee_berries', 'minecraft:glow_berries', 'collectorsreap:portobello', 'manors_bounty:holly_berry', 'nethers_exoticism:bouddha_s_hand', 'vinery:jungle_grapes_red', 'vinery:jungle_grapes_white',
        'vietnam_delight:lotot_leaf', 'vietnam_delight:garlic_chives', 'veggiesdelight:dandelion_leaf', 'cosmopolitan:fiddlehead', 'braziliandelight:yerba_mate_leaves', 'argentinas_delight:yerbamate', 'vintagedelight:cucumber', 'farm_and_charm:lettuce', 'veggiesdelight:zucchini', 'vinery:savanna_grapes_white', 'collectorsreap:lime', 'dumplings_delight:chinese_cabbage', 'vietnam_delight:mung_beans', 'vietnam_delight:basil_leaf', 'braziliandelight:collard_greens', 'manors_bounty:wild_jalapeno', 'dumplings_delight:fennel', 'vietnam_delight:pandan_leaf', 'farmersdelight:cabbage', 'alcocraftplus:hop', 'extravagantdelight:rhubarb', 'dumplings_delight:greenonion', 'cosmopolitan:wheatgrass', 'vietnam_delight:lotus_embryo', 'delighto_flight:lotus_seeds', 'veggiesdelight:broccoli', 'neapolitan:mint_leaves', 'braziliandelight:bean_pod', 'spanishdelight:green_bean', 'ltc2:pepper_green', 'neapolitan:vanilla_pods', 'ubesdelight:lemongrass', 'dumplings_delight:garlic_chive', 'bountifulfares:leek', 'ramadandelight:parsley', 'argentinas_delight:espinacaitem',
        'manors_bounty:walpecan', 'manors_bounty:chestnut', 'forestry:fruit_feijoa', 'veggiesdelight:cauliflower', 'foragersinsight:spruce_tips', 'rusticdelight:bell_pepper_green', 'foragersinsight:dandelion_root', 'vietnam_delight:bean_sprouts', 'manors_bounty:star_anise', 'bountifulfares:tea_berries', 'manors_bounty:tomato', 'vietnam_delight:bird_eye_chilis', 'braziliandelight:cassava_root', 'vietnam_delight:young_lotus_stem', 'vietnam_delight:turmeric', 'yeastnfeast:ginger', 'braziliandelight:carioca_beans', 'vegandelight:soybean', 'braziliandelight:garlic_bulb', 'wildernature:hazelnut', 'fruitsdelight:pineapple', 'neapolitan:strawberries', 'peruviansdelight:aji_amarillo', 'miners_delight:cave_carrot', 'rusticdelight:bell_pepper_red', 'yeastnfeast:rye', 'farmersdelight:onion', 'manors_bounty:baby_corn', 'extravagantdelight:green_mango', 'vietnam_delight:green_banana_bunch', 'vietnam_delight:green_kumquat', 'farmersrespite:green_tea_leaves', 'vinery:taiga_grapes_white', 'delightful:mini_melon', 'ltc2:pepper_white', 'braziliandelight:green_coconut',
        'manors_bounty:scots_pine_cone', 'youkaishomecoming:soybean', 'braziliandelight:black_beans', 'foragersinsight:black_acorn', 'manors_bounty:pistachio', 'culturaldelights:eggplant', 'veggiesdelight:turnip', 'mooncake_delight:white_sesame', 'manors_bounty:cashew', 'farmersrespite:black_tea_leaves', 'rusticdelight:cotton_boll', 'vinery:red_grape', 'manors_bounty:jalapeno', 'minecraft:apple', 'fruitsdelight:orange', 'bountifulfares:orange', 'yeastnfeast:barley', 'minecraft:pumpkin', 'muffins_thaidelight:pepper', 'manors_bounty:clove', 'fungidelight:morel_mushroom', 'fungidelight:inky_cap_mushroom', 'vintagedelight:oat', 'rusticdelight:bell_pepper_yellow', 'farmersrespite:yellow_tea_leaves', 'ubesdelight:ube', 'minecraft:potato', 'vintagedelight:ghost_pepper', 'uwabami_breakers:konjak', 'delighto_flight:lotus_root', 'veggiesdelight:sweet_potato', 'vietnam_delight:shallot', 'festive_delight:cinnamon_sticks', 'foragersinsight:poppy_seeds', 'seeddelight:sunflower_seed', 'ramadandelight:chickpea',
        'fruitsdelight:cranberry', 'mooncake_delight:black_sesame', 'vintagedelight:gearo_berry', 'vietnam_delight:kumquat', 'vintagedelight:peanut', 'vinery:savanna_grapes_red', 'seeddelight:acorn', 'fruitsdelight:peach', 'braziliandelight:corn', 'culturaldelights:white_eggplant', 'fruitsdelight:mango', 'minecraft:carrot', 'fruitsdelight:lemon', 'neapolitan:banana_bunch', 'fruitfulfun:citron', 'farmersdelight:tomato', 'neapolitan:adzuki_beans', 'manors_bounty:cherry_tomatoes', 'vinery:taiga_grapes_red', 'manors_bounty:nutmeg'
    )

    event.add('shopcore:four_to_seven',
        'fruitfulfun:lime', 'bountifulfares:elderberries', 'fruitsdelight:lychee', 'extravagantdelight:lush_mango', 'manors_bounty:cherries', 'fruitsdelight:durian', 'manors_bounty:musang_king_durian', 'braziliandelight:guarana_fruit', 'collectorsreap:lucuma', 'brewincompatdelight:juniper_berries', 'manors_bounty:purple_sugar_cane', 'cosmopolitan:arbutus_berries', 'fruitsdelight:bayberry', 'braziliandelight:coconut', 'ramadandelight:date', 'bountifulfares:walnut', 'braziliandelight:acai_berries', 'nethers_exoticism:jaboticaba', 'nethers_exoticism:ramboutan', 'manors_bounty:dragon_fruit', 'nethers_exoticism:kiwano', 'collectorsreap:pink_dragon_fruit', 'youkaishomecoming:black_grape', 'bountifulfares:lapisberries', 'extravagantdelight:muscadine_grapes', 'extravagantdelight:sloe_berries', 'manors_bounty:blackcurrant', 'fruitsdelight:blueberry', 'delightful:cantaloupe', 'minecraft:melon', 'fruitsdelight:hamimelon', 'manors_bounty:olive_fruit', 'vinery:cherry', 'argentinas_delight:membrillo', 'culturaldelights:avocado', 'fruitfulfun:redlove'
    )

   event.add('shopcore:one_three_five',
        'minecraft:kelp','netherdepthsupgrade:crimson_kelp','netherdepthsupgrade:warped_kelp','minecraft:chorus_fruit','ends_delight:chorus_succulent'
    )

    event.add('shopcore:fifty_to_eighty',
        'avaritia_delight:blaze_tomato','avaritia_delight:diamond_lattice_potato','avaritia_delight:crystal_cabbage','avaritia_delight:neutronium_wheat'
    )

    //event.add('shopcore:',

    //)

    //肉类  1-2
    event.add('shopcore:meat_one_to_two',
        'dungeonsdelight:spider_meat', 'dungeonsdelight:silverfish_abdomen', 'unusualfoodsdelight:spider_legs', 'unusual_delight:raw_zork_chop', 'youkaishomecoming:raw_boarchop_bits', 'argentinas_delight:carnepicadaitem', 'crabbersdelight:raw_frog_leg', 'unusual_delight:raw_mite_meat', 'ends_delight:raw_ender_mite_meat', 'dungeonsdelight:gritty_flesh', 'dungeonsdelight:sculk_polyp'
    )
    //3-5
    event.add('shopcore:meat_three_to_five',
        'manors_bounty:raw_beef_cubes', 'foragersinsight:raw_rabbit_leg', 'aquaculturedelight:small_turtle_meat', 'crabbersdelight:raw_clam_meat', 'collectorsreap:clam_meat', 'alexsmobsdelight:raw_tusklin_meat_piece', 'alexsmobsdelight:raw_kangaroo_meat_slice', 'collectorsreap:chieftain_crab_meat', 'alexsmobsdelight:raw_bison_meat_cubes', 'oceanic_delight:shrimp_slices', 'unusualfishmod:raw_mossthorn', 'unusual_delight:fish_blob', 'collectorsreap:uni'
    )

    //3-6
    event.add('shopcore:meat_three_to_six',
        'culturaldelights:squid', 'manors_bounty:raw_chicken_wing', 'manors_bounty:raw_duck_foot', 'manors_bounty:raw_duck_drumstick', 'manors_bounty:raw_chicken_foot', 'untameddelight:terror_bird_leg', 'unusualfoodsdelight:minced_bad_flesh', 'alexsmobsdelight:mimic_octopus_tentacle', 'farmersdelight:chicken_cuts', 'manors_bounty:raw_duck_neck', 'farmersdelight:minced_beef', 'luncheonmeatsdelight:minced_pork', 'manors_bounty:raw_chicken_neck', 'untameddelight:sliced_bear', 'youkaishomecoming:flesh', 'wildernature:pelican_meat', 'culturaldelights:glow_squid', 'manors_bounty:raw_duck_wing', 'manors_bounty:raw_chicken_drumstick', 'argentinas_delight:nalga', 'argentinas_delight:tirasdeasado', 'argentinas_delight:tirasdechancho', 'youkaishomecoming:raw_tuna', 'youkaishomecoming:raw_tuna_slice', 'youkaishomecoming:otoro', 'manors_bounty:raw_duck_breast', 'manors_bounty:raw_chicken_breast', 'unusual_delight:cut_lost_tentacle'
    )

    //7-9
    event.add('shopcore:meat_seven_to_nine',
        'meadow:raw_buffalo_meat', 'unusualfoodsdelight:bad_flesh', 'alexsmobsdelight:raw_turtle_meat', 'wildernature:cassowary_meat', 'alexsmobsdelight:raw_crocodile_meat', 'dungeonsdelight:sniffer_shank', 'unusualfoodsdelight:bam_bam_smoked_meat', 'unusualprehistory:raw_austro', 'unusualprehistory:raw_coty', 'minecraft:rabbit', 'manors_bounty:raw_bresse_chicken', 'wildernature:turkey_meat', 'minecraft:chicken', 'untitledduckmod:raw_goose', 'manors_bounty:raw_mallard_duck', 'alexsmobs:kangaroo_meat', 'mynethersdelight:hoglin_loin', 'minecraft:beef', 'unusualprehistory:raw_mammoth', 'alexsmobsdelight:raw_tusklin_meat', 'neapolitan:mint_chops', 'unusual_delight:raw_sniffer_meat', 'delightful:raw_goat', 'alexsmobsdelight:raw_anaconda', 'alexsmobsdelight:seal_meat', 'alexsmobsdelight:raw_bear_meat', 'minecraft:mutton', 'untamedwilds:food_turtle_raw', 'wildernature:venison', 'untameddelight:camel_meat', 'casualness_delight:raw_donkey_meat', 'youkaishomecoming:raw_boarchop', 'alexsmobsdelight:raw_bison_meat', 'untamedwilds:food_pachyderm_raw'
    )

    //9-11
    event.add('shopcore:meat_nine_to_eleven',
        'alexsmobsdelight:whale_meat','ends_delight:raw_dragon_meat','cavedelight:raw_dino_cut'
    )

    //林业 2-4
    event.add('shopcore:forestry_two_to_four',
        'forestry:propolis_pulsating','mobees:arcane_wax','minecraft:honeycomb','mobees:soul_wax', 'forestry:propolis_normal', 'forestry:propolis_volcanic', 'forestry:propolis_silky', 'forestry:honeydew', 'forestry:honey_drop', 'forestry:beeswax', 'forestry:refractory_wax'
    )

    //1-3
    event.add('shopcore:forestry_one_to_three',
        'list:raw_lacquer_bucket', 'list:urushi_bucket', 'list:tree_sap', 'foragersinsight:birch_syrup_bottle', 'cosmopolitan:birch_sap_bottle', 'alexscaves:pewen_sap'
    )

    //4-6
    event.add('shopcore:forestry_four_to_six',
        'forestry:bee_comb_honey', 'forestry:bee_comb_cocoa', 'forestry:bee_comb_simmering', 'forestry:bee_comb_stringy', 'forestry:bee_comb_frozen', 'forestry:bee_comb_dripping', 'forestry:bee_comb_silky', 'forestry:bee_comb_parched', 'forestry:bee_comb_mysterious', 'forestry:bee_comb_powdery', 'forestry:bee_comb_wheaten', 'forestry:bee_comb_mossy', 'forestry:bee_comb_mellow', 'forestry:bee_comb_kaolin', 'forestry:bee_comb_vintage', 'forestry:bee_comb_sponge', 'forestry:bee_comb_sculken',
        'mobees:bee_comb_rocky', 'mobees:bee_comb_mineral', 'mobees:bee_comb_coal', 'mobees:bee_comb_copper', 'mobees:bee_comb_tin', 'mobees:bee_comb_zinc', 'mobees:bee_comb_lead', 'mobees:bee_comb_nickel', 'mobees:bee_comb_silver', 'mobees:bee_comb_iron', 'mobees:bee_comb_gold', 'mobees:bee_comb_lapis', 'mobees:bee_comb_apatite', 'mobees:bee_comb_redstone', 'mobees:bee_comb_amethyst', 'mobees:bee_comb_diamond', 'mobees:bee_comb_emerald', 'mobees:bee_comb_harmonic', 'mobees:bee_comb_chromatic', 'mobees:bee_comb_glowing', 'mobees:bee_comb_fungal', 'mobees:bee_comb_soulful', 'mobees:bee_comb_arcane', 'mobees:bee_comb_decayed', 'mobees:bee_comb_paper'
    )

    //7-8
    event.add('shopcore:forestry_seven_to_eight',
        'mobees:bee_comb_scrapped','forestry:royal_jelly'
    )
});