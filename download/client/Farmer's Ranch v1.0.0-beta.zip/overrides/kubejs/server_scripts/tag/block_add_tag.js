ServerEvents.tags('block', event => {

    const Manors_bounty_universal_heat_blocks = [
        'mynethersdelight:nether_stove',
        'ends_delight:end_stove',
        'endersdelight:endstone_stove', 
        'farmersdelight:stove', 
        'trailandtales_delight:mud_stove', 
        'avaritia_delight:extreme_stove', 
        'mynethersdelight:nether_stove', 
        'dungeonsdelight:dungeon_stove', 
        'undertale_delight:undynes_stove', 
        'immortalers_delight:ancient_stove', 
        'immortalers_delight:exposed_ancient_stove', 
        'immortalers_delight:weathered_ancient_stove', 
        'immortalers_delight:oxidized_ancient_stove',
        'farm_and_charm:stove'
        ];
    Manors_bounty_universal_heat_blocks.forEach(block => {
        event.add('manors_bounty:universal_heat_blocks', block);
    });

});