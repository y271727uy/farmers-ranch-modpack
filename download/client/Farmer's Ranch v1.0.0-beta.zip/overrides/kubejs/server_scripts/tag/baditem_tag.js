ServerEvents.tags('item', event => {
    const bad_item = [
        'list:bad_item'
        //技术性物品
    ];
    
    bad_item.forEach(block => {
        event.add('modpack:bad_item', block);
    });


});