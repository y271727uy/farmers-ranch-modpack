ServerEvents.tags('item', event => {

    event.add('fabric:mashed_potatoes', 'hearthandharvest:mashed_potatoes');
    event.add('fabric:mashed_potatoes', 'immortalers_delight:mashed_potatoes');
    event.add('fabric:mashed_potatoes', 'moredelight:mashed_potatoes');

    //event.add('fabric:plum_sapling', 'vietnam_delight:plum_sapling'); 
    event.add('fabric:plum_sapling', 'bountifulfares:plum_sapling'); 

    event.add('fabric:flowering_plum_leaves', 'vietnam_delight:plum_flowering_leaves'); 
    event.add('fabric:flowering_plum_leaves', 'bountifulfares:flowering_plum_leaves'); 

    event.add('fabric:plum_leaves', 'vietnam_delight:plum_leaves'); 
    event.add('fabric:plum_leaves', 'bountifulfares:plum_leaves'); 

    event.add('fabric:plum_log', 'vietnam_delight:small_plum_log'); 
    event.add('fabric:plum_log', 'bountifulfares:plum_log'); 

    event.add('fabric:stripped_plum_log', 'vietnam_delight:small_stripped_plum_log'); 
    event.add('fabric:stripped_plum_log', 'bountifulfares:stripped_plum_log'); 

    event.add('fabric:lemongrass', 'ubesdelight:lemongrass'); 
    event.add('fabric:lemongrass', 'vietnam_delight:lemongrass'); 

    event.add('fabric:greenonion', 'vietnam_delight:scallion'); 
    event.add('fabric:greenonion', 'dumplings_delight:greenonion'); 

    event.add('forge:oat', 'farm_and_charm:oat');
    event.add('forge:oat', 'vintagedelight:oat');

    event.add('fabric:banana_flower', 'manors_bounty:banana_tree_flower_item'); 
    event.add('fabric:banana_flower', 'vietnam_delight:banana_blossom'); 

    event.add('fabric:lotus_root', 'delighto_flight:lotus_root'); 
    event.add('fabric:lotus_root', 'vietnam_delight:lotus_rhizome'); 

    event.add('fabric:lotus_seeds', 'delighto_flight:lotus_seeds'); 
    event.add('fabric:lotus_seeds', 'vietnam_delight:lotus_seeds'); 
    event.add('fabric:lotus_root', 'mooncake_delight:lotus_seed');

    event.add('fabric:strawberry_pips', 'neapolitan:strawberry_pips'); 
    event.add('fabric:strawberry_pips', 'farm_and_charm:strawberry_seeds'); 

    event.add('fabric:barley_seeds', 'farm_and_charm:barley_seeds'); 
    event.add('fabric:barley_seeds', 'yeastnfeast:barley_seeds'); 

    event.add('fabric:barley', 'farm_and_charm:barley'); 
    event.add('fabric:barley', 'yeastnfeast:barley'); 

    event.add('fabric:banana_frond', 'manors_bounty:banana_frond'); 
    event.add('fabric:banana_frond', 'vietnam_delight:banana_leaf'); 

    event.add('fabric:green_lime_seeds', 'collectorsreap:lime_seeds'); 
    event.add('fabric:green_lime_seeds', 'vietnam_delight:lime_seeds'); 

    event.add('fabric:yeast', 'yeastnfeast:yeast'); 
    event.add('fabric:yeast', 'farm_and_charm:yeast'); 

    event.add('fabric:toasted_bread_slice', 'some_assembly_required:toasted_bread_slice'); 
    event.add('fabric:toasted_bread_slice', 'argentinas_delight:tostaditas'); 

    event.add('fabric:raw_bear_meat', 'alexsmobsdelight:raw_bear_meat'); 
    event.add('fabric:raw_bear_meat', 'untamedwilds:food_bear_raw'); 

    event.add('fabric:cooked_bear_meat', 'untamedwilds:food_bear_cooked'); 
    event.add('fabric:cooked_bear_meat', 'alexsmobsdelight:cooked_bear_meat'); 

    event.add('fabric:cinnamon', 'festive_delight:cinnamon_sticks'); 
    event.add('fabric:cinnamon', 'manors_bounty:cinnamon');
    event.add('fabric:cinnamon', 'farmers_delight_christmas_editon:cinnamon');

    event.add('fabric:cinnamon_powder', 'manors_bounty:cinnamon_powder'); 
    event.add('fabric:cinnamon_powder', 'festive_delight:cinnamon_powder'); 

    event.add('fabric:chestnut', 'forestry:fruit_chestnut'); 
    event.add('fabric:chestnut', 'manors_bounty:chestnut');

    event.add('fabric:cooked_bison_meat', 'alexsmobsdelight:cooked_bison_meat'); 
    event.add('forge:salt2', 'vietnam_delight:salt'); 
    event.add('forge:ginger','vietnam_delight:ginger');
    event.add('forge:plum','vietnam_delight:plum');
    event.add('forge:garlic','vietnam_delight:garlic');
    event.add('neoforge:lime_slice','vietnam_delight:lime_slice');
    event.add('neoforge:banana_bunch', 'vietnam_delight:banana_bunch');
    event.add('neoforge:banana', 'vietnam_delight:banana');
    event.add('forge:lime','vietnam_delight:lime');
    event.add('forge:corn_seeds', 'farm_and_charm:kernels'); 
    event.add('forge:corn', 'farm_and_charm:corn');
    event.add('forge:strawberry', 'farm_and_charm:strawberry');
    event.add('neoforge:tomato', 'farm_and_charm:tomato');
    event.add('quilt:tomato_seeds', 'farm_and_charm:tomato_seeds');
    event.add('forge:onion', 'farm_and_charm:onion');
    event.add('neoforge:wheat_dough', 'farm_and_charm:dough');
    event.add('forge:pear','forestry:fruit_pear');
    event.add('forge:orange','forestry:fruit_orange');
    event.add('forge:coconut','forestry:fruit_coconut');
    event.add('neoforge:coconut','forestry:fruit_coconut');
    event.add('neoforge:bacon', 'farm_and_charm:bacon');
    event.add('neoforge:tomato', 'kaleidoscope_cookery:tomato');
    event.add('quilt:pepper_red', 'kaleidoscope_cookery:red_chili');
    event.add('neoforge:cook_egg', 'kaleidoscope_cookery:fried_egg');
    event.add('quilt:tomato_seeds', 'kaleidoscope_cookery:tomato_seed');
    event.add('fabric:fries', 'moderndelight:deep_fried_potato_chips');
    event.add('forge:squid', 'moderndelight:squid');
    event.add('forge:glow_squid', 'moderndelight:glow_squid');
    event.add('forge:calamari2', 'moderndelight:squid_tentacle');
    event.add('forge:squid_tentacles', 'moderndelight:glow_squid_tentacle');
    event.add('quilt:garlic_clove', 'moderndelight:garlic_petal');
    event.add('forge:garlic','moderndelight:garlic')
    event.add('forge:cherry','moderndelight:cherry')
    event.add('forge:shrimp','moderndelight:prawn')
    event.add('fabric:wrapped_fries','moderndelight:french_fries')
    event.add('neoforge:potato_slices','moderndelight:raw_potato_chip')
    event.add('forge:butter','moderndelight:butter')
    event.add('neoforge:apple_slices','moderndelight:apple_petal')
    event.add('fabric:sausage','moderndelight:sausage')
    event.add('quilt:cheese_slice','moderndelight:cheese')

    event.add('fabric:hazelnut', 'manors_bounty:hazelnut'); 
    event.add('fabric:hazelnut', 'wildernature:hazelnut');

    event.add('fabric:pine_nut', 'manors_bounty:pine_nut'); 
    event.add('fabric:pine_nut', 'alexscaves:pine_nuts');

    event.add('fabric:birch_sap_bottle', 'foragersinsight:birch_sap_bottle');
    event.add('fabric:birch_sap_bottle', 'cosmopolitan:birch_sap_bottle');

    event.add('fabric:corncob', 'list:corncob'); 
    event.add('fabric:corncob', 'corn_delight:corncob'); 

    event.add('fabric:sweet_dough', 'create_bic_bit:sweet_dough'); 
    event.add('fabric:sweet_dough', 'manors_bounty:sweet_dough'); 
    event.add('fabric:sweet_dough', 'list:sweet_dough'); 
    
    event.add('fabric:marshmallow', 'list:marshmallow'); 
    event.add('fabric:marshmallow', 'manors_bounty:marshmallow');
    event.add('fabric:marshmallow', 'farmers_delight_christmas_editon:marshmallow'); 
    event.add('fabric:marshmallow', 'sweet_delight:marshmallow');
    event.add('fabric:marshmallow', 'create_confectionery:marshmallow'); 

    event.add('fabric:chocolate_bar', 'neapolitan:chocolate_bar'); 
    event.add('fabric:chocolate_bar', 'create:bar_of_chocolate'); 
    event.add('fabric:chocolate_bar', 'hearthandharvest:chocolate_bar'); 

    event.add('fabric:popcorn', 'manors_bounty:popcorn'); 
    event.add('fabric:popcorn', 'culturaldelights:popcorn'); 
    event.add('fabric:popcorn', 'corn_delight:popcorn'); 

    event.add('fabric:graham_cracker', 'list:graham_cracker'); 
    event.add('fabric:graham_cracker', 'manors_bounty:graham_cacker');

    event.add('fabric:marshmallow_stick', 'list:marshmallow_stick'); 
    event.add('fabric:marshmallow_stick', 'hearthandharvest:marshmallow_stick'); 
    event.add('fabric:marshmallow_stick', 'manors_bounty:marshmallow_skewer'); 
    event.add('fabric:marshmallow_stick', 'delightful:marshmallow_stick'); 
    event.add('fabric:marshmallow_stick', 'create_confectionery:marshmallow_on_a_stick'); 
    
    event.add('fabric:toasted_marshmallow_with_stick', 'create_confectionery:caramelized_marshmellow_on_a_stick'); 
    event.add('fabric:toasted_marshmallow_with_stick', 'list:toasted_marshmallow_with_stick'); 
    event.add('fabric:toasted_marshmallow_with_stick', 'manors_bounty:campfire_marshmallow'); 
    event.add('fabric:toasted_marshmallow_with_stick', 'delightful:cooked_marshmallow_stick'); 

    event.add('fabric:sausage', 'list:sausage'); 
    event.add('fabric:sausage', 'manors_bounty:sausage');

    event.add('fabric:green_chili', 'kaleidoscope_cookery:green_chili'); 
    event.add('fabric:green_chili', 'ltc2:pepper_green'); 

    event.add('fabric:lettuce', 'kaleidoscope_cookery:lettuce'); 
    event.add('fabric:lettuce', 'farm_and_charm:lettuce'); 

    event.add('fabric:rice_panicle', 'farmersdelight:rice_panicle'); 
    event.add('fabric:rice_panicle', 'kaleidoscope_cookery:rice_panicle'); 

    event.add('fabric:rice', 'kaleidoscope_cookery:rice'); 
    event.add('fabric:rice', 'farmersdelight:rice'); 

    event.add('fabric:lettuce_seeds', 'kaleidoscope_cookery:lettuce_seed'); 
    event.add('fabric:lettuce_seeds', 'farm_and_charm:lettuce_seeds'); 

    event.add('fabric:chili_seed', 'kaleidoscope_cookery:chili_seed'); 
    event.add('fabric:chili_seed', 'muffins_thaidelight:pepper_seeds'); 

    event.add('fabric:raw_fries', 'create_bic_bit:raw_fries'); 
    event.add('fabric:raw_fries', 'moderndelight:potato_chips');

    event.add('fabric:potato_slice', 'list:fried_potato_slice'); 
    event.add('fabric:potato_slice', 'moderndelight:potato_chip');

    event.add('fabric:raw_squid_tentacle', 'moderndelight:raw_squid_tentacle_kebabs'); 
    event.add('fabric:raw_squid_tentacle', 'oceansdelight:tentacle_on_a_stick');

    event.add('fabric:cooked_squid_tentacle', 'oceansdelight:baked_tentacle_on_a_stick'); 
    event.add('fabric:cooked_squid_tentacle', 'moderndelight:squid_tentacle_kebabs'); 

    event.add('fabric:mantou', 'youkaishomecoming:mantou'); 
    event.add('fabric:mantou', 'kaleidoscope_cookery:mantou');
    event.add('fabric:mantou', 'moderndelight:steamed_bun');
    
    event.add('fabric:black_pepper_corn', 'moderndelight:black_pepper_corn'); 
    event.add('fabric:black_pepper_corn', 'ltc2:pepper_black'); 

    //event.add('fabric:black_pepper_dust', 'moderndelight:black_pepper_dust'); 
    //event.add('fabric:black_pepper_dust', 'ltc2:pepper_black_powder'); 
});

/* 
    event.add(, );

    event.add('fabric:', ); 
    event.add('fabric:', ); 

    event.add('neoforge:', );
    event.add('neoforge:', '');

    event.add('neoforge:', ''); 
    event.add('fabric:', ''); 
    event.add('forge:','');
    event.add('quilt:','')
    event.add('liteloader:', '');
    event.add('optfine:','')
*/