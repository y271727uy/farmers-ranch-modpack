ServerEvents.tags('block', event => {
    //春季
    const SereneSeasons_spring = [
        'mynethersdelight:powder_cannon',
        'fruitsdelight:lemon_seeds',
        'farmersrespite:small_tea_bush',
        'finallyfarmabledyes:black',
        'createcafe:cassava_crop',
        'collectorsreap:lime_bush', 'manors_bounty:pear_seed', 'manors_bounty:peach_seed',
        'endersdelight:ethereal_saffron_bush', 'endersdelight:chorus_flame_block', 'ramadandelight:parsley_crop', 'youkaishomecoming:mandrake', 'netherdepthsupgrade:crimson_kelp', 'netherdepthsupgrade:warped_kelp', 'avaritia_delight:budding_blaze_tomato', 'avaritia_delight:crystal_cabbage', 'minecraft:kelp', 'endersdelight:voidpepper_block',
        'veggiesdelight:broccoli_crop', 'miners_delight:cave_carrots', 'dumplings_delight:greenonion', 'dumplings_delight:garlic_chive', 'braziliandelight:collard_greens_seeds',
        'frightsdelight:wither_berry_bush', 'mynethersdelight:bullet_pepper', 'frightsdelight:soul_berry_bush', 'delighto_flight:cloud_berry_bush', 'avaritia_delight:diamond_lattice_potato', 'avaritia_delight:neutronium_wheat', 'bountifulfares:hoary_apple_sapling',
        'finallyfarmabledyes:yellow', 
        'vintagedelight:ghost_pepper_crop', 'rusticdelight:cotton', 'ubesdelight:lemongrass_stalk_crop', 'dumplings_delight:fennel', 'vintagedelight:cucumber_crop', 'muffins_thaidelight:pepper', 'spanishdelight:green_bean_crop', 'finallyfarmabledyes:azure_bluet', 'finallyfarmabledyes:magenta', 'finallyfarmabledyes:light_blue', 'finallyfarmabledyes:pink', 'finallyfarmabledyes:light_gray', 'finallyfarmabledyes:blue', 'finallyfarmabledyes:red', 'finallyfarmabledyes:red_tulip', 'finallyfarmabledyes:oxeye_daisy', 'finallyfarmabledyes:orange', 'finallyfarmabledyes:white',
        'collectorsreap:damselflower_crop', 
        'collectorsreap:moontear_crop', 
        'collectorsreap:skull_lily_crop', 
        'collectorsreap:bulbous_rose_crop',
        'collectorsreap:heartpetals_crop',
        'vietnam_delight:garlic_chives_crop',
        'vietnam_delight:shallot_crop',
        'immortalers_delight:travastruggler_sapling',
        'manors_bounty:cashew_tree_sapling',
        'manors_bounty:cinnise_tree_sapling',

    ];

    SereneSeasons_spring.forEach(block => {
        event.add('sereneseasons:spring_crops', block);
    });

    //夏季
    const SereneSeasons_summer = [
        'fruitsdelight:orange_sapling',
        'mynethersdelight:powder_cannon',
        'farmersrespite:small_tea_bush',
        'fruitsdelight:apple_sapling',
        'manors_bounty:apple_seed',
        'argentinas_delight:pimpolloyerba',
        'braziliandelight:yerba_mate_bush',
        'immortalers_delight:leisamboo_crop',
        'finallyfarmabledyes:black',
        'legendarysurvivaloverhaul:sun_fern_seeds',
        'createcafe:cassava_crop',
        'rusticdelight:bell_peppers', 'dumplings_delight:chinese_cabbages', 'culturaldelights:eggplants',
        'hearthandharvest:raspberry_bush', 'manors_bounty:coconut_sprout', 'minecraft:rose_bush', 'muffins_thaidelight:papaya_crop', 'muffins_thaidelight:papaya_sapling', 'manors_bounty:banana_frond_sapling', 'neapolitan:small_banana_frond', 'braziliandelight:coconut_palm_sapling', 'vinery:taiga_grape_bush_white', 'vinery:taiga_grape_bush_red', 'manors_bounty:starfruit_seed', 'vinery:savanna_grape_bush_white', 'vinery:savanna_grape_bush_red', 'delightful:salmonberry_bush', 'nethers_exoticism:kiwano_sapling', 'vinery:jungle_grape_bush_white', 'vinery:jungle_grape_bush_red', 'nethers_exoticism:ramboutan_sapling', 'fruitfulfun:pomelo_sapling', 'nethervinery:warped_grape_bush', 'legendarysurvivaloverhaul:water_plant_crop', 'vinery:white_grape_bush', 'manors_bounty:yuzumelo_seed', 'collectorsreap:budding_pink_dragon_fruits', 'manors_bounty:dragon_fruit_cactus', 'nethers_exoticism:pitaya_sapling', 'nethers_exoticism:bouddha_s_hand_sapling', 'coffee_delight:coffee_bush', 'bountifulfares:spongekin_stem', 'bountifulfares:tea_shrub',
        'culturaldelights:avocado_sapling', 'manors_bounty:apricot_seed', 'nethers_exoticism:jaboticaba_sapling', 'trailandtales_delight:budding_lantern_fruit', 'manors_bounty:mango_seed', 'ramadandelight:palm_sapling', 'immortalers_delight:pearlipearl_stalk', 'bountifulfares:plum_sapling', 'vinery:red_grape_bush', 'immortalers_delight:himekaido_shrub', 'manors_bounty:durian_seed', 'fruitsdelight:durian_sapling', 'vinery:dark_cherry_sapling', 'nethervinery:crimson_grape_bush', 'manors_bounty:cherries_seed', 'manors_bounty:avocado_seed',
        'endersdelight:ethereal_saffron_bush', 'endersdelight:chorus_flame_block', 'ramadandelight:parsley_crop', 'youkaishomecoming:mandrake', 'netherdepthsupgrade:crimson_kelp', 'netherdepthsupgrade:warped_kelp', 'avaritia_delight:budding_blaze_tomato', 'avaritia_delight:crystal_cabbage', 'minecraft:kelp', 'endersdelight:voidpepper_block',
        'yeastnfeast:mint_crop', 'neapolitan:mint', 'peruviansdelight:ajies_amarillos', 'veggiesdelight:zucchini_crop', 'alcocraftplus:hop', 'farmersdelight:budding_tomatoes', 'youkaishomecoming:udumbara',
        'collectorsreap:pomegranate_bush', 'braziliandelight:guarana_seeds', 'immortalers_delight:alfalfa', 'immortalers_delight:kwat_wheat', 'yeastnfeast:barley_crop', 'yeastnfeast:rye_crop', 'immortalers_delight:evolutcorn',
        'frightsdelight:wither_berry_bush', 'mynethersdelight:bullet_pepper', 
        'oddsnends:flax_crop',
        'oddsnends:laco_crop',
        'collectorsreap:lucuma_sapling',
        'oddsnends:ciderine_sapling',
        'oddsnends:anthesi_crop',
        'frightsdelight:soul_berry_bush', 'delighto_flight:cloud_berry_bush', 'avaritia_delight:diamond_lattice_potato', 'avaritia_delight:neutronium_wheat', 'bountifulfares:hoary_apple_sapling',
        'finallyfarmabledyes:yellow', 'vintagedelight:ghost_pepper_crop', 'rusticdelight:cotton', 'ubesdelight:lemongrass_stalk_crop', 
        'dumplings_delight:fennel', 'vintagedelight:cucumber_crop', 'muffins_thaidelight:pepper', 'spanishdelight:green_bean_crop', 
        'finallyfarmabledyes:azure_bluet', 'finallyfarmabledyes:magenta', 'finallyfarmabledyes:light_blue', 'finallyfarmabledyes:pink', 
        'finallyfarmabledyes:light_gray', 'finallyfarmabledyes:blue', 'finallyfarmabledyes:red', 'finallyfarmabledyes:red_tulip', 'finallyfarmabledyes:oxeye_daisy', 
        'finallyfarmabledyes:orange', 
        'finallyfarmabledyes:white',
        'vietnam_delight:garlic_chives_crop',
        'vietnam_delight:mung_beans_crop',
        'vietnam_delight:basil_crop',
        'vietnam_delight:lotot_crop',
        'vietnam_delight:pandan_crop',
        'farm_and_charm:lettuce_crop',
        'immortalers_delight:travastruggler_sapling',
        'manors_bounty:myriclave_tree_sapling',

    ];

    SereneSeasons_summer.forEach(block => {
        event.add('sereneseasons:summer_crops', block);
    });

    //秋季
    const SereneSeasons_autumn = [
        'mynethersdelight:powder_cannon',
        'minecraft:pitcher_pod',
        'farmersrespite:small_tea_bush',
        'argentinas_delight:brotemembrillo',
        'yeastnfeast:ginger_crop',
        'minecraft:beetroots',
        'festive_delight:cinnamon_bush',
        'youkaishomecoming:soybean',
        'neapolitan:vanilla_vine',
        'finallyfarmabledyes:black',
        'vintagedelight:oat_crop',
        'manors_bounty:apple_seed',
        'yeastnfeast:maple_sapling',
        'rusticdelight:bell_peppers', 'dumplings_delight:chinese_cabbages', 'culturaldelights:eggplants',
        'oddsnends:flax_crop',
        'veggiesdelight:broccoli_crop', 'miners_delight:cave_carrots', 'dumplings_delight:greenonion', 'dumplings_delight:garlic_chive', 'braziliandelight:collard_greens_seeds',
        'collectorsreap:pomegranate_bush', 'braziliandelight:guarana_seeds', 'immortalers_delight:alfalfa', 'immortalers_delight:kwat_wheat', 'yeastnfeast:barley_crop', 'yeastnfeast:rye_crop', 'immortalers_delight:evolutcorn',
        'frightsdelight:wither_berry_bush', 'mynethersdelight:bullet_pepper', 'frightsdelight:soul_berry_bush', 'delighto_flight:cloud_berry_bush', 'avaritia_delight:diamond_lattice_potato', 'avaritia_delight:neutronium_wheat', 'bountifulfares:hoary_apple_sapling',
        'endersdelight:ethereal_saffron_bush', 'endersdelight:chorus_flame_block', 'ramadandelight:parsley_crop', 'youkaishomecoming:mandrake', 
        'netherdepthsupgrade:crimson_kelp', 'netherdepthsupgrade:warped_kelp', 'avaritia_delight:budding_blaze_tomato', 'avaritia_delight:crystal_cabbage', 
        'minecraft:kelp', 
        'endersdelight:voidpepper_block',
        'vietnam_delight:garlic_chives_crop',
        'vietnam_delight:chilis_crop',
        'vietnam_delight:lotot_crop',
        'vietnam_delight:turmeric_crop',
        'vietnam_delight:shallot_crop',
        'farm_and_charm:lettuce_crop',
        'immortalers_delight:travastruggler_sapling',
        'manors_bounty:chestnut_tree_sapling',
        'manors_bounty:hazelnut_tree_sapling','manors_bounty:almond_tree_sapling','manors_bounty:walpecan_tree_sapling','manors_bounty:pistachio_tree_sapling',
        'manors_bounty:cinnise_tree_sapling',


    ];

    SereneSeasons_autumn.forEach(block => {
        event.add('sereneseasons:autumn_crops', block);
    });

    //冬季
    const SereneSeasons_winter = [
        'mynethersdelight:powder_cannon',
        'finallyfarmabledyes:black',
        'vintagedelight:oat_crop',
        'legendarysurvivaloverhaul:ice_fern_seeds',
        'frightsdelight:wither_berry_bush', 
        'mynethersdelight:bullet_pepper', 
        'frightsdelight:soul_berry_bush', 
        'delighto_flight:cloud_berry_bush', 
        'avaritia_delight:diamond_lattice_potato', 
        'avaritia_delight:neutronium_wheat', 
        'bountifulfares:hoary_apple_sapling',
        'endersdelight:ethereal_saffron_bush', 
        'endersdelight:chorus_flame_block', 
        'ramadandelight:parsley_crop', 
        'youkaishomecoming:mandrake', 
        'netherdepthsupgrade:crimson_kelp', 
        'netherdepthsupgrade:warped_kelp', 
        'avaritia_delight:budding_blaze_tomato', 
        'avaritia_delight:crystal_cabbage', 
        'minecraft:kelp', 
        'endersdelight:voidpepper_block',
        'manors_bounty:kiwifruit_seed',
        'manors_bounty:hawthorn_seed',
        'vietnam_delight:kumquat_crop',
        'farm_and_charm:lettuce_crop',
        'immortalers_delight:gelpitaya_crop',
        'manors_bounty:holly_tree_sapling',
        'manors_bounty:scots_pine_sapling',
        'manors_bounty:myriclave_tree_sapling',


    ];

    SereneSeasons_winter.forEach(block => {
        event.add('sereneseasons:winter_crops', block);
    });

});