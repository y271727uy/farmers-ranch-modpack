ServerEvents.recipes(event => {
event.custom({
  "type": "forestry:fermenter",
  "fermentationValue": 1000,
  "fluidResource": {
    "Amount": 1,
    "FluidName": "minecraft:water"
  },
  "modifier": 2.0,
  "output": "forestry:biomass",
  "resource": {
    "item": 'createaddition:biomass'
  }
});

event.custom({
  "type": "forestry:fermenter",
  "fermentationValue": 1000,
  "fluidResource": {
    "Amount": 1,
    "FluidName": "minecraft:water"
  },
  "modifier": 1.0,
  "output": "forestry:biomass",
  "resource": {
    "item": 'vintagedelight:organic_mash'
  }
});

event.custom({
  "type": "forestry:squeezer",
  "chance": 0.1,
  "output": {
    "Amount": 200,
    "FluidName": "forestry:juice"
  },
  "remnant": {
    "Count": 1,
    "id": "forestry:mulch"
  },
  "resources": [
    {
      "tag": "modpack:fruit_singularity"
    }
  ],
  "time": 10
});


});
