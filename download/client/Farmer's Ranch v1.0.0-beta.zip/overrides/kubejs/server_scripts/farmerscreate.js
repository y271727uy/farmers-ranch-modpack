ServerEvents.recipes(event => {

    event.recipes.create.cutting(
        [
            Item.of('culturaldelights:cut_avocado', 2),
            Item.of('manors_bounty:avocado_seed', 1)
        ],
       'culturaldelights:avocado'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:avocado_slice', 2)
        ],
       'culturaldelights:cut_avocado'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:banana_slice', 3)
        ],
       'neapolitan:banana'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:pear_slice', 2),
            Item.of('manors_bounty:pear_seed', 1)
        ],
       'fruitsdelight:pear'
    )

    event.recipes.create.cutting(
        [
            Item.of('culturaldelights:cut_cucumber', 2)
        ],
       'vintagedelight:cucumber'
    )

    event.recipes.create.cutting(
        [
            Item.of('peruviansdelight:camote_cortado', 2)
        ],
       'veggiesdelight:sweet_potato'
    )

    event.recipes.create.cutting(
        [
            Item.of('delightful:cantaloupe', 4)
        ],
       'delightful:cantaloupe_slice'
    )

    event.recipes.create.cutting(
        [
            Item.of('culturaldelights:cut_eggplant', 2)
        ],
       'culturaldelights:eggplant'
    )

    event.recipes.create.cutting(
        [
            Item.of('bountifulfares:spongekin_slice', 9)
        ],
       'bountifulfares:spongekin'
    )

    event.recipes.create.cutting(
        [
            Item.of('muffins_thaidelight:papaya_slice', 2)
        ],
       'muffins_thaidelight:papaya'
    )

    event.recipes.create.cutting(
        [
            Item.of('some_assembly_required:tomato_slices', 2)
        ],
       'argentinas_delight:tomatitos_cherry'
    )

    event.recipes.create.cutting(
        [
            Item.of('some_assembly_required:tomato_slices', 2)
        ],
       'farmersdelight:tomato'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:tomato_slice', 2)
        ],
       'manors_bounty:tomato'
    )

    event.recipes.create.cutting(
        [
            Item.of('veggiesdelight:zucchini_slice', 2)
        ],
       'veggiesdelight:zucchini'
    )

    event.recipes.create.cutting(
        [
            Item.of('peruviansdelight:yuca_cortada', 2)
        ],
       'braziliandelight:cassava_root'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:half_of_kiwifruit', 2)
        ],
       'fruitsdelight:kiwi'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:kiwifruit_slice', 2)
        ],
       'manors_bounty:half_of_kiwifruit'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:half_of_gold_kiwifruit', 2)
        ],
       'manors_bounty:gold_kiwifruit'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:gold_kiwifruit_slice', 2)
        ],
       'manors_bounty:half_of_gold_kiwifruit'
    )

    event.recipes.create.cutting(
        [
            Item.of('farmersdelight:pumpkin_slice', 9)
        ],
       'minecraft:pumpkin'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:golden_pumpkin_slice', 9)
        ],
       'manors_bounty:golden_pumpkin'
    )

    event.recipes.create.cutting(
        [
            Item.of('unusual_delight:shroomlight_slice', 9)
        ],
       'minecraft:shroomlight'
    )

    event.recipes.create.cutting(
        [
            Item.of('fruitsdelight:hamimelon_slice', 9)
        ],
       'fruitsdelight:hamimelon'
    )

    event.recipes.create.cutting(
        [
            Item.of('minecraft:melon_slice', 9)
        ],
       'minecraft:melon'
    )

    event.recipes.create.cutting(
        [
            Item.of('minecraft:melon_slice', 2)
        ],
       'delightful:mini_melon'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:peach_slice', 2),
            Item.of('manors_bounty:peach_seed', 1)
        ],
       'fruitsdelight:peach'
    )

    event.recipes.create.cutting(
        [
            Item.of('fruitsdelight:durian_flesh', 6),
            Item.of('fruitsdelight:durian_helmet', 1),
            Item.of('fruitsdelight:durian_shell', 1),
            Item.of('fruitsdelight:durian_sapling', 1)
        ],
       'fruitsdelight:durian'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:starfruit_slice', 2),
            Item.of('manors_bounty:starfruit_seed', 1)
        ],
       'manors_bounty:starfruit'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:half_of_musang_king_durian', 2)
        ],
       'manors_bounty:musang_king_durian'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:musang_king_durian_flesh', 2)
        ],
       'manors_bounty:half_of_musang_king_durian'
    )

    event.recipes.create.cutting(
        [
            Item.of('braziliandelight:coconut_slice', 1)
        ],
       'braziliandelight:coconut'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:jalapeno_slice', 3)
        ],
       'manors_bounty:jalapeno'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:wild_jalapeno_slice', 3)
        ],
       'manors_bounty:wild_jalapeno'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:end_pepper_slice', 3)
        ],
       'manors_bounty:end_pepper'
    )
/*
    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:dragon_fruit_slice', 2),
            Item.of('collectorsreap:dragon_fruit_seeds', 1)
        ],
       'collectorsreap:pink_dragon_fruit'
    )
*/
    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:fig_slice', 2),
            Item.of('manors_bounty:fig_seed', 1)
        ],
       'fruitsdelight:fig'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:grapefruit_slice', 2)
        ],
       'manors_bounty:grapefruit'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:yuzumelo_wedge', 3)
        ],
       'manors_bounty:yuzumelo'
    )

    event.recipes.create.cutting(
        [
            Item.of('collectorsreap:lime_slice', 2)
        ],
       'collectorsreap:lime'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:plum_slice', 2)
        ],
       'bountifulfares:plum'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:hawthorn_flakes', 2)
        ],
       'fruitsdelight:hawberry'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:mango_slice', 2),
            Item.of('manors_bounty:mango_seed', 1)
        ],
       'fruitsdelight:mango'
    )

    event.recipes.create.cutting(
        [
            Item.of('manors_bounty:green_apple_slice', 2)
        ],
       'manors_bounty:green_apple'
    )

    event.recipes.create.cutting(
        [
            Item.of('oceanic_delight:sea_pickle_slices', 2)
        ],
       'minecraft:sea_pickle'
    )

    event.recipes.create.cutting(
        [
            Item.of('extravagantdelight:green_mango_slice', 2)
        ],
       'extravagantdelight:green_mango'
    )

    event.recipes.create.cutting(
        [
            Item.of('extravagantdelight:lush_mango_slice', 2)
        ],
       'extravagantdelight:lush_mango'
    )

    event.recipes.create.cutting(
        [
            Item.of('nethers_exoticism:sliced_kiwano', 2)
        ],
       'nethers_exoticism:kiwano'
    )

    event.recipes.create.cutting(
        [
            Item.of('nethers_exoticism:chopped_bouddha_s_hand', 2)
        ],
       'nethers_exoticism:bouddha_s_hand'
    )

    event.recipes.create.cutting(
        [
            Item.of('peruviansdelight:raw_heart_slices', 3)
        ],
       'peruviansdelight:beef_heart'
    )

    event.recipes.create.cutting(
        [
            Item.of('untameddelight:sliced_bear', 2)
        ],
       'alexsmobsdelight:raw_bear_meat'
    )

    

});

/*
event.recipes.create.cutting(
        [
            Item.of(, 2),
            Item.of(, 1)
        ],
       
    )

event.recipes.create.cutting(
        [
            Item.of(, 2)
        ],
       
    )
*/