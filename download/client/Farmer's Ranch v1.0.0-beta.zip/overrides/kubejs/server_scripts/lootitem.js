LootJS.modifiers((event) => {

    event
        .addEntityLootModifier('unusualfishmod:kalappa') 
        .addLoot('collectorsreap:portobello')

    event
        .addEntityLootModifier('minecraft:camel') 
        .addLoot('untameddelight:camel_meat')
/*
    event
        .addEntityLootModifier('naturalist:bear') 
        .addLoot('untamedwilds:food_bear_raw')
*/
    event
        .addEntityLootModifier("wildernature:boar") 
        .replaceLoot("minecraft:porkchop", "untameddelight:boar_chop");

    event
        .addEntityLootModifier('untamedwilds:big_cat') 
        .addLoot('untamedwilds:food_pachyderm_raw')

    event
        .addEntityLootModifier('untamedwilds:hippo') 
        .addLoot('untamedwilds:food_pachyderm_raw')

    event
        .addEntityLootModifier('untamedwilds:hyena') 
        .addLoot('untamedwilds:food_pachyderm_raw')

    event
        .addEntityLootModifier('untamedwilds:wildebeest') 
        .addLoot('untamedwilds:food_pachyderm_raw')
/*
    event
        .addEntityLootModifier('naturalist:vulture') 
        .addLoot('naturalist:bushmeat')

    event
        .addEntityLootModifier('naturalist:lion') 
        .addLoot('naturalist:bushmeat')

    event
        .addEntityLootModifier('naturalist:zebra') 
        .addLoot('naturalist:bushmeat')

    event
        .addEntityLootModifier('naturalist:hippo') 
        .addLoot('naturalist:bushmeat')

*/
    
});


/*
event
        .addEntityLootModifier() 
        .addLoot()
*/


