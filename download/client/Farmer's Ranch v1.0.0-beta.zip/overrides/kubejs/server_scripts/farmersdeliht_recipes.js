ServerEvents.recipes(event => {
//晶格马铃薯汉堡
event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "item": "list:neutronium_butter"
    },
    {
      "tag": "forge:eggs"
    },
    {
      "item": "avaritia_delight:infinity_milk"
    },
    {
      "item": "avaritia_delight:diamond_lattice_potato"
    },
    {
      "item": "avaritia_delight:diamond_lattice_potato"
    },
    {
      "item": "avaritia_delight:diamond_lattice_potato"
    }
  ],
  "output": {
    "count": 1,
    "item": "list:diamond_lattice_potato_burger"
  },
  "temperature": 250
});

event.custom({
  "type": "manors_bounty_machine:oven",
  "cookingTime": 300,
  "input": [
    {
      "item": "list:neutronium_butter"
    },
    {
      "item": "avaritia:neutron_nugget"
    },
    {
      "item": "avaritia_delight:infinity_milk"
    },
    {
      "item": "list:neutronium_butter"
    },
    {
      "item": "avaritia_delight:neutronium_wheat_dough"
    },
    {
      "item": "avaritia_delight:neutronium_wheat_dough"
    }
  ],
  "output": {
    "count": 1,
    "item": "list:neutronium_burger"
  },
  "temperature": 250
});


event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:black_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:black_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:black_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});


event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:barley_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:barley_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:barley_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item:'list:cassava_burger' }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:cassava_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:cassava_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:corn_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:corn_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:corn_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:evolutcorn_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:evolutcorn_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:evolutcorn_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:kwat_wheat_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:kwat_wheat_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:kwat_wheat_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:black_oak_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:black_oak_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:black_oak_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:oak_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:oak_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:oak_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:sweet_potato_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:sweet_potato_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:sweet_potato_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:pumpkin_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:pumpkin_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:pumpkin_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:nut_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:nut_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:nut_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:ghast_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:ghast_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:ghast_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:banana_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:banana_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:banana_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:potato_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:potato_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:potato_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:diamond_lattice_potato_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:diamond_lattice_potato_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:diamond_lattice_potato_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'list:neutronium_burger'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'list:neutronium_burger_bottom',  
          count: 1,
          chance: 1.0
        },
        {
          item: 'list:neutronium_burger_top',  
          count: 1,
          chance: 1.0
        }
      ]
});

event.shaped(
  Item.of('list:rye_dough', 2), 
  [
    'AAB',
    'BCD',
    '   '
  ],
  {
    A: 'yeastnfeast:rye',
    B: Ingredient.of('#fabric:yeast', 1), 
    C: 'minecraft:water_bucket',
    D: 'create:wheat_flour'
  }
)

event.shaped(
  Item.of('list:barley_dough', 2), 
  [
    'AAB',
    'BCD',
    '   '
  ],
  {
    A: 'yeastnfeast:barley',
    B: Ingredient.of('#fabric:yeast', 1), 
    C: 'minecraft:water_bucket',
    D: 'create:wheat_flour'
  }
)

event.shaped(
      Item.of('unusualfoodsdelight:sugarcane_juice', 1),  
      [
        'AAA',
        'AAA',
        ' B '
      ],
      {
        A: 'manors_bounty:purple_sugar_cane',
        B: 'minecraft:glass_bottle' 
      }
    )

    
/*
event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: 'manors_bounty:hawaiian_pizza'}   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: 'manors_bounty:hawaiian_pizza_slice',  
          count: 4,
          chance: 1.0
        }
      ]
    });
    
event.custom({
      type: 'farmersdelight:cutting',
      ingredients: [
        { item: }   
      ],
      tool: {
        tag: 'forge:tools/knives'  
      },
      result: [
        {
          item: _bottom,  
          count: 1,
          chance: 1.0
        },
        {
          item: _top,  
          count: 1,
          chance: 1.0
        }
      ]
});
*/
});