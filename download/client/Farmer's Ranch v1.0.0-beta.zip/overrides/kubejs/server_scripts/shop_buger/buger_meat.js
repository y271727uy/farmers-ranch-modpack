// 注册汉堡材料
//非常非常感谢空岛汉堡店原作者：流浪者Xx
//也非常感谢一路上给予各种帮助的朋友：DancingSnow、、Neo-Tix、小苏打、小弥等内测群的杂鱼

/*
注册新材料环节 具体介绍：
最前面的数字（1001001）代表材料编号，相同编号的材料会互相覆盖
个人建议前四位（1001）保持一致，后三位（001）次序递增，以减少撞车的几率
id：物品的id，游戏内用f3+h可以查看
type：材料的类型，0是面包，1是肉类，2是蔬菜，3是酱料，4是其他
price：单价
extraprice：附加价
favor：订单*继续*概率，游戏内显示的订单结束概率是1-favor
chapter：材料所属的章节，与声望加值相关
bottom：仅对汉堡面包顶有意义，即这个汉堡面包顶所对应的面包底的编号；汉堡面包底的bottom应为-1
*/
const BugerMeatFoodIngredients = {
    //金枪鱼大腹
    1001001: {
        id: "youkaishomecoming:otoro",
        type: 1, // 肉类
        price: 6,
        extraprice: 0.8,
        favor: 0.1, 
        chapter: 1 
    },
    "youkaishomecoming:otoro": 1001001,

    //炙烤金枪鱼排
    1001002: {
        id: "youkaishomecoming:seared_tuna",
        type: 1, // 肉类
        price: 6,
        extraprice: 0.8,
        favor: 0.1, 
        chapter: 1 
    },
    "youkaishomecoming:seared_tuna": 1001002,

    // 烤鸭胸肉
    1001003: {
        id: "manors_bounty:cooked_duck_breast",
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1, 
        chapter: 1 
    },
    "manors_bounty:cooked_duck_breast": 1001003,

    // 烤鸡胸肉
    1001004: {
        id: "manors_bounty:cooked_chicken_breast",
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "manors_bounty:cooked_chicken_breast": 1001004,

    // 熟午餐肉片
    1001005: {
        id: "manors_bounty:cooked_spam_slice",
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "manors_bounty:cooked_spam_slice": 1001005,

    // 熟薄荷肉排
    1001006: {
        id: "neapolitan:cooked_mint_chops",
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "neapolitan:cooked_mint_chops": 1001006,

    // 熟野牛排
    1001007: {
        id: "wildernature:cooked_bison_meat",
        type: 1, // 肉类
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "wildernature:cooked_bison_meat": 1001007,

    // 熟厚皮动物肉
    1001008: {
        id: "untamedwilds:food_pachyderm_cooked",
        type: 1, // 肉类
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "untamedwilds:food_pachyderm_cooked": 1001008,

    // 熟熊肉
    1001009: {
        id: "untamedwilds:food_bear_cooked",
        type: 1, // 肉类
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "untamedwilds:food_bear_cooked": 1001009,

    // 熟鳖肉
    1001010: {
        id: "untamedwilds:food_turtle_cooked",
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    "untamedwilds:food_turtle_cooked": 1001010,

    // 熟熊肉排
    1001011: {
        id: 'untameddelight:bear_steak',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'untameddelight:bear_steak': 1001011,

    //炸猪排
    1001012: {
        id: 'manors_bounty:fried_porkchop',
        type: 1, // 肉类
        price: 14,
        extraprice: 2,
        favor: 0.1,
        chapter: 5
    },
    'manors_bounty:fried_porkchop': 1001012,

    //炸牛排
    1001013: {
        id: 'manors_bounty:fried_steak',
        type: 1, // 肉类
        price: 14,
        extraprice: 2,
        favor: 0.1,
        chapter: 5
    },
    'manors_bounty:fried_steak': 1001013,

    //炸鲍鱼
    1001014: {
        id: 'manors_bounty:fried_abalone',
        type: 1, // 肉类
        price: 15,
        extraprice: 3,
        favor: 0.1,
        chapter: 5
    },
    'manors_bounty:fried_abalone': 1001014,

    //炸天妇罗
    1001015: {
        id: 'manors_bounty:fried_tempura',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 5
    },
    'manors_bounty:fried_tempura': 1001015,

    //海胆黄
    1001016: {
        id: 'collectorsreap:uni',
        type: 1, // 肉类
        price: 12,
        extraprice: 3,
        favor: 0.1,
        chapter: 5
    },
    'collectorsreap:uni': 1001016,

    1001017: {
        id: 'aquaculture:fish_fillet_cooked',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'aquaculture:fish_fillet_cooked': 1001017,

    1001018: {
        id: 'unusualfoodsdelight:bake_hoglin_rib',
        type: 1, // 肉类
        price: 10,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualfoodsdelight:bake_hoglin_rib': 1001018,

    1001019: {
        id: 'untameddelight:cooked_boar_chop',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'untameddelight:cooked_boar_chop': 1001019,

    1001020: {
        id: 'untameddelight:cooked_camel_meat',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'untameddelight:cooked_camel_meat': 1001020,

    1001021: {
        id: 'manors_bounty:cooked_beef_cubes',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:cooked_beef_cubes': 1001021,

    1001022: {
        id: 'unusualprehistory:cooked_mammoth',
        type: 1, // 肉类
        price: 24,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualprehistory:cooked_mammoth': 1001022,

    1001023: {
        id: 'unusualfishmod:cooked_lobster',
        type: 1, // 肉类
        price: 10,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualfishmod:cooked_lobster': 1001023,

    1001024: {
        id: 'wildernature:cooked_venison',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'wildernature:cooked_venison': 1001025,

    1001026: {
        id: 'youkaishomecoming:kabayaki',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'youkaishomecoming:kabayaki': 1001026,

    1001027: {
        id: 'cavedelight:honey_glazed_dino_nugget',
        type: 1, // 肉类
        price: 7,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'cavedelight:honey_glazed_dino_nugget': 1001027,

    1001028: {
        id: 'vegandelight:minced_tofu',
        type: 1, // 肉类
        price: 1,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vegandelight:minced_tofu': 1001028,

    1001029: {
        id: 'crabbersdelight:cooked_clam_meat',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'crabbersdelight:cooked_clam_meat': 1001029,

    1001030: {
        id: 'casualness_delight:cooked_donkey_meat',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'casualness_delight:cooked_donkey_meat': 1001030,

    1001031: {
        id: 'unusual_delight:cooked_zorkchop',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusual_delight:cooked_zorkchop': 1001031,

    1001032: {
        id: 'vegandelight:cooked_tofu_slices',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vegandelight:cooked_tofu_slices': 1001032,

    1001033: {
        id: 'vegandelight:tofu_patty',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vegandelight:tofu_patty': 1001033,

    1001034: {
        id: 'vegandelight:cooked_smoked_tofu_slices',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vegandelight:cooked_smoked_tofu_slices': 1001034,

    1001035: {
        id: 'vegandelight:tofu_slices',
        type: 1, // 肉类
        price: 1,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vegandelight:tofu_slices': 1001035,

    1001036: {
        id: 'delightful:cactus_steak',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'delightful:cactus_steak': 1001036,

    1001037: {
        id: 'ends_delight:roasted_dragon_meat_cuts',
        type: 1, // 肉类
        price: 8,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'ends_delight:roasted_dragon_meat_cuts': 1001037,

    1001038: {
        id: 'brain_delight:meatpiececooked',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'brain_delight:meatpiececooked': 1001038,

    1001039: {
        id: 'unusualfoodsdelight:silverfish_meatball',
        type: 1, // 肉类
        price: 1,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualfoodsdelight:silverfish_meatball': 1001039,

    1001040: {
        id: 'youkaishomecoming:cooked_flesh_slice',
        type: 1, // 肉类
        price: 1,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'youkaishomecoming:cooked_flesh_slice': 1001040,

    1001041: {
        id: 'unusual_delight:cooked_mite_meat',
        type: 1, // 肉类
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusual_delight:cooked_mite_meat': 1001041,

    1001042: {
        id: 'ends_delight:roasted_dragon_meat',
        type: 1, // 肉类
        price: 24,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'ends_delight:roasted_dragon_meat': 1001042,

    1001043: {
        id: 'youkaishomecoming:cooked_flesh',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'youkaishomecoming:cooked_flesh': 1001043,

    1001044: {
        id: 'vegandelight:smoked_tofu_slices',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vegandelight:smoked_tofu_slices': 1001044,

    1001045: {
        id: 'dungeonsdelight:smoked_spider_meat',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'dungeonsdelight:smoked_spider_meat': 1001045,

    1001046: {
        id: 'peruviansdelight:chicharron_pota',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'peruviansdelight:chicharron_pota': 1001046,

    1001047: {
        id: 'peruviansdelight:chicharron',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'peruviansdelight:chicharron': 1001047,

    1001048: {
        id: 'luncheonmeatsdelight:fry_luncheon_meat',
        type: 1, // 肉类
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'luncheonmeatsdelight:fry_luncheon_meat': 1001048,

    1001049: {
        id: 'collectorsreap:chieftain_crab_meat',
        type: 1, // 肉类
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'collectorsreap:chieftain_crab_meat': 1001049,

    1001050: {
        id: 'cavedelight:cooked_trilocaris_slice',
        type: 1, // 肉类
        price: 7,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'cavedelight:cooked_trilocaris_slice': 1001050,

    1001051: {
        id: 'ends_delight:dried_endermite_meat',
        type: 1, // 肉类
        price: 6,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'ends_delight:dried_endermite_meat': 1001051,

    1001052: {
        id: 'dungeonsdelight:cooked_sniffer_shank',
        type: 1, // 肉类
        price: 11,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'dungeonsdelight:cooked_sniffer_shank': 1001052,

    1001053: {
        id: 'avaritia_delight:cosmic_beef_cooked',
        type: 1, // 肉类
        price: 44,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'avaritia_delight:cosmic_beef_cooked': 1001053,

    1001054: {
        id: 'brewinandchewin:kippers',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'brewinandchewin:kippers': 1001054,

    1001055: {
        id: 'brewinandchewin:jerky',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'brewinandchewin:jerky': 1001055,

    1001056: {
        id: 'vintagedelight:salted_cod',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vintagedelight:salted_cod': 1001056,

    1001057: {
        id: 'unusualfoodsdelight:salted_fish',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualfoodsdelight:salted_fish': 1001057,

    1001058: {
        id: 'unusual_delight:cooked_silver_cube',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusual_delight:cooked_silver_cube': 1001058,

    1001059: {
        id: 'vintagedelight:salted_salmon',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vintagedelight:salted_salmon': 1001059,

    1001060: {
        id: 'vintagedelight:surstromming',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'vintagedelight:surstromming': 1001060,

    1001061: {
        id: 'cavedelight:cooked_curious_insect',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'cavedelight:cooked_curious_insect': 1001061,

    1001062: {
        id: 'manors_bounty:shirako',
        type: 1, // 肉类
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:shirako': 1001062,

    1001063: {
        id: 'manors_bounty:tarako',
        type: 1, // 肉类
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:tarako': 1001063,

    1001064: {
        id: 'manors_bounty:mentaiko',
        type: 1, // 肉类
        price: 8,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:mentaiko': 1001064,

    1001065: {
        id: 'unusualfishmod:cooked_mossthorn',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualfishmod:cooked_mossthorn': 1001065,

    1001066: {
        id: 'oceansdelight:cooked_elder_guardian_slice',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'oceansdelight:cooked_elder_guardian_slice': 1001066,

    1001067: {
        id: 'unusual_delight:cooked_cut_flying_fish',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusual_delight:cooked_cut_flying_fish': 1001067,

    1001068: {
        id: 'argentinas_delight:chinchulinesitem',
        type: 1, // 肉类
        price: 6,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'argentinas_delight:chinchulinesitem': 1001068,

    1001069: {
        id: 'argentinas_delight:chorizoitem',
        type: 1, // 肉类
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'argentinas_delight:chorizoitem': 1001069,

    1001070: {
        id: 'unusual_delight:spectralegg',
        type: 10, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusual_delight:spectralegg': 1001070,

    1001071: {
        id: 'list:atlatitan_amlette',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:atlatitan_amlette': 1001071,

    1001072: {
        id: 'list:vallumraptor_amlette',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:vallumraptor_amlette': 1001072,

    1001073: {
        id: 'list:grottoceratops_amlette',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:grottoceratops_amlette': 1001073,

    1001074: {
        id: 'list:relicheirus_amlette',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:relicheirus_amlette': 1001074,

    1001075: {
        id: 'list:subterranodon_amlette',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:subterranodon_amlette': 1001075,

    1001076: {
        id: 'list:tremorsaurus_amlette',
        type: 1, // 肉类
        price: 15,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:tremorsaurus_amlette': 1001076,

    1001077: {
        id: 'trailandtales_delight:fried_sniffer_egg',
        type: 1, // 肉类
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'trailandtales_delight:fried_sniffer_egg': 1001077,

    1001078: {
        id: 'list:tremorzilla_amlette',
        type: 1, // 肉类
        price: 24,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:tremorzilla_amlette': 1001078,

    1001079: {
        id: 'ends_delight:fried_dragon_egg',
        type: 1, // 肉类
        price: 24,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'ends_delight:fried_dragon_egg': 1001079,

    1001080: {
        id: 'list:amlette_from_embryo',
        type: 1, // 肉类
        price: 30,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'list:amlette_from_embryo': 1001080,

    1001081: {
        id: 'avaritia_delight:endest_fried_egg',
        type: 1, // 肉类
        price: 44,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'avaritia_delight:endest_fried_egg': 1001081,

    1001082: {
        id: 'alexsmobsdelight:cooked_bear_meat',
        type: 1, // 肉类
        price: 16,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'alexsmobsdelight:cooked_bear_meat': 1001082,

    1001083: {
        id: 'alexsmobsdelight:cooked_bison_meat',
        type: 1, // 肉类
        price: 16,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'alexsmobsdelight:cooked_bison_meat': 1001083,

    1001084: {
        id: 'alexsmobsdelight:slice_of_smoked_tusklin_sausage',
        type: 1, // 肉类
        price: 16,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'alexsmobsdelight:slice_of_smoked_tusklin_sausage': 1001084,

    1001085: {
        id: 'alexsmobsdelight:fried_tusklin_meat',
        type: 1, // 肉类
        price: 16,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'alexsmobsdelight:fried_tusklin_meat': 1001085,

    1001086: {
            id: 'alexsmobsdelight:cooked_tusklin_meat',
            type: 1, // 肉类
            price: 16,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobsdelight:cooked_tusklin_meat': 1001086,

    1001087: {
            id: 'alexsmobsdelight:cooked_crocodile_meat',
            type: 1, // 肉类
            price: 16,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobsdelight:cooked_crocodile_meat': 1001087,

    1001088: {
            id: 'alexsmobs:cooked_kangaroo_meat',
            type: 1, // 肉类
            price: 16,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobs:cooked_kangaroo_meat': 1001088,

    1001089: {
            id: 'alexsmobsdelight:cooked_tusklin_meat_piece',
            type: 1, // 肉类
            price: 8,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobsdelight:cooked_tusklin_meat_piece': 1001089,

    1001091: {
            id: 'alexsmobsdelight:cooked_octopus_tentacle',
            type: 1, // 肉类
            price: 8,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobsdelight:cooked_octopus_tentacle': 1001091,

    1001092: {
            id: 'alexsmobsdelight:cooked_kangaroo_meat_slice',
            type: 1, // 肉类
            price: 8,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobsdelight:cooked_kangaroo_meat_slice': 1001092,

    1001093: {
            id: 'alexsmobsdelight:cooked_bear_meat_slice',
            type: 1, // 肉类
            price: 8,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    'alexsmobsdelight:cooked_bear_meat_slice': 1001093,
}

// 将新食材注册到全局食材列表
Object.assign(global.ingredients, BugerMeatFoodIngredients)

/*
//
    100109: {
            id: ,
            type: 1, // 肉类
            price: 8,
            extraprice: 0.8,
            favor: 0.1,
            chapter: 1
        },
    : 100109,
*/