/*
注册新额外商品环节 具体介绍：
编号：同上
id：同上
type：额外商品的类型，1是小吃，2是饮料
pricemod：价格乘数：比如1.5是+50%，0.5是-50%
repmod：声望乘数
*/
const SnackFood_newSnacks = {
    1005000:
    {
        id: 'manors_bounty:dried_apricot',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'manors_bounty:dried_apricot': 1005000,

    1005001:
    {
        id: 'manors_bounty:nata_de_coco',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'manors_bounty:nata_de_coco': 10015001,

    1005002:
    {
        id: 'manors_bounty:durian_crisp',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'manors_bounty:durian_crisp': 10015002,

    1005003:
    {
        id: 'fruitsdelight:durian_pie',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:durian_pie': 10015003,

    1005004:
    {
        id: 'fruitsdelight:baked_pear',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:baked_pear': 10015004,

    1005005:
    {
        id: 'manors_bounty:umeboshi',
        type: 1,
        pricemod: 2,
        repmod: 1
    },
    'manors_bounty:umeboshi': 10015005,

    1005006:
    {
        id: 'fruitsdelight:pineapple_pie',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:pineapple_pie': 10015006,

    1005007:
    {
        id: 'fruitsdelight:dried_persimmon',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:dried_persimmon': 10015007,

    1005008:
    {
        id: 'fruitsdelight:hawberry_stick',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:hawberry_stick': 10015008,

    1005009:
    {
        id: 'fruitsdelight:hawberry_sheet',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:hawberry_sheet': 10015009,

    1005010:
    {
        id: 'fruitsdelight:hawberry_roll',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'fruitsdelight:hawberry_roll': 1005010,

    1005011:
    {
        id: 'manors_bounty:dark_chocolate',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'manors_bounty:dark_chocolate': 1005011,

    1005012:
    {
        id: 'manors_bounty:white_chocolate',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'manors_bounty:white_chocolate': 1005012,

    1005013:
    {
        id: 'manors_bounty:chocolate',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'manors_bounty:chocolate': 1005013,

    1005014:
    {
        id: 'corn_delight:popcorn',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'corn_delight:popcorn': 1005014,

    1005015:
    {
        id: 'manors_bounty:karaage',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'manors_bounty:karaage': 1005015,

    1005016:
    {
        id: 'manors_bounty:cooked_duck_neck',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'manors_bounty:cooked_duck_neck': 1005016,

    1005017:
    {
        id: 'manors_bounty:cooked_chicken_neck',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'manors_bounty:cooked_chicken_neck': 1005017,

    1005018:
    {
        id: 'manors_bounty:cooked_chicken_foot',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'manors_bounty:cooked_chicken_foot': 1005018,

    1005019:
    {
        id: 'manors_bounty:cooked_duck_foot',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'manors_bounty:cooked_duck_foot': 1005019,

    1005020:
    {
        id: 'manors_bounty:cooked_duck_wing',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'manors_bounty:cooked_duck_wing': 1005020,

    1005021:
    {
        id: 'manors_bounty:cooked_chicken_wing',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'manors_bounty:cooked_chicken_wing': 1005021,

    1005022:
    {
        id: 'manors_bounty:cooked_duck_drumstick',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'manors_bounty:cooked_duck_drumstick': 1005022,

    1005023:
    {
        id: 'manors_bounty:cooked_chicken_drumstick',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'manors_bounty:cooked_chicken_drumstick': 1005023,

    1005024:
    {
        id: 'manors_bounty:fried_drumstick',
        type: 1,
        pricemod: 1.4,
        repmod: 1
    },
    'manors_bounty:fried_drumstick': 1005024,

    1005025:
    {
        id: 'casualness_delight:potato_bobo_chicken',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'casualness_delight:potato_bobo_chicken': 1005025,

    1005026:
    {
        id: 'casualness_delight:cabbage_bobo_chicken',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'casualness_delight:cabbage_bobo_chicken': 1005026,

    1005027:
    {
        id: 'casualness_delight:roast_gluten',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'casualness_delight:roast_gluten': 1005027,

    1005028:
    {
        id: 'casualness_delight:chicken_bobo_chicken',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'casualness_delight:chicken_bobo_chicken': 1005028,

    1005029:
    {
        id: 'casualness_delight:spicy_strips',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'casualness_delight:spicy_strips': 1005029,

    1005030:
    {
        id: 'manors_bounty:naan',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'manors_bounty:naan': 1005030,

    1005031:
    {
        id: 'manors_bounty:you_tiao',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'manors_bounty:you_tiao': 1005031,

    1005032:
    {
        id: 'manors_bounty:bun',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'manors_bounty:bun': 1005032,

    1005033:
    {
        id: 'youkaishomecoming:raisin',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'youkaishomecoming:raisin': 1005033,

    1005034:
    {
        id: 'unusual_delight:dried_berry',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'unusual_delight:dried_berry': 1005034,

    1005035:
    {
        id: 'unusual_delight:coated_berry',
        type: 1,
        pricemod: 1.1,
        repmod: 1
    },
    'unusual_delight:coated_berry': 1005035,

    1005036:
    {
        id: 'youkaishomecoming:nattou',
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    'youkaishomecoming:nattou': 1005036,

    1005037:
    {
        id: 'youkaishomecoming:onigili',
        type: 1,
        pricemod: 1.3,
        repmod: 1
    },
    'youkaishomecoming:onigili': 1005037,
}

Object.assign(global.snacks, SnackFood_newSnacks)

/*
100503:
    {
        id: ,
        type: 1,
        pricemod: 1.2,
        repmod: 1
    },
    : 100503,
*/