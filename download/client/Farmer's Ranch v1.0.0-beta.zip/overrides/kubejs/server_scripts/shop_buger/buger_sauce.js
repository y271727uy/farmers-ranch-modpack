//注册汉堡材料
//非常非常感谢空岛汉堡店原作者：流浪者Xx
//也非常感谢一路上给予各种帮助的朋友：DancingSnow、小苏打、小弥等内测群的朋友

/*
注册新材料环节 具体介绍：
最前面的数字（1001001）代表材料编号，相同编号的材料会互相覆盖
个人建议前四位（1001）保持一致，后三位（001）次序递增，以减少撞车的几率
id：物品的id，游戏内用f3+h可以查看
type：材料的类型，0是面包，1是肉类，2是蔬菜，3是酱料，4是其他
price：单价
extraprice：附加价
favor：订单*继续*概率，游戏内显示的订单结束概率是1-favor
chapter：材料所属的章节，与声望加值相关
bottom：仅对汉堡面包顶有意义，即这个汉堡面包顶所对应的面包底的编号；汉堡面包底的bottom应为-1
*/
const BugerSauceFoodIngredients = {
    //烈火番茄酱
    1003000: {
        id: "avaritia_delight:blaze_tomato_sauce",
        type: 3, //酱料
        price: 30,
        extraprice: 0.8,
        favor: 0.1, 
        chapter: 1 
    },
    "avaritia_delight:blaze_tomato_sauce": 1003000,
    }   
// 将新食材注册到全局食材列表
Object.assign(global.ingredients, BugerSauceFoodIngredients)

/*
//
    1002000: {
        id: ,
        type: 3, //酱料
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    : 100101,
*/