//注册汉堡材料
//非常非常感谢空岛汉堡店原作者：流浪者Xx
//也非常感谢一路上给予各种帮助的朋友：DancingSnow、小苏打、小弥等内测群的朋友

/*
注册新材料环节 具体介绍：
最前面的数字（1001001）代表材料编号，相同编号的材料会互相覆盖
个人建议前四位（1001）保持一致，后三位（001）次序递增，以减少撞车的几率
id：物品的id，游戏内用f3+h可以查看
type：材料的类型，0是面包，1是肉类，2是蔬菜，3是酱料，4是其他
price：单价
extraprice：附加价
favor：订单*继续*概率，游戏内显示的订单结束概率是1-favor
chapter：材料所属的章节，与声望加值相关
bottom：仅对汉堡面包顶有意义，即这个汉堡面包顶所对应的面包底的编号；汉堡面包底的bottom应为-1
*/
const BugerVegFoodIngredients = {
    //矩阵卷心菜叶
    1002000: {
        id: "avaritia_delight:crystal_cabbage_leaf",
        type: 2, //蔬菜
        price: 30,
        extraprice: 0.8,
        favor: 0.1, 
        chapter: 1 
    },
    "avaritia_delight:crystal_cabbage_leaf": 1001003,

    1002001: {
        id: 'fruitsdelight:baked_durian',
        type: 2, //蔬菜
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'fruitsdelight:baked_durian': 1002001,

    1002002: {
        id: 'manors_bounty:cooked_durian_flesh',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:cooked_durian_flesh': 1002002,

    1002003: {
        id: 'manors_bounty:fried_banana',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:fried_banana': 1002003,

    1002004: {
        id: 'brewinandchewin:kimchi',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'brewinandchewin:kimchi': 1002004,

    1002005: {
        id: 'foragersinsight:dandelion_root',
        type: 2, //蔬菜
        price: 1,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'foragersinsight:dandelion_root': 1002005,

    1002006: {
        id: 'veggiesdelight:dandelion_leaf',
        type: 2, //蔬菜
        price: 1,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'veggiesdelight:dandelion_leaf': 1002006,

    1002007: {
        id: 'braziliandelight:collard_greens',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'braziliandelight:collard_greens': 1002007,

    1002008: {
        id: 'argentinas_delight:espinacaitem',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'argentinas_delight:espinacaitem': 1002008,

    1002009: {
        id: 'neapolitan:mint_leaves',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'neapolitan:mint_leaves': 1002009,

    1002010: {
        id: 'extravagantdelight:rhubarb',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'extravagantdelight:rhubarb': 1002010,

    1002011: {
        id: 'brewinandchewin:pickled_pickles',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'brewinandchewin:pickled_pickles': 1002011,

    1002012: {
        id: 'unusualfoodsdelight:tomato_in_oil',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'unusualfoodsdelight:tomato_in_oil': 1002012,

    1002013: {
        id: 'manors_bounty:stuffed_olive',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:stuffed_olive': 1002013,

    1002014: {
        id: 'culturaldelights:smoked_white_eggplant',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'culturaldelights:smoked_white_eggplant': 1002014,

    1002015: {
        id: 'veggiesdelight:roasted_zucchini',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'veggiesdelight:roasted_zucchini': 1002015,

    1002016: {
        id: 'neapolitan:roasted_adzuki_beans',
        type: 2, //蔬菜
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'neapolitan:roasted_adzuki_beans': 1002016,

    1002017: {
        id: 'dumplings_delight:chinese_cabbage_leaf',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'dumplings_delight:chinese_cabbage_leaf': 1002017,

    1002018: {
        id: 'youkaishomecoming:cucumber_slice',
        type: 2, //蔬菜
        price: 2,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'youkaishomecoming:cucumber_slice': 1002018,

    1002019: {
        id: 'manors_bounty:avocado_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:avocado_slice': 1002019,

    1002020: {
        id: 'culturaldelights:cut_cucumber',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'culturaldelights:cut_cucumber': 1002020,

    1002021: {
        id: 'fruitsdelight:pineapple_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'fruitsdelight:pineapple_slice': 1002021,

    1002022: {
        id: 'some_assembly_required:chopped_carrot',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'some_assembly_required:chopped_carrot': 1002022,

    1002023: {
        id: 'some_assembly_required:chopped_beetroot',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'some_assembly_required:chopped_beetroot': 1002023,

    1002024: {
        id: 'manors_bounty:grapefruit_slice',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:grapefruit_slice': 1002024,

    1002025: {
        id: 'veggiesdelight:cauliflower_floret',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'veggiesdelight:cauliflower_floret': 1002025,

    1002026: {
        id: 'manors_bounty:tomato_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:tomato_slice': 1002026,

    1002027: {
        id: 'manors_bounty:kiwifruit_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:kiwifruit_slice': 1002027,

    1002028: {
        id: 'fruitsdelight:lemon_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'fruitsdelight:lemon_slice': 1002028,

    1002029: {
        id: 'collectorsreap:lime_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'collectorsreap:lime_slice': 1002029,

    1002030: {
        id: 'fungidelight:cooked_cleaned_cap',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'fungidelight:cooked_cleaned_cap': 1002030,

    1002031: {
        id: 'culturaldelights:smoked_cut_eggplant',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'culturaldelights:smoked_cut_eggplant': 1002031,

    1002032: {
        id: 'miners_delight:vegan_patty',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'miners_delight:vegan_patty': 1002032,

    1002033: {
        id: 'fungidelight:truffle_slice',
        type: 2, //蔬菜
        price: 6,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'fungidelight:truffle_slice': 1002033,

    1002034: {
        id: 'peruviansdelight:camote_frito',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'peruviansdelight:camote_frito': 1002034,

    1002035: {
        id: 'extravagantdelight:boiled_quince_pulp',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'extravagantdelight:boiled_quince_pulp': 1002035,

    1002036: {
        id: 'rusticdelight:baked_potato_slices',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'rusticdelight:baked_potato_slices': 1002036,

    1002037: {
        id: 'some_assembly_required:chopped_golden_carrot',
        type: 2, //蔬菜
        price: 8,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'some_assembly_required:chopped_golden_carrot': 1002037,

    1002038: {
        id: 'manors_bounty:cooked_peanut',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:cooked_peanut': 1002038,

    1002039: {
        id: 'peruviansdelight:yuca_frita',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'peruviansdelight:yuca_frita': 1002039,

    1002040: {
        id: 'neapolitan:dried_banana',
        type: 2, //蔬菜
        price: 4,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'neapolitan:dried_banana': 1002040,

    1002041: {
        id: 'manors_bounty:cooked_pineapple_slice',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:cooked_pineapple_slice': 1002041,

    1002042: {
        id: 'manors_bounty:gold_kiwifruit_slice',
        type: 2, //蔬菜
        price: 5,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:gold_kiwifruit_slice': 1002042,

    1002043: {
        id: 'manors_bounty:wild_jalapeno_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:wild_jalapeno_slice': 1002043,

    1002044: {
        id: 'manors_bounty:jalapeno_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:jalapeno_slice': 1002044,

    1002045: {
        id: 'manors_bounty:end_pepper_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:end_pepper_slice': 1002045,

    1002046: {
        id: 'manors_bounty:starfruit_slice',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'manors_bounty:starfruit_slice': 1002046,

    1002047: {
        id: 'oceanic_delight:sea_pickle_slices',
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    'oceanic_delight:sea_pickle_slices': 1002047,
    }   
// 将新食材注册到全局食材列表
Object.assign(global.ingredients, BugerVegFoodIngredients)

/*
//
    100204: {
        id: ,
        type: 2, //蔬菜
        price: 3,
        extraprice: 0.8,
        favor: 0.1,
        chapter: 1
    },
    : 100204,
*/