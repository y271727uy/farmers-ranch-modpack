
  //哎哟卧槽，什么傻逼玩意我去
  //中午折腾半个小时司马了啊
  
  //21：44 果然啊,mcr的一切都不适合魔改得了重写重启游戏
  //forge的这个进程卡死是不是祖传的啊
  //草，这代码估计除了 我没有人能看得懂了，命名和代码不符合，不写注释因为我看个鸡毛


StartupEvents.registry('creative_mode_tab', event => {
	event.create('gregtech_food_option').icon(() => 'kubejs:gtfologo').content(() => [
		'kubejs:tungstensteel_apple',
    ''
	])
})


StartupEvents.registry('creative_mode_tab', event => {
	event.create('burger').icon(() => 'farmersdelight:hamburger').content(() => [
		'kubejs:sliced_ham',
    'kubejs:sliced_red_mushroom',
    'kubejs:sliced_brown_mushroom',
    'kubejs:sliced_crimson_fungus',
    'kubejs:smoked_warped_fungus',
    'kubejs:cheese_slice',
    'kubejs:hashbrown',
    'kubejs:bamboo_shoot',
    'kubejs:pickled_bamboo_shoot',
    'kubejs:sliced_enchantfruit',
    'kubejs:sliced_goat',
    'kubejs:sliced_pickle',
    'kubejs:sliced_pitcher',
    'kubejs:sliced_sniffer',
    'kubejs:sliced_succulent',
    'kubejs:sliced_torchflower',
    'kubejs:sliced_turtle',
    'kubejs:sliced_udumbera',
    'kubejs:clam_slice',
    'kubejs:clawster_slice',
    'kubejs:fiddlefern',
    'kubejs:fried_turtle_eggs',
    'kubejs:pepper_pieces',
    'kubejs:scrambled_snifferegg',
    'kubejs:shrimp_slice' ,
    'kubejs:sliced_century_egg',
    'kubejs:sliced_bamboo_shoot',
    'kubejs:smoked_carrot', 
    'kubejs:smoked_carrot_slice', 
    'list:mayo_sauce', 
    'list:bbq_sauce', 
    'list:ancient_sauce', 
    'list:blaze_sauce', 
    'list:pepper_sauce',
    'list:seafood_sauce',
    'list:lime_sauce', 
    'list:urchin_sauce', 
    'kubejs:boneless_mutton', 
    'kubejs:beetroot_slice', 
    'kubejs:onion_slice', 
    'list:pomegranate_sauce', 
    'kubejs:rice_burger_top', 
    'kubejs:rice_burger_bottom', 
    'kubejs:rice_burger',  
    'kubejs:egg_burger', 
    'kubejs:egg_burger_bottom', 
    'kubejs:egg_burger_top', 
    'kubejs:ink_burger_top', 
    'kubejs:ink_burger_bottom', 
    'kubejs:ink_burger', 
    'kubejs:oat_burger_top', 
    'kubejs:oat_burger_bottom', 
    'kubejs:oat_burger', 
    'kubejs:blaze_burger_top', 
    'kubejs:blaze_burger_bottom', 
    'kubejs:blaze_burger',
    'list:pizza_sauce_torch', 
    'list:pizza_sauce_blaze', 
    'list:pizza_sauce_alfredo', 
    'list:pizza_sauce_seafood', 
    'list:pizza_sauce_tomato',
    'kubejs:soda_water', 
    'kubejs:soda_plain',
    'kubejs:soda_lily', 
    'kubejs:soda_lime', 
    'kubejs:fried_chicken', 
    //'kubejs:fries'
	])
})
