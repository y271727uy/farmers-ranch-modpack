/*
// 注册料理台顺序配方的 schema
StartupEvents.recipeSchemaRegistry(event => {
  event.register("youkaishomecoming:cuisine_ordered", builder => {
    builder.require("base", "item")      // 基底必须是物品
    builder.require("input", "array")    // 输入是数组
    builder.require("result", "item")    // 结果是物品
  })
})

// 文件: kubejs/startup_scripts/youkaishomecoming_render.js
StartupEvents.init(event => {
  // 注册蟹肉棒寿司的料理台渲染
  TableItemManager.SUSHI_TOP.addMapping(
    "manors_bounty:surimi_crab_stick_nigiri",
    "youkaishomecoming:sushi/top/surimi_crab_stick",
    0
  )
})
*/

// 引入 KubeJS 的 Schema 类
/*
const $RecipeSchema = Java.loadClass('dev.latvian.mods.kubejs.recipe.schema.RecipeSchema');
const $RecipeComponentBuilder = Java.loadClass('dev.latvian.mods.kubejs.recipe.component.RecipeComponentBuilder');

StartupEvents.recipeSchemaRegistry(event => {
  const { components } = event;

  // 注册你需要的 cuisine_ordered 配方类型
  event.register(
    'youkaishomecoming:cuisine_ordered',
    new $RecipeSchema(
      // 对应 result 字段（输出物品）
      components.get('outputItem')().key('result'),

      // 对应 base 字段（基底，比如 sumeshi）
      components.get('nonBlankString')().key('base'),

      // 对应 input 字段（一个物品数组，比如 surimi_crab_stick 和 nori）
      components.get('inputItemArray')().key('input')
    )
  );
});

let $TableItemManager = Java.loadClass('dev.xkmc.youkaishomecoming.content.pot.table.item.TableItemManager');
let $YHTagGen = Java.loadClass("dev.xkmc.youkaishomecoming.init.data.YHTagGen");

StartupEvents.init(event=>{
    $TableItemManager.SUSHI_TOP['addMapping(java.lang.String,net.minecraft.tags.TagKey)']
    ("circus_fish", $YHTagGen.forgeItem("raw_fishes/circus_fish"));
})
*/

const $RecipeSchema = Java.loadClass('dev.latvian.mods.kubejs.recipe.schema.RecipeSchema');
const $RecipeComponentBuilder = Java.loadClass('dev.latvian.mods.kubejs.recipe.component.RecipeComponentBuilder');
 
StartupEvents.recipeSchemaRegistry(event => {
    const { components } = event
     
    event.register(
        'youkaishomecoming:cuisine_ordered',
        new $RecipeSchema(
            components.get('outputItem')().key('result'),
            components.get('nonBlankString')().key('base').defaultOptional(),
            components.get('inputItemArray')().key('input').defaultOptional()
        )
    );
 
    event.register(
        'youkaishomecoming:cuisine_mixed',
        new $RecipeSchema(
            components.get('outputItem')().key('result'),
            components.get('nonBlankString')().key('base').defaultOptional(),
            components.get('inputItem')().key('first').defaultOptional(),
            components.get('inputItemArray')().key('second').defaultOptional()
        )
   );

  });