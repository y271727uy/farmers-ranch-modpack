---
navigation:
  title: 爆裂蕈
  icon: vital_herbs:burst_bud
  parent: special-crops/index.md
  position: 1
item_ids:
  - vital_herbs:burst_bud
---

## 爆裂蕈

<ItemImage id="vital_herbs:burst_bud" />

### 来源
爆裂蕈植株生成于下界荒地和玄武岩三角洲。  

### 种植
爆裂蕈植株可种植在下界岩、菌岩、灵魂沙、灵魂土、玄武岩和平滑玄武岩上。  
爆裂蕈可以使用骨粉催熟。  
