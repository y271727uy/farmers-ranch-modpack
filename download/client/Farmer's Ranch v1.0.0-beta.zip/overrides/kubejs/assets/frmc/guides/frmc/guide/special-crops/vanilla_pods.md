---
navigation:
  title: 香草荚 
  icon: neapolitan:vanilla_pods
  parent: special-crops/index.md
  position: 1
item_ids:
  - neapolitan:vanilla_pods
---

## 香草荚 

<ItemImage id="neapolitan:vanilla_pods" />

香草藤蔓会自然生成于热带草原的金合欢树上，破坏后掉落香草荚。  
可以依附在土，木头，树叶等方块的任意表面生长，使用骨粉可使加速并不断生长。  
不使用剪刀破坏将生成带有15秒中毒效果的状态效果云（仅在被破坏的一节生成）  