---
navigation:
  title: 姬海棠果
  icon: immortalers_delight:himekaido
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:himekaido
  - immortalers_delight:himekaido_seed
---

## 姬海棠果

<ItemImage id="immortalers_delight:himekaido" />
<ItemImage id="immortalers_delight:himekaido_seed" />

### 来源   
由嗅探兽在森林、繁花森林、桦木森林、原始桦木森林 、黑森林​、雪林挖掘获得。

### 种植  
姬海棠种子可以种植在耕地、沃土耕地上，共有八个生长阶段：0%、14%、29%、43%、57%、71%、86%、成熟。 
- 生长速度不大于 3 时，只会生长为第四阶段的姬海棠灌木并结果，采摘方式与甜浆果类似；  
- 生长速度大于 3 时（种植于湿润耕地、避免过度密植），利用骨粉可催生为姬海棠树；  
- 5~7 阶段的姬海棠灌木在随机刻时不会生长，反而回退一个生长阶段；  
- 姬海棠树上只有结果的树叶会不断开花和结果，右击可采摘姬海棠果。  