---
navigation:
  title: 茂盛芒果
  icon: extravagantdelight:lush_mango
  parent: special-crops/index.md
  position: 1
item_ids:
  - extravagantdelight:lush_mango
---

## 茂盛芒果

<ItemImage id="extravagantdelight:lush_mango" />

### 来源
茂盛芒果是一种稀有作物。由于本整合包修改，茂盛芒果无法自然获得，只能从 SDM 商店购买，或者使用林业温室培养获得。  
