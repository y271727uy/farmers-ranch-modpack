---
navigation:
  title: 幻昙花
  icon: youkaishomecoming:udumbara_flower
  parent: special-crops/index.md
  position: 1
item_ids:
  - youkaishomecoming:udumbara_seeds
  - youkaishomecoming:udumbara_flower
---

## 幻昙花

<ItemImage id="youkaishomecoming:udumbara_seeds" />
<ItemImage id="youkaishomecoming:udumbara_flower" />

### 来源
收获最高生长阶段的幻昙花作物可获得幻昙花。  

### 生长
幻昙花仅在月相为满月的夜晚时才会生长至最高生长阶段。  
月相不为满月的夜晚，幻昙花只能生长至第二高的生长阶段。  
完全成熟的幻昙花在夜晚结束时会逐渐降低生长阶段。  
使用非透明方块遮挡幻昙花可以暂停这一过程的进度。  

### 催熟
幻昙花在生长过程中不能使用骨粉催熟。  
幻月灯可以加速幻昙花的生长进程。  
收获幻昙花作物时不会掉落额外的幻昙华叶片。  
