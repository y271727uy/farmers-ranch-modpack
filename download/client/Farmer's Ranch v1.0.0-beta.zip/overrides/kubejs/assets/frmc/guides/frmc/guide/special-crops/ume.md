---
navigation:
  title: 青梅
  icon: manors_bounty:ume
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:ume
---

## 青梅

<ItemImage id="manors_bounty:ume" />

### 来源
青梅是一种稀有作物，可以在 SDM 商店购买，或通过种植蜜桃种子有概率获得。  

### 种植
也可以将蜜桃种子种植于树坑上培育桃树，有概率获得青梅。  
