---
navigation:
  title: 可视化配方编辑器
  icon: minecraft:crafting_table
  parent: dev-guide/index.md
  position: 3
---

## 可视化配方编辑器

本项目使用的可视化配方编辑器基于 [visual_recipe_editor-1.20.1-Forge](https://github.com/y271727uy/visual_recipe_editor-1.20.1-Forge)。  
下载地址：[visual recipe editor](https://github.com/y271727uy/visual_recipe_editor-1.20.1-Forge/tree/main/download)

> **注意**  
> 目前仅 JSON 生成有额外维护，KubeJS 导出不保证可用性。  
> 本项目修正了输出字段为 `id` 与 1.20.1 版本期望 JSON 键值不一致导致的配方无法加载问题。

## 导出说明

JSON 配方会导出到：

```text
<游戏目录>/exported_recipes/
```

KubeJS 脚本会尝试导出到：

```text
<游戏目录>/kubejs/server_scripts/exported_recipes.js
```

但本项目只建议使用 JSON 导出结果。  
导出的文件名采用 URL 安全的 Base64 编码加随机字节生成，进入实际生产环境后可读性极差，请务必单独隔离、整理后再合并进正式数据包或 KubeJS 项目。

如果打开编辑器时与 JEI 书签区域重叠，请临时隐藏 JEI 书签。

## 砧板配方编辑器

输入以下任意命令打开砧板配方编辑器：

```mcfunction
/re cutting_board
/recipeexporter cutting_board
```

砧板编辑器的 UI 略显粗糙，但功能相对齐全。

### 槽位说明

- 工具槽位默认可以留空，导出时会自动填补为 `forge:tools/knive`
- 输出槽位是右侧的 4 个槽位
- 默认不会生成概率输出
- 如果需要概率输出，请在左侧 4 个数字槽位填写期望概率
- 数字槽位填写 `0` 表示不使用概率输出
- 每个数字输入槽位会对应相对位置的输出槽位

## 厨锅配方编辑器

输入以下任意命令打开厨锅配方编辑器：

```mcfunction
/re cook_pot
/recipeexporter cook_pot
```

厨锅编辑器的默认烹饪时间为 100 刻。  
烹饪时间和获取经验等参数在右侧修改。

## 推荐流程

1. 在测试环境中打开对应工作方块的编辑器。
2. 填写输入、输出和额外参数。
3. 导出 JSON 配方。
4. 到 `<游戏目录>/exported_recipes/` 中找到新生成的文件。
5. 手动检查并重命名文件。
6. 确认配方能正常加载后，再移动到正式数据包或项目目录中。
