---
navigation:
  title: 杜松子
  icon: brewincompatdelight:juniper_berries
  parent: special-crops/index.md
  position: 1
item_ids:
  - brewincompatdelight:juniper_berries
---

## 杜松子

<ItemImage id="brewincompatdelight:juniper_berries" />

### 来源
破坏刺柏树叶或云杉树叶可以获得杜松子。  
