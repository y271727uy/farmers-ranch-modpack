---
navigation:
  title: 百香果
  icon: bountifulfares:passion_fruit
  parent: special-crops/index.md
  position: 1
item_ids:
  - bountifulfares:passion_fruit
  - manors_bounty:passion_fruit_slice
---

## 百香果

<ItemImage id="bountifulfares:passion_fruit" />
<ItemImage id="manors_bounty:passion_fruit_slice" />

### 来源
破坏野生百香果藤蔓可获得百香果。  

### 种植
百香果可作为种子种植在格架上。  
百香果切片也可种植在攀爬杆和攀爬架上。  
