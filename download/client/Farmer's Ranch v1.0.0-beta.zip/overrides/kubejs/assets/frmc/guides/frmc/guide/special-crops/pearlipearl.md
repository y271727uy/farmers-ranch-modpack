---
navigation:
  title: 珍珠棱蕉
  icon: immortalers_delight:pearlip
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:pearlipearl
  - immortalers_delight:pearlip
---

## 珍珠棱蕉

<ItemImage id="immortalers_delight:pearlipearl" />
<ItemImage id="immortalers_delight:pearlip" />

### 来源  
由嗅探兽在丛林、竹林、稀疏丛林挖掘获得。  

### 种植  
棱珠可以种植在泥土类方块上，可以使用骨粉催熟。  
- 种植后假茎会逐渐变粗并生长至 3 格高开花；  
- 第 2 格会缓慢结出 4 个棱蕉串，挖掘后掉落若干珍珠棱蕉。  