---
navigation:
  title: 糯米
  icon: vietnam_delight:sticky_rice
  parent: special-crops/index.md
  position: 1
item_ids:
  - vietnam_delight:sticky_rice_panicle
  - vietnam_delight:sticky_rice
---

## 糯米

<ItemImage id="vietnam_delight:sticky_rice" />
<ItemImage id="vietnam_delight:sticky_rice_panicle" />

### 获取
破坏沼泽群系自然生成的野生稻米时掉落。  

### 用途
糯米可以用于种植。  
糯米必须在位于静止的水下方的泥土、草方块或沃土上才能种植。  
种植后的水稻作物共有四个生长阶段，但只有上方一格处为空气时才能长成第三、四阶段。  
成熟后的水稻作物有两格高，并且会在较高的一格被破坏时掉落糯米穗。  
