---
navigation:
  title: 小麦草
  icon: cosmopolitan:wheatgrass
  parent: special-crops/index.md
  position: 1
item_ids:
  - cosmopolitan:wheatgrass
---

## 小麦草

<ItemImage id="cosmopolitan:wheatgrass" />

### 来源
破坏生长期的小麦有概率掉落若干小麦草。  
- 3、4 阶段有 50% 概率掉落 1~2 个；
- 5、6 阶段有 50% 概率掉落 2~4 个。
