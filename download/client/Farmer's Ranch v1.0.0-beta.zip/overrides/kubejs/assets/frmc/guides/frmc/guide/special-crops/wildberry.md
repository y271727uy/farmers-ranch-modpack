---
navigation:
  title: 野莓
  icon: cosmopolitan:wildberry
  parent: special-crops/index.md
  position: 1
item_ids:
  - cosmopolitan:wildberry
---

## 野莓

<ItemImage id="cosmopolitan:wildberry" />

### 来源
破坏草和高草丛有 12.5% 的概率掉落若干野莓，掉落数量受时运影响。  
