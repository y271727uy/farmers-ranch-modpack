---
navigation:
  title: 香蕉
  icon: neapolitan:banana
  parent: special-crops/index.md
  position: 1
item_ids:
  - neapolitan:banana_frond
  - neapolitan:small_banana_frond
  - neapolitan:large_banana_frond
  - neapolitan:banana
  - neapolitan:banana_bunch
---

## 香蕉

<ItemImage id="neapolitan:banana" />

香蕉树上会长出三种大小的蕉叶，均可用于种植香蕉树。蕉叶可以被放置在任意表面，但只有顶面可以生长，初始为小型，使用蕉叶再次右击可增大蕉叶大小。  
雨天时，种植在沙子与沙砾顶部的蕉叶会自然成长为香蕉树，也可在雨天使用骨粉催熟位于任意方块顶部的蕉叶使其成长为香蕉树，蕉叶越大长成的香蕉树越大，平均小型3-4格，中型4-5格，大型5-6格。  
若有方块阻挡香蕉树的蕉叶生成（例如花）上方挡住雨，则蕉叶不会长大。  
可以通过林业温室进行培养，此方式不会被环境限制。  