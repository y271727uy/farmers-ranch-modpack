---
navigation:
  title: 接骨木莓
  icon: bountifulfares:elderberries
  parent: special-crops/index.md
  position: 1
item_ids:
  - bountifulfares:elderberries
---

## 接骨木莓

<ItemImage id="bountifulfares:elderberries" />

### 来源
破坏野生接骨木莓藤蔓可获得接骨木莓。  

### 种植
接骨木莓可作为种子种植在格架上。  
