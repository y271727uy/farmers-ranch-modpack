---
navigation:
  title: DLC制作：Mixin使用
  icon: minecraft:purple_dye
  parent: dev-guide/index.md
  position: 8
---

## DLC制作：Mixin使用

Mixin 适合处理数据层和事件层不好碰到的内容，但它不该被当成第一方案。  
能用事件、配置或 KubeJS 解决的，优先别上 Mixin。

### 先看版本

- Mixin 推荐版本：`0.8.5`
- 如果需要 MixinSquared，建议使用 `0.3.2-beta.4`
- 暂时不建议直接往更高版本跳，除非你已经确认兼容

### FRMC 黑名单

如果希望使用 FarmersRanchMixinCore 提供的 mixin 黑名单功能，需要先让工程能够访问 `FarmersRanchMixinCore`。

```java
import com.y271727uy.FRMC.mixin.blacklist.FRMCMixinBlacklistConfig;
```

然后在模组初始化阶段注册黑名单即可，构造函数或 `FMLCommonSetupEvent` 都可以：

```java
FRMCMixinBlacklistConfig.addBlacklistedMixin("com.example.mod.mixin.BadMixin");
FRMCMixinBlacklistConfig.addBlacklistedMixin("com.example.mod.mixin.broken.*");
```

这个方式适合：

- 临时屏蔽某个出问题的 mixin。
- 屏蔽整包命名空间下的 mixin。
- 做兼容排查时快速验证是不是某个注入导致问题。

### MixinSquared 黑名单

如果要用 MixinSquared 的黑名单能力，核心思路是自己实现并注册一个 `MixinCanceller`。

常见接口和入口是：

- `com.bawnorton.mixinsquared.api.MixinCanceller`
- `boolean shouldCancel(List<String> targetClassNames, String mixinClassName)`
- `com.bawnorton.mixinsquared.canceller.MixinCancellerRegistrar.register(MixinCanceller)`

这种方式是外部模组自己拦截 mixin，能在 `preApply` 阶段取消注入。  
它也可以拦截其他模组的 mixin，前提是你的工程能访问到对应的 MixinSquared 类。

### 使用习惯

- 先做最小注入，再慢慢加功能。
- 一旦出现冲突，先怀疑注入点，再怀疑别的地方。
- Mixin 写得越少，后面越容易维护。
