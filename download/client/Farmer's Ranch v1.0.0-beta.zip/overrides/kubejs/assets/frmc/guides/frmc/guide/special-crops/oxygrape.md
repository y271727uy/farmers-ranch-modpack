---
navigation:
  title: 氧葡萄
  icon: immortalers_delight:oxygrape
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:oxygrape
---

## 氧葡萄

<ItemImage id="immortalers_delight:oxygrape" />

### 来源   
氧葡萄植株自然生成于海底神殿。  
 
### 种植
氧葡萄可以种植在方块底部，且植株需生长于水中，可以使用骨粉催熟。   
末端的氧葡萄每次生长时，会向下生长 1 格或进入下一生长阶段，各自 50% 概率，达到最大生长阶段后只会向下生长。  
成熟后右击可收获氧葡萄，未成熟时被破坏会掉落海带。  