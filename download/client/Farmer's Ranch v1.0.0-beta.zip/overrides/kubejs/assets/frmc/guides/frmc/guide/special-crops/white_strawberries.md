---
navigation:
  title: 白草莓
  icon: neapolitan:white_strawberries
  parent: special-crops/index.md
  position: 1
item_ids:
  - neapolitan:white_strawberries
---

## 白草莓

<ItemImage id="neapolitan:white_strawberries" />

收获成熟的白草莓丛获得。  
当种植高度超过y200(本整合包实测y需要大于等于256以上)或种植于末地时，成熟后将收获白草莓。