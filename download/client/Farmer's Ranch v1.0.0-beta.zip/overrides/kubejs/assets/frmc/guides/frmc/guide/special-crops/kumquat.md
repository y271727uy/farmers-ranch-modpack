---
navigation:
  title: 金桔
  icon: vietnam_delight:kumquat
  parent: special-crops/index.md
  position: 1
item_ids:
  - vietnam_delight:kumquat_seeds
  - vietnam_delight:green_kumquat
  - vietnam_delight:kumquat
---

## 金桔

<ItemImage id="vietnam_delight:kumquat_seeds" />
<ItemImage id="vietnam_delight:green_kumquat" />
<ItemImage id="vietnam_delight:kumquat" />

### 收获
金桔有两个成熟阶段，分别为青金桔与金桔。  
青金桔会随着时间流逝成熟为金桔。  
