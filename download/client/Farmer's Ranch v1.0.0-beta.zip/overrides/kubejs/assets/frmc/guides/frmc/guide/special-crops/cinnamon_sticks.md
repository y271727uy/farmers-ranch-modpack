---
navigation:
  title: 肉桂条
  icon: festive_delight:cinnamon_sticks
  parent: special-crops/index.md
  position: 1
item_ids:
  - festive_delight:cinnamon_sticks
---

## 肉桂条

<ItemImage id="festive_delight:cinnamon_sticks" />

肉桂从分布于针叶林、原始松木针叶林、原始云杉针叶林中。  
肉桂条通过种植肉桂从获得。 