---
navigation:
  title: 白垩玉黍
  icon: immortalers_delight:evolutcorn
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:evolutcorn
  - immortalers_delight:evolutcorn_grains
---

## 白垩玉黍

<ItemImage id="immortalers_delight:evolutcorn" />
<ItemImage id="immortalers_delight:evolutcorn_grains" />

### 来源   
由嗅探兽在平原、雪原、草甸、向日葵平原挖掘获得。

### 种植  
白垩玉黍粒可以种植在耕地、沃土耕地上，可以使用骨粉催熟。
成熟后右击收获白垩玉黍。