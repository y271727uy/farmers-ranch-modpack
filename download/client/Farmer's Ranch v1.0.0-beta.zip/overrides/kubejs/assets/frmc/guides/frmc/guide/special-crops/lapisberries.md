---
navigation:
  title: 青金石莓
  icon: bountifulfares:lapisberries
  parent: special-crops/index.md
  position: 1
item_ids:
  - bountifulfares:lapisberries
  - bountifulfares:lapisberry_seeds
---

## 青金石莓

<ItemImage id="bountifulfares:lapisberry_seeds" />
<ItemImage id="bountifulfares:lapisberries" />

### 来源
青金石莓种子有概率在嗅探兽刨挖后获得，这是青金石莓种子的唯一获取方式。  

### 种植
青金石莓种子需要种植在格架上。  
青金石莓可以使用骨粉催熟，但无法使用剪刀采集。  
