---
navigation:
  title: 烬烟杆
  icon: immortalers_delight:a_bush
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:a_bush
---

## 烬烟杆

<ItemImage id="immortalers_delight:a_bush" />

### 来源  
由嗅探兽在下界荒地挖掘获得。  

### 种植
烬烟杆可以种植在下界岩上，可以使用骨粉催熟。
成熟的烬烟杆植株被破坏会掉落 2~5 个烬烟杆，数量受时运魔咒加成。
成熟的烬烟杆植株若处于熔岩源中，会转变为烬烟木。