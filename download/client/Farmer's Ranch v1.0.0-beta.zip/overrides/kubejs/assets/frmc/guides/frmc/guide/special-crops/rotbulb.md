---
navigation:
  title: 腐芋
  icon: dungeonsdelight:rotbulb
  parent: special-crops/index.md
  position: 1
item_ids:
  - dungeonsdelight:rotbulb_crop
  - dungeonsdelight:rotbulb
---

## 腐芋

<ItemImage id="dungeonsdelight:rotbulb" />
<ItemImage id="dungeonsdelight:rotbulb_crop" />

### 来源
腐芋球茎可通过搜寻腐烂地牢宝箱、破坏野生腐芋或击杀山芋怪获得。  
腐烂地牢宝箱中有 38.46% 概率生成 2~5 个腐芋球茎。  

### 种植
腐芋需要在无天空光照，且光照等级不大于 8 的环境下生长。  
首次种植会达成进度【尸花】。  

### 收获
破坏球茎不会直接掉落物品，而是会召唤山芋怪。  
击杀山芋怪后会掉落 1 个腐芋，腐芋需要精加工后食用。  
和平模式下破坏球茎会直接掉落对应战利品。  
