---
navigation:
  title: 含茶竹节
  icon: immortalers_delight:contains_tea_leisamboo
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:contains_tea_leisamboo
---

## 含茶竹节

<ItemImage id="immortalers_delight:contains_tea_leisamboo" />

### 来源  
由嗅探兽在河流、冻河挖掘获得。

### 种植  
含茶竹节可以种植在水下的泥土或其变种方块上，可以使用骨粉催熟。  
- 水深 1 格时，会生长成 2 格高的溪竹，待水面上竹节成熟，破坏后获得一个含茶竹节，提前破坏会获得一节竹子；
- 水深大于 1 格时，只会生长成 1 格高的溪竹，破坏后获得一节竹子。