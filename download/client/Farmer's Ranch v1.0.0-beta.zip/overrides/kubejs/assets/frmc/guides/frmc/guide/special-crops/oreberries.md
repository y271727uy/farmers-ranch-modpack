---
navigation:
  title: 矿莓
  icon: oreberriesreplanted:iron_oreberry_bush
  parent: special-crops/index.md
  position: 1
item_ids:
  - oreberriesreplanted:gold_oreberry
  - oreberriesreplanted:iron_oreberry
  - oreberriesreplanted:iron_oreberry_bush
  - oreberriesreplanted:gold_oreberry_bush
  - oreberriesreplanted:uranium_oreberry
  - oreberriesreplanted:osmium_oreberry
  - oreberriesreplanted:zinc_oreberry
  - oreberriesreplanted:silver_oreberry
  - oreberriesreplanted:essence_berry
  - oreberriesreplanted:aluminum_oreberry
  - oreberriesreplanted:zinc_oreberry_bush
  - oreberriesreplanted:silver_oreberry_bush
  - oreberriesreplanted:osmium_oreberry_bush
  - oreberriesreplanted:uranium_oreberry_bush
  - oreberriesreplanted:nickel_oreberry_bush
  - oreberriesreplanted:lead_oreberry_bush
  - oreberriesreplanted:aluminum_oreberry_bush
  - oreberriesreplanted:tin_oreberry_bush
  - oreberriesreplanted:copper_oreberry_bush
  - oreberriesreplanted:nickel_oreberry
  - oreberriesreplanted:lead_oreberry
  - oreberriesreplanted:tin_oreberry
  - oreberriesreplanted:copper_oreberry
---

## 矿莓

### 来源
矿莓丛会在地下生成，可以直接破坏后带回家种植。  

### 种植
默认情况下，矿莓丛只能种植在黑暗的地方。  
矿莓丛生长完成后会生产矿莓，表现为表面出现奇怪斑点，右击即可获得矿莓。  
贴近矿莓丛会受到类似仙人掌的伤害，但不会像仙人掌一样摧毁物品。  

### 处理
获得矿莓后，需要将其放入踩莓盆获得对应的矿莓果汁。  
矿莓果汁会随着时间流逝析出矿物粒。  
