---
navigation:
  title: 黑莓
  icon: manors_bounty:blackberry
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:blackberry
---

## 黑莓

<ItemImage id="manors_bounty:blackberry" />

### 来源
黑莓是一种稀有作物。由于本整合包修改，黑莓无法自然获得，只能从 SDM 商店购买，或者使用林业温室培养获得。  
