---
navigation:
  title: DLC制作：GuideME编写
  icon: minecraft:purple_dye
  parent: dev-guide/index.md
  position: 10
---

## DLC制作：GuideME编写

GuideME 的页面本身就是 Markdown。先把页面结构、目录关系和物品绑定理顺，后面再加组件会轻松很多。

### 页面放哪

页面会从 `guides/<guide_id_namespace>/<guide_id_path>/` 读取。  
在这个项目里，实际内容放在 `guides/frmc/guide/` 下面。

文件名需要是合法资源 ID，也就是全小写。  
每个 `.md` 文件都会被当成一页，子目录也会继续被读取。

### 页面开头

每页通常先写 frontmatter，再写正文：

```md
---
navigation:
  title: 页面标题
---

# 页面标题
正文
```

这个项目里常用的是这些字段：

- `navigation.title`
- `navigation.icon`
- `navigation.parent`
- `navigation.position`
- `item_ids`

`navigation` 负责页面在导航栏里的位置。  
`item_ids` 负责把物品绑定到这页，后面 `<ItemLink />` 能不能跳过来，主要就看这个。

### 导航关系

- `parent` 用来挂子页面。
- `position` 用来排顺序。
- `<SubPages />` 可以把当前分类下的子页面直接列出来。

这套结构很适合做“总目录页 + 子页面”的组织方式。  
你现在的特殊作物页、开发者指南页，都是这个思路。

### 常用组件

最常见、也最该先学会的几个标签是这些：

- `<ItemImage />`：显示物品图。
- `<ItemLink />`：显示物品名，并链接到主页面。
- `<RecipeFor />`：显示某个物品的第一个配方。
- `<RecipesFor />`：显示某个物品的所有配方。
- `<Recipe />`：显示指定配方。
- `<SubPages />`：显示子页面列表。
- `<Row />` 和 `<Column />`：控制横向和纵向排版。
- `<CategoryIndex />`：按分类列页面。

正文里如果要让一堆物品排整齐，`Row` 和 `Column` 很有用。  
如果是单个物品说明，直接用 `ItemImage` 就够了。

### 资源和翻译

GuideME 会优先读取默认语言内容。  
如果你要做翻译，可以把同一页放到对应语言目录里，比如：

```text
_zh_cn/
_en_us/
```

找不到翻译页时，会回退到默认页面。  
图片和其他资源也会先读语言目录，再回退到默认目录。

### 这个项目里的写法

这个项目的 GuideME 页一般会保持几件事：

- 标题短，读起来直接。
- 目录页只负责列子页。
- 条目页尽量先给物品图，再给来源和规则。
- `item_ids` 只放真正要绑定的物品。
- 页面文案尽量贴近游戏里的实际行为，不硬讲概念。

### 参考

- [GuideME Documentation](https://guideme.appliedenergistics.org/)
- [Authoring Pages](https://guideme.appliedenergistics.org/authoring/)
- [Data Driven Guides](https://guideme.appliedenergistics.org/data-driven-guides/)
- [Integration into Mods](https://guideme.appliedenergistics.org/integration/)
- [GuideME Example](https://guideme.appliedenergistics.org/#example)
