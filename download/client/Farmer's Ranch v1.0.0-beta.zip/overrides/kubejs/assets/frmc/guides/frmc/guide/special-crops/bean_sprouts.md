---
navigation:
  title: 豆芽
  icon: vietnam_delight:bean_sprouts
  parent: special-crops/index.md
  position: 1
item_ids:
  - vietnam_delight:bean_sprouts
---

## 豆芽

<ItemImage id="vietnam_delight:bean_sprouts" />

### 收获
豆芽是绿豆作物成熟的中间态。  
若不及时采集，豆芽将会继续生长并变成绿豆。  
