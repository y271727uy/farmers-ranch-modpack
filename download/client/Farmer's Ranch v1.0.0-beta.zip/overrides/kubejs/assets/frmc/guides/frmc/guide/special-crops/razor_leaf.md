---
navigation:
  title: 剃刀叶
  icon: vital_herbs:razor_leaf
  parent: special-crops/index.md
  position: 1
item_ids:
  - vital_herbs:razor_leaf
---

## 剃刀叶

<ItemImage id="vital_herbs:razor_leaf" />

### 种植
剃刀叶可以直接种植在泥土上。  
