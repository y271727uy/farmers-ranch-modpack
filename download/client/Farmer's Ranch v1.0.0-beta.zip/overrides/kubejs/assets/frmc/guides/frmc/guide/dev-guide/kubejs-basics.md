---
navigation:
  title: DLC制作：KubeJS基础
  icon: minecraft:purple_dye
  parent: dev-guide/index.md
  position: 5
---

## DLC制作：KubeJS基础

KubeJS 常用来接入模组内容、事件和配方。做 DLC 时，先把脚本目录和加载顺序理清，后面写语法会顺很多。

### 常用目录

```text
kubejs/
├─ startup_scripts/
├─ server_scripts/
└─ client_scripts/
```

- `startup_scripts`：启动最早，适合基础注册和早期初始化。
- `server_scripts`：服务端逻辑、配方、掉落、事件，大多数 DLC 内容都在这里。
- `client_scripts`：客户端显示、提示、界面和渲染相关内容。

### 常见语法

KubeJS 里最常见的写法通常是事件回调：

```js
ServerEvents.recipes(event => {
  // 在这里写配方逻辑
})
```

需要先认得这些东西：

- `event`：事件对象。
- `=>`：箭头函数。
- `[]`：数组。
- `{}`：对象。
- `"` / `'`：字符串。

### 读脚本时先看什么

- 这是启动脚本，还是服务端脚本。
- 它是在注册内容，还是在修改已有内容。
- 它改的是逻辑，还是只改显示。
- 它依赖的模组和命名空间是否已经存在。

### 建议

- 新内容尽量先单文件验证。
- 能拆开的脚本就拆开。
- 不要把所有逻辑塞进一个文件里。
- 先把结构弄清楚，再写细节。
