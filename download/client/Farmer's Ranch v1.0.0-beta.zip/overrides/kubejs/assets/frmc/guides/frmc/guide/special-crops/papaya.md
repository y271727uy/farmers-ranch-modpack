---
navigation:
  title: 木瓜
  icon: muffins_thaidelight:papaya
  parent: special-crops/index.md
  position: 1
item_ids:
  - muffins_thaidelight:papaya_sapling
  - muffins_thaidelight:papaya_seeds
  - muffins_thaidelight:papaya
  - muffins_thaidelight:raw_papaya
---

## 木瓜

<ItemImage id="muffins_thaidelight:papaya_sapling" />
<ItemImage id="muffins_thaidelight:papaya_seeds" />
<ItemImage id="muffins_thaidelight:raw_papaya" />
<ItemImage id="muffins_thaidelight:papaya" />

### 收获
木瓜有两个可收集阶段，分别为青色的生木瓜与橙色的成熟木瓜。  
生木瓜会随着时间流逝成熟为木瓜。  
