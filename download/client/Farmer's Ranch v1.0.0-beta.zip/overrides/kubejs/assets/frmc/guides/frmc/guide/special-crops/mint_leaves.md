---
navigation:
  title: 薄荷
  icon: neapolitan:mint_leaves
  parent: special-crops/index.md
  position: 1
item_ids:
  - neapolitan:mint_leaves
  - neapolitan:mint_sprout
---

## 薄荷

<ItemImage id="neapolitan:mint_leaves" />
<ItemImage id="neapolitan:mint_sprout" />

薄荷自然生成于风袭森林/繁茂的山地，生成时会伴有一个小水池。   
薄荷苗可以种植在任何土类方块（包括砂土，灰化土，菌丝等）上，一格内最多可以种植4株。  
只有在亮度≥9的条件下才能生长。  
成熟后可以收获薄荷叶，成熟的薄荷苗可以促进周围非薄荷植物的生长。  