---
navigation:
  title: 诡怨桂
  icon: immortalers_delight:warped_laurel
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:warped_laurel_seeds
  - immortalers_delight:warped_laurel
---

## 诡怨桂

<ItemImage id="immortalers_delight:warped_laurel_seeds" />
<ItemImage id="immortalers_delight:warped_laurel" />

### 来源
由嗅探兽在诡异森林挖掘获得。   

### 种植
诡怨桂种子可以种植在耕地、灵魂沙、灵魂土和沃土耕地上，可以使用骨粉催熟。  
成熟后右击可收获诡怨桂种子和诡怨桂果。   