---
navigation:
  title: DLC制作：使用KubeJS创建DLC
  icon: minecraft:purple_dye
  parent: dev-guide/index.md
  position: 6
---

## DLC制作：使用KubeJS创建DLC

用 KubeJS 做 DLC 时，最重要的是隔离。DLC 的脚本、命名和打包方式，都应该和整合包主脚本分开。

### 目录隔离

- 不要和整合包已经有的脚本混放。
- 推荐在对应脚本目录下新建一个独立包。
- 如果同时涉及启动、服务端和客户端内容，三个目录都保持同一套包名。

例如：

```text
kubejs/server_scripts/textdls/
kubejs/startup_scripts/textdls/
kubejs/client_scripts/textdls/
```

### 命名建议

- DLC 包名建议直接使用 DLC 的实际名字，避免撞车。
- 不建议使用中文脚本名。
- 也不建议中文和拼音混着写。
- 文件名尽量短、清楚、统一。

### 打包分发

- 如果要分发，就只打包 DLC 自己的脚本。
- 不要把整合包主脚本一起带进去。
- 推荐使用 KubeLoader 把 DLC 打成 jar。
- 打包前先确认目录里没有多余测试文件。

### 维护习惯

- 每个 DLC 先独立跑通，再考虑合并展示。
- 公共逻辑和 DLC 逻辑尽量分开。
- 后面要删、要换、要迁移时，独立包会轻松很多。
