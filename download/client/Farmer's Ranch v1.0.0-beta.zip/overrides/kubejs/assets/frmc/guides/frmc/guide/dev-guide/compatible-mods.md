---
navigation:
  title: 兼容模组清单
  icon: minecraft:emerald
  parent: dev-guide/index.md
  position: 12
---

## 兼容模组清单

> 以下 Mod 均经过测试已兼容，或已经进行了特殊兼容处理。

### 模组列表

1. **Extra Delight Unofficial Port**

   经过特殊处理，兼容目前版本农夫乐事（Farmers Delight）。

2. **现代乐事（Modern Delight）Forge 版**

   经过测试，兼容良好，并且已经完成了基础的物品统一。

3. **森罗物语：厨房（Kaleidoscope Cookery）**

   经过测试，兼容良好，并且已经完成了基础的物品统一。

4. **火花（spark）**

   经过测试，兼容良好。

5. **observable**

   经过测试，兼容良好。

6. **ProbeJS**

   经过测试，兼容良好。

7. **应用能源2 (Applied Energistics 2)**

   经过测试，兼容良好！

8. **蟹农乐事：渔冶锭整(Crabber's Delight Expand)**

   经过测试，兼容良好！

9. **LDLib**

   经过测试，兼容良好！

10. **纸鸢庄园(Paper Kite Manor)**

   经过测试，兼容良好！
