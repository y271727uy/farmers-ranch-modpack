---
navigation:
  title: 咖啡浆果
  icon: farmersrespite:coffee_berries
  parent: special-crops/index.md
  position: 1
item_ids:
  - farmersrespite:coffee_berries
---

## 咖啡浆果

<ItemImage id="farmersrespite:coffee_berries" />

### 来源
咖啡树自然生成于下界的玄武岩三角洲群系，也可以用咖啡豆进行种植。  

### 种植
咖啡树只能种植在玄武岩、磨制玄武岩、平滑玄武岩和岩浆块上，且只有在下界才能正常生长。  
以咖啡树为中心 5×5×2 范围内的农作物会被转变为凋零根须，每株作物能使咖啡树生长一个生长阶段。  
主世界的咖啡树只有通过这种方式才能生长结果。  

### 收获
咖啡树最高可生长到 3 格，需要 4 格空间。  
主干上总共会长出 3 根可结果的树枝，右击成熟的树枝即可收获 1 个咖啡浆果。  

### 处理
咖啡浆果可以在砧板上用刀切开获得咖啡豆，也可以用于合成红色染料。  
