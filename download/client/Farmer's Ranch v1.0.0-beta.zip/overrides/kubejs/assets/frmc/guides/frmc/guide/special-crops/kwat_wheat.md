---
navigation:
  title: 瓦斯麦
  icon: immortalers_delight:kwat_wheat
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:kwat_wheat_seeds
  - immortalers_delight:kwat_wheat
---

## 瓦斯麦

<ItemImage id="immortalers_delight:kwat_wheat" />
<ItemImage id="immortalers_delight:kwat_wheat_seeds" />

### 来源

由嗅探兽在绯红森林挖掘获得。

### 种植
瓦斯麦种子可以种植在耕地、灵魂沙、灵魂土和沃土耕地上，可以使用骨粉催熟。   
刚成熟的瓦斯麦植株无毒，一段时间后（随机刻）变为有毒。有毒植株被触碰会对 7×7×7 格内所有生物造成 2 点（）伤害并施加 6 秒绯烬烈灼Ⅱ效果，自身生长状态回退至 71%。有毒植株被破坏会生成初始半径 3 格的绯烬尘霾效果云，对范围内实体施加 3.75 秒绯烬烈灼Ⅱ效果，超凡模式下延长至 6 秒。  
成熟后右击可收获瓦斯麦种子和瓦斯麦。  