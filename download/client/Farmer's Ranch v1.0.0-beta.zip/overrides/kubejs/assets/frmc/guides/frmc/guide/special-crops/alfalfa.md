---
navigation:
  title: 古苜蓿
  icon: immortalers_delight:alfalfa
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:alfalfa_seeds
  - immortalers_delight:alfalfa
---

## 古苜蓿

<ItemImage id="immortalers_delight:alfalfa_seeds" />
<ItemImage id="immortalers_delight:alfalfa" />

### 来源   
由嗅探兽在任意群系挖掘获得。
 
### 种植  
古苜蓿种子可以种植在耕地、沃土耕地上生长为古苜蓿，在生长速度不小于 3 时才能成熟，可以使用骨粉催熟。  
古苜蓿可以蔓延到相邻的土质、沙质方块上，在非耕地上最多蔓延 2 格。  
在生长速度不大于 1 时只能蔓延到耕地上。  