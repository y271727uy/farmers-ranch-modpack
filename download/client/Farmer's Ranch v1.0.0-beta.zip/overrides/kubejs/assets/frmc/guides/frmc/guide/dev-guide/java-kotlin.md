---
navigation:
  title: DLC制作：Java与Kotlin
  icon: minecraft:purple_dye
  parent: dev-guide/index.md
  position: 7
---

## DLC制作：Java与Kotlin

下面记录 Forge 1.20.1 里做 DLC 时常用的 Java 与 Kotlin 选择、版本和接入方式。

### Java

Forge 1.20.1 使用 Java 17 构建。  
做 DLC 时，最稳妥的做法也是按 Java 17 来准备环境。

- 版本太高会增加兼容和排错成本。
- 如果工程里已经有 Java 代码，继续沿用也很自然。
- 先把运行环境和构建环境统一，比后面补救省事得多。

### Kotlin

Kotlin 和 Java 有很好的互操作性，适合和现有 Java 工程一起使用。  
如果你想让工程写起来更紧凑，Kotlin 是很顺手的选择。

KotlinForForge 推荐参考：

- [KotlinForForge README](https://github.com/thedarkcolour/KotlinForForge/blob/6.x/README.md)
- 推荐版本：`4.12.0`

如果你准备从零开始搭 Kotlin 工程，推荐直接看模板：

- [KotlinModdingSkeleton](https://github.com/thedarkcolour/KotlinModdingSkeleton)

### 选择建议

- 纯新增内容，且希望和 Java 生态直接对接，Kotlin 很合适。
- 现有工程已经是 Java，也可以继续沿用 Java。
- 无论选哪边，先把构建脚本和运行配置跑通，再开始写内容。
