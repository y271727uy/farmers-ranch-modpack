---
navigation:
  title: 白茄子
  icon: culturaldelights:white_eggplant
  parent: special-crops/index.md
  position: 1
item_ids:
  - culturaldelights:white_eggplant
---

## 白茄子

<ItemImage id="culturaldelights:white_eggplant" />

### 来源
可以在丛林和沼泽地形中寻找自然生成的野生茄子。  
使用剪刀可以完整采集野生茄子，将其放到砧板上切开后可获得白茄子。  
