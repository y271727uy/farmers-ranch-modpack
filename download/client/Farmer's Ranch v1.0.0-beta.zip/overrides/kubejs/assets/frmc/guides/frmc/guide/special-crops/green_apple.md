---
navigation:
  title: 青苹果
  icon: manors_bounty:green_apple
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:green_apple
---

## 青苹果

<ItemImage id="manors_bounty:green_apple" />

### 来源
青苹果可以通过与村民交易获得，也可以在 SDM 商店内直接购买。  

### 种植
青苹果也可以直接种植苹果种子。  
也可以将苹果种子种植于树坑上，培育苹果树苗有概率获得青苹果。  
