---
navigation:
  title: 荧光叶
  icon: vital_herbs:glow_leaf
  parent: special-crops/index.md
  position: 1
item_ids:
  - vital_herbs:glow_leaf
---

## 荧光叶

<ItemImage id="vital_herbs:glow_leaf" />

### 来源
荧光叶植株生成于黑森林。  

### 种植
荧光叶植株没有种子，可使用荧光叶直接种植。  
荧光叶可种植在泥土及其变种、草方块、灰化土、缠根泥土、菌丝体和耕地上。  
