---
navigation:
  title: 云蘑菇
  icon: delighto_flight:cloudshroom_colony
  parent: special-crops/index.md
  position: 1
item_ids:
  - delighto_flight:cloudshroom_colony
  - delighto_flight:thunder_cloudshroom
  - delighto_flight:rainy_cloudshroom
  - delighto_flight:clear_cloudshroom
---

## 云蘑菇

<ItemImage id="delighto_flight:cloudshroom_colony" />
<ItemImage id="delighto_flight:clear_cloudshroom" />
<ItemImage id="delighto_flight:rainy_cloudshroom" />
<ItemImage id="delighto_flight:thunder_cloudshroom" />

### 种植
在气象沃土上种植蘑菇可以获得云蘑菇菌落。  

### 采集
玩家可使用剪刀对成熟的云蘑菇菌落进行采集。  
采集云蘑菇菌落掉落的蘑菇种类取决于天气。  
- 晴天时掉落白云蘑菇；
- 雨天时掉落雨云蘑菇；
- 雷暴时掉落雷云蘑菇。
