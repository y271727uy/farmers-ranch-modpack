---
navigation:
  title: 奇异果
  icon: manors_bounty:gold_kiwifruit
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:gold_kiwifruit
---

## 奇异果

<ItemImage id="manors_bounty:gold_kiwifruit" />

### 来源
奇异果可以在 SDM 商店购买。  

### 种植
也可以直接种植猕猴桃种子，或者将猕猴桃种子种植于树坑上。  
