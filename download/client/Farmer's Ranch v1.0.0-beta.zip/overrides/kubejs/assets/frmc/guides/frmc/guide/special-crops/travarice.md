---
navigation:
  title: 菅米
  icon: immortalers_delight:travarice
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:travarice
---

## 菅米

<ItemImage id="immortalers_delight:travarice" />

### 来源   
由嗅探兽在草甸、冰封山峰、尖峭山峰、裸岩山峰、积雪的山坡、樱花树林挖掘获得。  

### 种植   
菅米可以种植在泥土类方块上，可以使用骨粉催熟。  
种植的菅米会成长为通天菅，右击通天菅上结实的通天菅叶可收获 1~3 个菅米。  
不主动收获的情况下，一段时间后结实的通天菅叶中的菅米会自然掉落。  