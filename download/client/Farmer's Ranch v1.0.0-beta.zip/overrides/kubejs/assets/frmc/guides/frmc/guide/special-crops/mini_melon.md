---
navigation:
  title: 迷你西瓜
  icon: delightful:mini_melon
  parent: special-crops/index.md
  position: 1
item_ids:
  - delightful:mini_melon
---

## 迷你西瓜

<ItemImage id="delightful:mini_melon" />

### 来源
迷你西瓜可以在平原类生物群系中找到。  

### 种植
迷你西瓜可以生长为一个大西瓜。  
