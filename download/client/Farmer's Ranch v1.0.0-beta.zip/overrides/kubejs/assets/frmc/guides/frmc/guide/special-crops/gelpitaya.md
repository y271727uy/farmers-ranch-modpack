---
navigation:
  title: 
  icon: immortalers_delight:gelpitaya
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:gelpitaya_seeds
  - immortalers_delight:gelpitaya
---

## 冰蛟果

<ItemImage id="immortalers_delight:gelpitaya" />
<ItemImage id="immortalers_delight:gelpitaya_seeds" />

### 来源
由嗅探兽在冰刺之地挖掘获得

### 种植
冰蛟果种子需要种植在仙人掌顶部，可以使用骨粉催熟。  
- 触碰生长状态 50% 及以上的冰蛟果植株，每 0.5 秒受到 1 点伤害。  
- 触碰生长状态 83% 及以上的冰蛟果植株，会如同陷入细雪一样，逐渐进入冻伤状态。  
- 冰蛟果成熟时会产生一次雪雾粒子效果，在其周围 1 格内生成雪，将水方块转化为冰方块、岩浆块转化为下界岩。  
- 成熟后使用铁镐或以上级别的镐破坏植株可获得 2 个冰蛟果。  