---
navigation:
  title: 海绵瓜
  icon: bountifulfares:spongekin
  parent: special-crops/index.md
  position: 1
item_ids:
  - bountifulfares:spongekin_slice
  - bountifulfares:spongekin
  - bountifulfares:spongekin_seeds
---

## 海绵瓜

<ItemImage id="bountifulfares:spongekin_seeds" />
<ItemImage id="bountifulfares:spongekin" />
<ItemImage id="bountifulfares:spongekin_slice" />

### 来源
击败远古守卫者后必定掉落 1 个海绵瓜种子。  
首次获得海绵瓜种子可达成进度【绵软之地】。  

### 种植
海绵瓜种子需要种植在水里，底部方块任意。  
它的成长方式类似南瓜种子和西瓜种子，使用骨粉催熟只能加速茎的生长，无法使其快速结果。  
果实会在根茎正上方结出，无论这是否会导致根茎缺水。  
若将其种植在海晶灯上，果实顶部还会结出一朵海晶花。  

### 收获
破坏海绵瓜后随机掉落 3~7 个海绵瓜片。  
使用带有时运的工具采集会掉落 9 个海绵瓜片，使用带有精准采集的工具可以获得完整的海绵瓜。  
使用剪刀右击海绵瓜，会使其蜕皮变为湿海绵。  
首次获得海绵瓜可达成进度【是谁住在深海的大绵瓜里】。  
