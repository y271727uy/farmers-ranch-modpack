---
navigation:
  title: 马黛树叶
  icon: argentinas_delight:yerbamate
  parent: special-crops/index.md
  position: 1
item_ids:
  - argentinas_delight:yerbamate
---

## 马黛树叶

<ItemImage id="argentinas_delight:yerbamate" />

### 来源
破坏马黛茶树叶可以获得马黛树叶。  
也可以在切石机上将马黛茶树树叶切制获得，或通过粉碎马黛茶叶获得。  

### 种植
手持马黛树叶右击地面可以直接种植。  
