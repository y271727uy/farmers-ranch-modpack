---
navigation:
  title: 青芒果
  icon: extravagantdelight:green_mango
  parent: special-crops/index.md
  position: 1
item_ids:
  - extravagantdelight:green_mango
---

## 青芒果

<ItemImage id="extravagantdelight:green_mango" />

### 来源
青芒果是一种稀有作物。由于本整合包修改，青芒果无法自然获得，只能从 SDM 商店购买，或者使用林业温室培养获得。  
