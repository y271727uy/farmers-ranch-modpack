---
navigation:
  title: 凋灵浆果
  icon: frightsdelight:wither_berry
  parent: special-crops/index.md
  position: 1
item_ids:
  - frightsdelight:wither_berry
---

## 凋灵浆果

<ItemImage id="frightsdelight:wither_berry" />

### 来源
凋灵浆果只能由生长完全的灵魂浆果丛转变获得。  

### 转变
当生长完全的灵魂浆果丛周围 1 格内存在“凋灵精华”，并且光照等级为 7 级或以下时，灵魂浆果丛会逐渐转变为凋灵浆果丛。  
“凋灵精华”包括凋灵玫瑰和凋灵骷髅头。  

### 种植
凋灵浆果需要种植在灵魂沙或灵魂土上。  
