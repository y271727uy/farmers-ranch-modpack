---
navigation:
  title: 茶叶
  icon: farmersrespite:green_tea_leaves
  parent: special-crops/index.md
  position: 1
item_ids: 
  - farmersrespite:green_tea_leaves
  - farmersrespite:yellow_tea_leaves
  - farmersrespite:black_tea_leaves
---

## 茶叶

<ItemImage id="farmersrespite:green_tea_leaves" />
<ItemImage id="farmersrespite:yellow_tea_leaves" />
<ItemImage id="farmersrespite:black_tea_leaves" />

绿茶叶：采摘成熟阶段为绿色的茶树得到；   
黄茶叶：采摘成熟阶段为黄色或黄褐色的茶树得到；   
红茶叶：采摘成熟阶段为黄褐色或褐色的茶树得到。   

此外绿茶叶也可以通过茶浆果得到；  
黄茶叶可以通过晒干绿茶叶得到；   
红茶叶可以通过发酵白茶叶得到。  