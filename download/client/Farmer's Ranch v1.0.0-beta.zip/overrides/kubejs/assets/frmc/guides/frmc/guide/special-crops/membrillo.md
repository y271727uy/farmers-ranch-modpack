---
navigation:
  title: 榅桲
  icon: argentinas_delight:membrillo
  parent: special-crops/index.md
  position: 1
item_ids:
  - argentinas_delight:membrillo
---

## 榅桲

<ItemImage id="argentinas_delight:membrillo" />

### 来源
可以在野外寻找野生榅桲树获得榅桲。  

### 种植
手持榅桲右击泥土即可种植。  
