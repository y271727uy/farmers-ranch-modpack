---
navigation:
  title: 黑橄榄
  icon: manors_bounty:black_olive_fruit
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:black_olive_fruit
---

## 黑橄榄

<ItemImage id="manors_bounty:black_olive_fruit" />

### 来源
黑橄榄可以在 SDM 商店购买。  

### 种植
也可以直接种橄榄种子，或者将橄榄种子种植于树坑上。  
