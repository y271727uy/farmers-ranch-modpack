---
navigation:
  title: 菠萝
  icon: fruitsdelight:pineapple
  parent: special-crops/index.md
  position: 1
item_ids:
  - fruitsdelight:pineapple
  - fruitsdelight:pineapple_sapling
---

## 菠萝

<ItemImage id="fruitsdelight:pineapple" />
<ItemImage id="fruitsdelight:pineapple_sapling" />

### 来源
使用刀在砧板上切开菠萝可以获得菠萝苗。  

### 种植
菠萝作物只能种植在沙子或红沙上。  
