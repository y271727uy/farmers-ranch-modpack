---
navigation:
  title: 不兼容模组清单
  icon: minecraft:redstone
  parent: dev-guide/index.md
  position: 11
---

## 不兼容模组清单

> 以下 mod 不兼容本整合包，可能引发崩溃或造成错误。

### 模组列表

1. **OptiFine**

   不兼容 Embeddium 等渲染优化模组。

2. **小米乐事（Millet Delight）**

   Sinytra Connector 无法转译，请等待 Forge 移植版。

3. **Recipe Essentials 与 FastSuite**

   FRMC 与它们优化的是同一模块，因此完全不兼容。

4. **机械动力（Create）低于 6.0.8 版本的附属**

   由于机械动力底层变动较大，低于 `6.0.8` 的附属不保证兼容；低于 `6.0.0` 的版本不兼容。

5. **农夫乐事（Farmers Delight）1.3.0 以上版本**

   当前发布版本暂不兼容该版本，因为方法变动会导致大量附属崩溃。整合包开发版本已经完成兼容。

6. **Canary**

   不建议安装，可能造成坏档。推荐继续使用 镭（Radium Reforged）。

7. **更多生物变种（More Mob Variants）**

   与 Farmer's Tales 的 Mixin 注入点相同，可能导致崩溃。

8. **Quality Food**

   与 Farmer's Tales 的 Mixin 注入点相同，可能导致崩溃。

9. **Mixin Squared 0.3.2-beta.4 以上版本**

   可能因为类名或方法变动导致 FRMC、Embeddium 等模组崩溃。

10. **阡陌交通（RoadWeaver）**

    当前版本仍然兼容，但后续可能因为 Realistic Terrain Generation Modern 发生不兼容。

11. **现代乐事（Modern Delight）Fabric 版**

    Sinytra Connector 无法转译，推荐使用 Forge 移植版。

