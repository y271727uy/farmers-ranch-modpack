---
navigation:
  title: 青提
  icon: manors_bounty:muscat_grape
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:muscat_grape
---

## 青提

<ItemImage id="manors_bounty:muscat_grape" />

### 来源
青提是一种稀有作物。由于本整合包修改，青提无法自然获得，只能从 SDM 商店购买，或者使用林业温室培养获得。  
