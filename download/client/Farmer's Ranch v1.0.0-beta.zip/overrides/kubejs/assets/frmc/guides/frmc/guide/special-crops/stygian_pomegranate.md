---
navigation:
  title: 幽冥石榴
  icon: collectorsreap:stygian_pomegranate
  parent: special-crops/index.md
  position: 1
item_ids:
  - collectorsreap:stygian_pomegranate
---

## 幽冥石榴

<ItemImage id="collectorsreap:stygian_pomegranate" />

当石榴被种植在复生沃土上时，有概率突变为该品种