---
navigation:
  title: 铁根
  icon: vital_herbs:iron_root
  parent: special-crops/index.md
  position: 1
item_ids:
  - vital_herbs:iron_root
---

## 铁根

<ItemImage id="vital_herbs:iron_root" />

### 来源
铁根植株生成于山地生物群系。  

### 种植
铁根植株没有种子，使用铁根物品可直接种植。  
铁根可种植在岩石方块、沙子和红沙上，可以使用骨粉催熟。  
