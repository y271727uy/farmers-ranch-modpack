---
navigation:
  title: 稻米
  icon: farmersdelight:rice
  parent: special-crops/index.md
  position: 1
item_ids:
  - farmersdelight:rice_panicle
  - farmersdelight:rice
---

## 稻米

<ItemImage id="farmersdelight:rice" />
<ItemImage id="farmersdelight:rice_panicle" />

### 获取
破坏沼泽群系自然生成的野生稻米时掉落。  
发现于废弃矿井的奖励箱中。  

### 用途
稻米可以用于种植。  
稻米必须在位于静止的水下方的泥土、草方块或沃土上才能种植。  
种植后的水稻作物共有四个生长阶段，但只有上方一格处为空气时才能长成第三、四阶段。  
成熟后的水稻作物有两格高，并且会在较高的一格被破坏时掉落稻米穗。  
如果在手持刀时左键破坏，则改为掉落稻米和草秆，并且不会消耗刀的耐久度。  
