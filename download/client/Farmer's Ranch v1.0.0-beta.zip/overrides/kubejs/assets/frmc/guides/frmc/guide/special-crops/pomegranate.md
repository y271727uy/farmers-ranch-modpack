---
navigation:
  title: 石榴
  icon: collectorsreap:pomegranate
  parent: special-crops/index.md
  position: 1
item_ids:
  - collectorsreap:pomegranate
  - manors_bounty:pomegranate_seed
---

## 石榴

<ItemImage id="collectorsreap:pomegranate" />
<ItemImage id="manors_bounty:pomegranate_seed" />

### 来源
石榴是一种产自下界的水果，自然生长于诡异森林群系。  
诡异森林中会自然生长石榴灌木丛。  

### 种植
石榴种子可种植在草方块、砂土、菌丝等含泥方块上。  
种植在诡异菌岩、绯红菌岩和肥沃灵魂土上时能加快生长速度。  
新版本中，石榴种子只能种植在诡异菌岩、绯红菌岩和肥沃灵魂土上。  
也可以使用石榴籽进行种植，该方式种出的石榴树不需要授粉，也没有环境限制，但无法获得幽冥石榴。  
石榴共有五个生长阶段，前两个阶段为种子期，后三个阶段为灌木丛期。  

### 生长
石榴不可使用骨粉催熟，但可以被蜜蜂授粉催熟。  
在下界种植石榴不需要授粉也可结果，种植在主世界时可能需要授粉。  

### 收获
直接破坏石榴灌木丛只会掉落 1 颗石榴种子。  
破坏种子期的石榴不会掉落任何物品。  
石榴灌木丛结出成熟石榴后，右击灌木丛可获得 2 个石榴，灌木丛会开始重新生长石榴。  

### 用途
石榴可装箱、堆肥，也可切片后制作更多食物。  
