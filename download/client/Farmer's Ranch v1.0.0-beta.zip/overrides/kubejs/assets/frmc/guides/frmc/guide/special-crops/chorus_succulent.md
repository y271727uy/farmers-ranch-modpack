---
navigation:
  title: 紫颂多肉植物
  icon: ends_delight:chorus_succulent
  parent: special-crops/index.md
  position: 1
item_ids:
  - ends_delight:chorus_succulent
---

## 紫颂多肉植物

<ItemImage id="ends_delight:chorus_succulent" />

### 来源
紫颂多肉植物自然生成于末地中型岛屿和末地高岛群系。  

### 增殖
当正下方的方块为末地石时，可以使用骨粉催熟，使其增殖为 3 个紫颂多肉植物。  
