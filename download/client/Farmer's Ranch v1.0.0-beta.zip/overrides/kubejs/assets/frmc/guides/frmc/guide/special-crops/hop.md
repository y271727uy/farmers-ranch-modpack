---
navigation:
  title: 啤酒花
  icon: alcocraftplus:hop
  parent: special-crops/index.md
  position: 1
item_ids:
  - alcocraftplus:hop_seeds
  - alcocraftplus:hop
---

## 啤酒花

<ItemImage id="alcocraftplus:hop_seeds" />
<ItemImage id="alcocraftplus:hop" />

### 种植
啤酒花种子必须种植在方块下方，生长方式类似发光浆果。  
成熟后右击可采摘啤酒花。  
