---
navigation:
  title: 阴森藤
  icon: vital_herbs:grim_vine
  parent: special-crops/index.md
  position: 1
item_ids:
  - vital_herbs:grim_vine
---

## 阴森藤

<ItemImage id="vital_herbs:grim_vine" />

### 来源
阴森藤植株生成于末地。  

### 种植
阴森藤植株可种植在完整方块的侧面上。  
阴森藤植株会自动向四周扩散 1 格，对其使用骨粉可快速扩散。  
