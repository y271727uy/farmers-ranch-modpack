---
navigation:
  title: 西柚
  icon: manors_bounty:grapefruit
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:grapefruit
---

## 西柚

<ItemImage id="manors_bounty:grapefruit" />

### 来源
西柚可以通过与村民交易获得，也可以在 SDM 商店购买。  

### 种植
西柚也可以直接种植柑橙种子。  
也可以直接种植西柚树苗，或者使用柑橙种子种植在树坑上。  
