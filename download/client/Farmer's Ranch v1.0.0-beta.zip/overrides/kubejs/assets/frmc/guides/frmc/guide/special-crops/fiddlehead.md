---
navigation:
  title: 蕨菜
  icon: cosmopolitan:fiddlehead
  parent: special-crops/index.md
  position: 1
item_ids:
  - cosmopolitan:fiddlehead
---

## 蕨菜

<ItemImage id="cosmopolitan:fiddlehead" />

### 来源
破坏蕨和大型蕨有 5% 的概率掉落 1 个蕨菜。  
