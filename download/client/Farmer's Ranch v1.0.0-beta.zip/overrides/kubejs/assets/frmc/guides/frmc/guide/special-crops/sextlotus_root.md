---
navigation:
  title: 既望莲
  icon: immortalers_delight:sextlotus_root
  parent: special-crops/index.md
  position: 1
item_ids:
  - immortalers_delight:sextlotus_root
---

## 既望莲

<ItemImage id="immortalers_delight:sextlotus_root" />
<ItemImage id="immortalers_delight:sextlotus_seeds" />
<ItemImage id="immortalers_delight:sextlotus_leaf" />

### 来源

由嗅探兽在森林、繁花森林、桦木森林、原始桦木森林 、黑森林​、雪林挖掘获得。

### 种植
既望莲子可以种植在耕地、沃土耕地上，可以使用骨粉催熟。  
既望莲植株共有八个生长阶段：0%、14%、29%、43%、57%、71%、86%、成熟。  
后四个阶段的既望莲会发出光亮，亮度依次为 4、7、12、15。  
成熟后右击收获既望莲子、既望莲叶、既望芜菁。  

### 生长机制
- 1~6 阶段需要亮度小于 9；
- 相邻位置不能存在未成熟的既望莲植株；
- 伴随月相变化才可生长；
- 生长时会吞噬 3×6×3 格内植物、泥土类方块的养分，最多吞噬 7 个方块，吞噬的养分越多生长成功的概率越高；（未吞噬方块时，成功概率仅 1/8）
- 若相邻位置存在成熟的既望莲植株，则忽视第一、二条；
- 若相邻位置（除正上方）存在月莲灯，则忽视第一、二、三条，但需要至少吞噬 2 点养分才能生长。

### 催熟机制
**计时模式**  
- 催熟需间隔 2.5 秒及以上；
- 生长时会吞噬附近植物、泥土类方块的养分，最多吞噬 31 个方块；
- 若吞噬的养分不少于 8 点，则保底生长一个阶段，根据吞噬的养分多少，额外生长 0~4 个阶段；反之，生长一个阶段后切换至计数模式。

**计数模式**  
- 催熟无间隔，连续催熟 50 次后切换至计时模式。

### 吞噬机制
 
| 标签          | 包含的方块/标签 |   被吞噬后   |  养分 |
| ------------- | ------------- | -------------|-------|
| sextlotus_transform_coal  | 沃土、沃土耕地  |   煤炭块/泥土  |  3 |
| sextlotus_transform_dirt  |  minecraft:logs |    泥土      |  1 |
| sextlotus_transform_sand  |  minecraft:dirt |    砂土      |  1 |
| null  | 砂土  | 沙子  |  1  |
| sextlotus_transform_air  | minecraft:flowers、minecraft:saplings、minecraft:crops、minecraft:maintains_farmland、minecraft:leaves、溪竹、洞穴藤蔓、垂泪藤、缠怨藤、藤蔓、甘蔗、仙人掌、大型滴叶、竹子 | 枯萎的灌木  |  1  |
| null  |  枯萎的灌木 | 空气  |  1  |
| sextlotus_transform_special  | minecraft:underwater_bonemeals、minecraft:coral_blocks  | 失活变种  |  2  |


