---
navigation:
  title: 蒲公英根
  icon: foragersinsight:dandelion_root
  parent: special-crops/index.md
  position: 1
item_ids:
  - foragersinsight:dandelion_root
---

## 蒲公英根

<ItemImage id="foragersinsight:dandelion_root" />

### 来源
持有农夫乐事的刀时，破坏蒲公英有 50% 的概率掉落 1 个蒲公英根，大部分附属的刀也可以触发。  
未持有刀时，破坏蒲公英不会掉落任何物品。  

### 种植
蒲公英根可以像一般作物种子一样右键种植在耕地上。  
破坏成熟的蒲公英根作物会掉落 3~5 个蒲公英根。  
持有农夫乐事的刀时，破坏成熟的蒲公英根作物还会额外掉落 1 个黄色染料。  
