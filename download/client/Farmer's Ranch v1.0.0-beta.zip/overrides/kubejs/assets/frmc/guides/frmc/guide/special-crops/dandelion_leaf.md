---
navigation:
  title: 蒲公英叶
  icon: veggiesdelight:dandelion_leaf
  parent: special-crops/index.md
  position: 1
item_ids:
  - veggiesdelight:mature_dandelion
  - veggiesdelight:dandelion_leaf
---

## 蒲公英叶

<ItemImage id="veggiesdelight:dandelion_leaf" />

### 来源
成熟蒲公英一般生成在蒲公英丛中，破坏后掉落 1~2 个蒲公英叶。  

### 处理
推荐使用剪刀剪下成熟蒲公英，再拿到砧板上破坏，可以获得更多蒲公英叶。  
