---
navigation:
  title: 出货箱
  icon: shopcore:selling_bin
  parent: dev-guide/index.md
  position: 1
---

## 出货箱

<ItemImage id="shopcore:selling_bin" />

**在开始前请确保您对Minecraft数据包与Json结构有一个基础的认知！**  

> **免责声明**   
> 开发者仅对 ShopCore 模组本体的必要 Bug 负责维护修复。对于玩家私下错误修改数据包导致的任何问题，开发者不承担责任。请确保遵循本文档的配置规范。    

ShopCore是负责提供出货箱物品的模组，使用数据包添加支持物品。  

通过数据包添加支持物品   
1. 创建一个json文件  
2. 放入data\modid\recipes\id.json  

通过KubeJS脚本添加支持物品      
1. 在kubejs\server_scripts目录下创建一个js文件   
2. 使用custom方法添加配方   

>示例：
>ServerEvents.recipes(event => {   
>  event.custom({json数据结构})   
>});  


**出货箱数据结构如下:**   

>{    
  "type": "shopcore:selling_bin",     
  "input": {       
    "item": "minecraft:apple",     
    "count": 5     
  },    
  "output": {     
    "item": "list:copper_gt_credit"     
  },   
  "base": 1,    
  "max": 3,     
  "group": "crop",       
  "trade_balance": true,       
  "s-regression": false,       
  "season":"winter",   
  "season_base": 1,     
  "season_max": 3,   
  "season_only": false     
>}     

### type
- **类型**：`String`
- **必填**：是
- **约束**：固定值 `shopcore:selling_bin`
- **说明**：数据包类型标识符

### input
- **类型**：`Object`
- **必填**：是
- **子字段**：
  - `item`（`String`，必填）：物品 ID 或 Tag，支持命名空间格式（如 `minecraft:apple`）
  - `count`（`Integer`，必填）：交易数量，必须为正整数
- **说明**：输入物品配置，支持 `item` 字段的同时也支持 `tag` 字段

**Quality 作物兼容**    
由 ShopCore 独立实现的 Quality 作物 (带有品质的作物) 已内置兼容，无需单独配置。  
由于 ShopCore 独立实现了 Quality 作物支持，因此不内置 Quality Food 和 Quality Crops 模组的兼容，也不会主动兼容这两个模组。如需使用这些模组的物品，请在数据包中自行配置。  

### output
- **类型**：`Object`
- **必填**：是
- **子字段**：
  - `item`（`String`，必填）：输出物品 ID 或 list 的物品 ID（如 `list:copper_gt_credit`）
- **说明**：输出物品配置

### base
- **类型**：`Number`
- **必填**：是
- **约束**：必须为正数，不得为零或负数
- **说明**：物品的基础售价

### max
- **类型**：`Number`
- **必填**：是
- **约束**：必须为正数，不得为零或负数
- **说明**：物品的最大售价

### group
- **类型**：`String`
- **必填**：否
- **说明**：价格浮动与继承的核心字段。若未填写，则无法进行价格浮动、季节经济与继承

### trade_balance
- **类型**：`Boolean`
- **必填**：否
- **默认值**：`false`
- **说明**：贸易平衡模块开关。通过引入 S-R 回归来实现：短期内出售多则降价，反之则涨价。`true` 表示启用贸易平衡

### s-regression
- **类型**：`Boolean`
- **必填**：否
- **默认值**：`false`
- **说明**：S 回归方向控制。`false` 表示正回归（S 回归速度越来越快）；`true` 表示反回归（S 回归速度越来越慢）

### season
- **类型**：`String`
- **必填**：否
- **说明**：指定该物品会在哪一个季节涨价

**季节机制说明**     
目前仅支持季节涨价机制，暂不会添加非合法季节降价的机制。

### season_only
- **类型**：`Boolean`
- **必填**：否
- **默认值**：`false`
- **说明**：季节独占开关。`true` 表示该物品只在指定季节出售

### season_base
- **类型**：`Number`
- **必填**：否
- **约束**：必须为正数，不得为零或负数
- **说明**：季节物品的基础价格加成

### season_max
- **类型**：`Number`
- **必填**：否
- **约束**：必须为正数，不得为零或负数
- **说明**：季节物品的最大价格加成

## 功能依赖说明

- `group` 字段是价格浮动、季节经济与继承功能的前置条件，未填写时上述功能均不生效
- `trade_balance` 与 `s-regression` 配合使用，后者仅在贸易平衡启用时才有实际意义
- `season_only`、`season_base`、`season_max` 需要配合 `season` 字段使用，单独填写无效

