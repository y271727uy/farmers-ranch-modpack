---
navigation:
  title: 草种子
  icon: bountifulfares:grass_seeds
  parent: special-crops/index.md
  position: 1
item_ids:
  - bountifulfares:grass_seeds
---

## 草种子

<ItemImage id="bountifulfares:grass_seeds" />

### 来源
破坏草可以获得草种子。  

### 用途
手持草种子右击泥土，可以将泥土转化为草方块。  
