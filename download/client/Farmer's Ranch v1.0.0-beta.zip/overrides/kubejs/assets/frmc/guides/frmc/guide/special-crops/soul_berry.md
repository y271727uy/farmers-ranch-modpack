---
navigation:
  title: 灵魂浆果
  icon: frightsdelight:soul_berry
  parent: special-crops/index.md
  position: 1
item_ids:
  - frightsdelight:soul_berry
---

## 灵魂浆果

<ItemImage id="frightsdelight:soul_berry" />

### 来源
灵魂浆果只能在堡垒遗迹的宝箱中找到。  

### 种植
灵魂浆果需要种植在灵魂沙或灵魂土上，可以使用骨粉催熟。  
灵魂浆果需要周围 5 格内存在“灵魂之光”，并且光照等级达到 9 级及以上时才会正常生长。  
“灵魂之光”包括灵魂火、灵魂火把、灵魂灯笼、灵魂营火等。  
