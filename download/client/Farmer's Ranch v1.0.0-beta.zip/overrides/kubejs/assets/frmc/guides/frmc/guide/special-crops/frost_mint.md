---
navigation:
  title: 霜薄荷
  icon: vital_herbs:frost_mint
  parent: special-crops/index.md
  position: 1
item_ids:
  - vital_herbs:frost_mint
---

## 霜薄荷

<ItemImage id="vital_herbs:frost_mint" />

### 来源
霜薄荷植株生成于积雪、寒冷的生物群系。  

### 种植
霜薄荷植株可种植在泥土及其变种、草方块、灰化土、缠根泥土、菌丝体和耕地上。  
