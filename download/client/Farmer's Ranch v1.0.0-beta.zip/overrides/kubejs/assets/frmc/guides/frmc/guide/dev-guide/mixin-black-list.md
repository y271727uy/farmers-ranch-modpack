---
navigation:
  title: Mixin 黑名单
  icon: minecraft:grass
  parent: dev-guide/index.md
  position: 2
---

## Mixin 黑名单  

> **免责声明**   
> 开发者仅对 FarmersRanchMixinCore 模组本体的必要 Bug 负责维护修复。对于任何私下禁用 Mixin 导致的任何问题/功能缺失，开发者不承担责任。请确保遵循本文档的配置规范。 

## 概述  
Mixin 黑名单功能由 FarmersRanchMixinCore 模组提供。当某个模组的 Mixin 导致问题且必须禁用时，可使用此模组来解决。  

基于 SpongePowered Mixin 提供的运行时字节码注入能力，通过 IMixinConfigPlugin 在启动早期注册一个自定义 IExtension，然后在目标类应用 mixin 之前，按 toml 配置里的黑名单把指定 mixin 从待应用列表里移除。(使用与GTOlib相同的实现思路但并非同类实现)      

## 重要说明

**对于整合包玩家**  
使用此模组时，特定的模组行为可能失效。请勿向原整合包作者报告相关问题，应由修改者负责处理。

## 配置方法

启动游戏后，在 `config` 文件夹下会自动生成 `frmc-mixin-blacklist.toml` 文件，按以下方式配置即可。

### 方式一：精确匹配（推荐）

禁用一个具体的 Mixin：

>blacklisted_mixins = [
>    "com.example.mod.mixin.EntityMixin"
>]
>```

### 方式二：通配符前缀匹配

使用 `*` 结尾禁用整个包下的所有 Mixin：

>blacklisted_mixins = [
>    "com.example.mod.mixin.render.*"
>]
>```

**示例**：上述配置会禁用以下 Mixin：
- `com.example.mod.mixin.render.PlayerMixin`
- `com.example.mod.mixin.render.GuiMixin`
- 所有 `render` 包下的其他 Mixin

## 配置须知

- 必须填写完整的类名
- `*` 只能放在末尾
- 一次只建议禁用一个进行测试