---
navigation:
  title: 红豆
  icon: neapolitan:adzuki_beans
  parent: special-crops/index.md
  position: 1
item_ids:
  - neapolitan:adzuki_beans
---

## 红豆

<ItemImage id="neapolitan:adzuki_beans" />

成熟的红豆苗自然生成于森林生物群系。  
破坏后掉落红豆并将下方的泥土转变为红豆土。

当成熟的红豆苗被收获后下方的泥土会转变为红豆土，也可以手持红豆右击泥土或草方块转变。  
一段时间后上方会长出红豆苗，同时红豆土变回泥土。   
红豆苗只有在亮度≥9的条件下才能生长。   
当被动生物走过红豆苗时，红豆苗会变为“开花”状态（材质稍有不同），开花的豆苗生长速度更快，且成熟时能收获2-3个红豆而不是1个。   
用锄右击可以将其变回泥土并得到红豆，破坏后掉落泥土与红豆。  