---
navigation:
  title: 鹅莓
  icon: manors_bounty:gooseberry
  parent: special-crops/index.md
  position: 1
item_ids:
  - manors_bounty:gooseberry
---

## 鹅莓

<ItemImage id="manors_bounty:gooseberry" />

### 来源
鹅莓是一种稀有作物，可以在 SDM 商店购买，或通过种植黑加仑有概率获得。  
