---
navigation:
  title: 青豆
  icon: spanishdelight:green_bean
  parent: special-crops/index.md
  position: 1
item_ids:
  - spanishdelight:green_bean
---

## 青豆

<ItemImage id="spanishdelight:green_bean" />

### 来源
青豆无法种植，仅能够通过与村民交易获得。  
