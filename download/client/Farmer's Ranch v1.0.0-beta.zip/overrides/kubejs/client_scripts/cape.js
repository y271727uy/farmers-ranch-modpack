CapeJS.addCapes(event => {
    event.register("7f979806-08a2-4ae7-b057-ace37fea8c64", "transgendercape");
    event.register("212c5e19-8d74-473c-9a8c-520a8d93cca0", "transgendercape");
});
//y271727uy DancingSnow 
