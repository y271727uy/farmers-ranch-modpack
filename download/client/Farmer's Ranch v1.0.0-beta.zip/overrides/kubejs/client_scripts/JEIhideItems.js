JEIEvents.hideItems(event => {
  event.hide('bountifulfares:tea_leaves')

  event.hide('culturaldelights:avocado_pit')
  event.hide('peruviansdelight:semilla_palta')
  event.hide('untamedwilds:egg_spadefish')
  event.hide('untamedwilds:egg_catfish')
  event.hide('untamedwilds:egg_triggerfish')
  event.hide('untamedwilds:egg_football_fish')
  event.hide('untamedwilds:egg_arowana')
  event.hide('untamedwilds:egg_trevally')
  event.hide('untamedwilds:egg_sunfish')
  event.hide('untamedwilds:egg_giant_clam')
  event.hide('untamedwilds:egg_king_crab')
  event.hide('vintagedelight:oat_seeds')
  event.hide('farm_and_charm:rotten_tomato')
  event.hide('yeastnfeast:lemon_sapling')
  event.hide('bountifulfares:lemon_sapling')

  event.hide('forestry:fruit_olive')
  event.hide('alexsmobs:banana')
  event.hide('alexsmobsdelight:banana_slice')
  event.hide('youkaishomecoming:green_coffee_bean')

  event.hide('fruitfulfun:cherry_sapling')
  event.hide('bountifulfares:orange_sapling')

  event.hide('bountifulfares:apple_sapling')
  event.hide('vinery:apple_tree_sapling')
  event.hide('fruitfulfun:apple_sapling')
  
  event.hide('peruviansdelight:camote_cocido')

  event.hide('extravagantdelight:grapefruit_seedling')
  event.hide('extravagantdelight:mango_seedling')
  event.hide('extravagantdelight:quince_seedling')
  //event.hide(Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_orange",inactive:"forestry:fruit_orange"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:0.5f",inactive:"forestry:0.5f"},"forestry:maturation":{active:"forestry:4i",inactive:"forestry:4i"},"forestry:saplings":{active:"forestry:0.025fd",inactive:"forestry:0.025fd"},"forestry:sappiness":{active:"forestry:0.3fd",inactive:"forestry:0.3fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_orange",inactive:"forestry:tree_orange"},"forestry:yield":{active:"forestry:0.3f",inactive:"forestry:0.3f"}}}}}'))
  //event.hide(Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_dates",inactive:"forestry:fruit_dates"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:1.0f",inactive:"forestry:1.0f"},"forestry:maturation":{active:"forestry:4i",inactive:"forestry:4i"},"forestry:saplings":{active:"forestry:0.035fd",inactive:"forestry:0.035fd"},"forestry:sappiness":{active:"forestry:0.3fd",inactive:"forestry:0.3fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_date",inactive:"forestry:tree_date"},"forestry:yield":{active:"forestry:0.1fd",inactive:"forestry:0.1fd"}}}}}'))
  //event.hide(Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_coconut",inactive:"forestry:fruit_coconut"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:1.25f",inactive:"forestry:1.25f"},"forestry:maturation":{active:"forestry:3i",inactive:"forestry:3i"},"forestry:saplings":{active:"forestry:0.025fd",inactive:"forestry:0.025fd"},"forestry:sappiness":{active:"forestry:0.4fd",inactive:"forestry:0.4fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_coconut",inactive:"forestry:tree_coconut"},"forestry:yield":{active:"forestry:0.3f",inactive:"forestry:0.3f"}}}}}'))
  //event.hide(Item.of('forestry:sapling', '{ForgeCaps:{Parent:{analyzed:0b,genome:{"forestry:fireproof":{active:"forestry:falsed",inactive:"forestry:falsed"},"forestry:fruits":{active:"forestry:fruit_lemon",inactive:"forestry:fruit_lemon"},"forestry:girth":{active:"forestry:1i",inactive:"forestry:1i"},"forestry:height":{active:"forestry:0.25f",inactive:"forestry:0.25f"},"forestry:maturation":{active:"forestry:4i",inactive:"forestry:4i"},"forestry:saplings":{active:"forestry:0.025fd",inactive:"forestry:0.025fd"},"forestry:sappiness":{active:"forestry:0.3fd",inactive:"forestry:0.3fd"},"forestry:tree_effect":{active:"forestry:tree_effect_none",inactive:"forestry:tree_effect_none"},"forestry:tree_species":{active:"forestry:tree_lemon",inactive:"forestry:tree_lemon"},"forestry:yield":{active:"forestry:0.3f",inactive:"forestry:0.3f"}}}}}'))
})

//event.hide()
