/*
JEIEvents.information(event => {
  event.addTag('jeitooltip:argentinas_delight_beef', [
    '将阿根廷烤牛肉右键放置于地面可以取下食物'
  ])
})
*/
JEIEvents.information(event => {
  event.addItem('argentinas_delight:vacio', ['阿根廷烤牛肉右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:cortemardelplata', ['阿根廷烤牛肉右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:costillar', ['阿根廷烤牛肉右键放置于地面可以取下食物'])

  event.addItem('argentinas_delight:patadechanchotool', ['阿根廷烤猪肉右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:costillasdechancho', ['阿根廷烤猪肉右键放置于地面可以取下食物'])

  event.addItem('argentinas_delight:pescadoasadoitem', ['阿根廷烤猪鱼右键放置于地面可以取下食物'])

  event.addItem('argentinas_delight:chinchulinesitem', ['烤牛肠右键放置于地面可以取下食物'])

  event.addItem('argentinas_delight:asadasoitem', ['阿根廷烤牛拼盘','两个烤架并排摆放，将牛尸体放在烤架上，然后手持高乔刀左键牛尸体制作'])

  event.addItem('argentinas_delight:lechon_asadoitem', ['阿根廷烤乳猪','两个烤架并排摆放，将猪尸体放在烤架上，然后手持苹果右键猪尸体制作'])
  event.addItem('argentinas_delight:cabezadechancho_1', ['阿根廷烤乳猪右键放置于地面可以取下食物'])

  event.addItem('argentinas_delight:manjarosarino', ['罗萨里奥乐事','手持面包右键猫制作'])

  event.addItem('argentinas_delight:jarraconhieloitem', ['先将玻璃杯放在地上','然后拿桶右键倒水，再手持冰右键水杯即可制成冰水。','冰、浮冰和蓝冰都可以','冰水和果汁破坏后掉落的不能再放置于地上,并且果汁和冰水不能直接喝只是用来做冰马黛茶的'])
  event.addItem('argentinas_delight:jarraconjugodebayas', ['手持材料右键放入冰水制作','材料为：甜浆果、西瓜、闪烁的西瓜、萤石粉、苹果','冰水和果汁破坏后掉落的不能再放置于地上,并且果汁和冰水不能直接喝只是用来做冰马黛茶的'])
  event.addItem('argentinas_delight:jarraglowberryitem', ['手持材料右键放入冰水制作','材料为：甜浆果、西瓜、闪烁的西瓜、萤石粉、苹果','冰水和果汁破坏后掉落的不能再放置于地上,并且果汁和冰水不能直接喝只是用来做冰马黛茶的'])
  event.addItem('argentinas_delight:jarramanzanaitem', ['手持材料右键放入冰水制作','材料为：甜浆果、西瓜、闪烁的西瓜、萤石粉、苹果','冰水和果汁破坏后掉落的不能再放置于地上,并且果汁和冰水不能直接喝只是用来做冰马黛茶的'])

  event.addItem('argentinas_delight:itemjarraloca', ['狂野特调','1.放一个空玻璃杯','2.拿水桶右键玻璃杯倒水','3.将一个糖扔到水杯中。杯子是中空的，糖要以掉落物的形式在水杯里面','4.然后将一只生物卡入水杯中,水杯上下都有开口，用活塞把水杯从上或从下推到生物的位置','5.手持冰右键放入有糖和生物的水杯'])

  event.addItem('argentinas_delight:patadepollo', ['阿根廷烤鸡右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:alitasdepollo', ['阿根廷烤鸡右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:muslosdepollo', ['阿根廷烤鸡右键放置于地面可以取下食物'])

  event.addItem('argentinas_delight:polloloco', ['使用高乔刀击杀动物，将尸体推到切石机上即可切割成各种肉'])
  event.addItem('argentinas_delight:tirasdeasado', ['使用高乔刀击杀动物，将尸体推到切石机上即可切割成各种肉'])
  event.addItem('argentinas_delight:tirasdechancho', ['使用高乔刀击杀动物，将尸体推到切石机上即可切割成各种肉'])
  event.addItem('argentinas_delight:achurasitem', ['使用高乔刀击杀动物，将尸体推到切石机上即可切割成各种肉'])
  event.addItem('argentinas_delight:corderocrudo', ['使用高乔刀击杀动物，将尸体推到切石机上即可切割成各种肉'])

  event.addItem('argentinas_delight:terere', ['把地上的冰水破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:teredesandiadoradaitem', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:teresandiaitem', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:teredemanza', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:tereglowberryitem', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:teredelimonbloque', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:tereredeberryroja', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])
  event.addItem('argentinas_delight:tereanana', ['把地上的果汁破坏，然后拿着右键装有马黛茶的杯子(只放茶不放其他材料或水的)，即可制成'])

  event.addItem('argentinas_delight:pancaseroporcion', ['烤盘装手工面包右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:panconchicharronitem', ['烤盘装油渣面包右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:bolasdefraile', ['修士炸面球右键放置于地面可以取下食物'])
  event.addItem('argentinas_delight:rosquita', ['炸甜甜圈右键放置于地面可以取下食物'])
  //event.addItem(, [''])
  //event.addItem(, [''])
  //event.addItem(, [''])
  //event.addItem(, [''])

})
