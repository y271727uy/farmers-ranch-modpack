ItemEvents.tooltip(event => {
  //event.add(, '§4已禁止生成')
  event.add('untamedwilds:butterfly_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:bear_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:rhino_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:tarantula_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:snake_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:boar_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:camel_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:large_snake_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:spitter_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:bison_spawn_egg', '§4已禁止生成')
  event.add('untamedwilds:hippo_spawn_egg', '§4已禁止生成')

  event.add('naturalist:boar_spawn_egg', '§4已禁止生成')
  event.add('naturalist:deer_spawn_egg', '§4已禁止生成')
  event.add('naturalist:rattlesnake_spawn_egg', '§4已禁止生成')
  event.add('naturalist:coral_snake_spawn_egg', '§4已禁止生成')

  event.add('peruviansdelight:atun_spawn_egg', '出现bug,暂时禁止自然生成')

  //event.add('manors_bounty:corn_seed', '种植在耕地成长为玉米，种植在泥土等方块可以收获玉米笋')

  //event.add(, '§2中文译名修正：帝王蟹卵')
  //event.add(, '§4已禁止生成')
  //event.add(, '§4已禁止生成')
  //event.add(, '§4已禁止生成')
  //event.add(, '§4已禁止生成')

  event.add('oreberriesreplanted:osmium_oreberry', '§4无相应金属材料，但可以出售')
  //event.add('oreberriesreplanted:zinc_oreberry', '§4无相应金属材料，但可以出售')
  event.add('oreberriesreplanted:lead_oreberry', '§4无相应金属材料，但可以出售')
  event.add('oreberriesreplanted:osmium_oreberry_bush', '§4产物副产物无对应金属材料，但可以出售')
  event.add('oreberriesreplanted:lead_oreberry_bush', '§4产物副产物无对应金属材料，但可以出售')

  //event.add(, '§4无实际功能，仅供装饰')
  event.add('hearthandharvest:cask', '§4无实际功能，仅供装饰')
  event.add('alcocraftplus:keg', '§4无实际功能，仅供装饰')
  event.add('yeastnfeast:keg', '§4无实际功能，仅供装饰')

  event.add('growable_ores:vanilla/result/egg_cane_result', '§4请勿制作')
  event.add('growable_ores:feather_cane', '§4请勿制作')
  event.add('growable_ores:wool_cane', '§4请勿制作')
  event.add('growable_ores:gunpowder_cane', '§4请勿制作')
  event.add('growable_ores:leather_cane', '§4请勿制作')

  //半成品提示
  event.add('braziliandelight:heavy_cream_bucket', '制作重奶油首先需要手持奶桶右击厨锅倒入，接着空手长按右键搅拌一圈，最后用空桶盛起。')
  event.add('manors_bounty:banana_frond', '仅用于装饰')
  event.add('neapolitan:banana_frond', '可用于种植')

  event.add(Item.of('untamedwilds:egg_king_crab', '{CustomModelData:0,variant:0}'), '§2中文译名修正：帝王蟹卵')
  event.add(Item.of('untamedwilds:egg_king_crab', '{CustomModelData:0,variant:0}'), '§3皇帝蟹（巨大拟滨蟹）和帝王蟹是不同物种')
  event.add(Item.of('untamedwilds:egg_king_crab', '{CustomModelData:0,variant:0}'), '§3前者产于澳洲且体色偏淡，后者体型更大、产于阿拉斯加和俄罗斯沿海体色偏红')

})